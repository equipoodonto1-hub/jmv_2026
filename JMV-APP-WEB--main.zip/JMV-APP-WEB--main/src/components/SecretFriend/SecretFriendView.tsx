import React, { useState } from 'react';
import {
  Gift,
  Send,
  Sparkles,
  HelpCircle,
  Eye,
  CheckCircle,
  Clock,
  Heart,
  Lightbulb,
  MessageCircle,
  Lock,
  RotateCcw,
  Users,
  Check,
  X,
  Plus,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

const DAILY_SUGGESTIONS = [
  { day: 1, title: 'Día 1: Oración por ti', prompt: 'Dedica tu oración de hoy por tu amigo secreto y dile brevemente qué pediste a Dios por él o ella.' },
  { day: 2, title: 'Día 2: Frase Motivacional', prompt: 'Comparte una frase vicenciana o bíblica que le dé fuerzas en sus estudios o trabajo.' },
  { day: 3, title: 'Día 3: Un Elogio Sincero', prompt: 'Dile qué cualidad o talento admiras en su forma de ser dentro de JMV sin revelar tu nombre.' },
  { day: 4, title: 'Día 4: Recuerdos Alegres', prompt: 'Menciona un momento divertido o una anécdota del grupo que te alegre recordar.' },
  { day: 5, title: 'Día 5: Un Canto o Melodía', prompt: 'Recomiéndale una canción católica o mariana para su lista de reproducción.' },
  { day: 6, title: 'Día 6: Agradecimiento', prompt: 'Agradécele por ser parte de nuestra familia comunitaria y perseverar.' },
  { day: 7, title: 'Día 7: ¡Día de la Revelación!', prompt: 'Prepara tu mensaje final y un pequeño detalle o abrazo fraterno para la reunión.' },
];

export const SecretFriendView: React.FC = () => {
  const {
    currentUser,
    users,
    secretRound,
    secretMessages,
    startSecretFriendRound,
    resetSecretFriendRound,
    sendSecretMessage,
    revealSecretFriends,
    mySecretTarget,
    isAdmin,
  } = useApp();

  const [messageText, setMessageText] = useState('');
  const [selectedDay, setSelectedDay] = useState(1);
  const [showConfigModal, setShowConfigModal] = useState(false);

  // Estados del modal de inicio de sorteo
  const [roundTitle, setRoundTitle] = useState('Semana de la Fraternidad Mariana');
  const [durationDays, setDurationDays] = useState(7);
  const [selectedUserIds, setSelectedUserIds] = useState<string[]>(() => users.map((u) => u.id));

  // Mensajes que YO le he enviado a mi amigo secreto
  const sentByMe = secretMessages.filter(
    (m) => m.giverId === currentUser.id && m.receiverId === mySecretTarget?.id
  );

  // Mensajes que he RECIBIDO en mi buzón anónimo
  const receivedByMe = secretMessages.filter((m) => m.receiverId === currentUser.id);

  // Quién me regalaba a mí (solo visible si la ronda ya fue revelada)
  const myGiverAssignment = secretRound?.assignments?.find((a) => a.receiverId === currentUser.id);
  const myRevealedFriend = myGiverAssignment
    ? users.find((u) => u.id === myGiverAssignment.giverId)
    : null;

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim()) return;

    sendSecretMessage(messageText.trim(), selectedDay);
    setMessageText('');
  };

  const handleStartRound = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedUserIds.length < 2) {
      alert('Debes seleccionar al menos 2 integrantes para realizar el sorteo.');
      return;
    }

    startSecretFriendRound(roundTitle.trim(), selectedUserIds, durationDays);
    setShowConfigModal(false);
  };

  const toggleSelectAll = () => {
    if (selectedUserIds.length === users.length) {
      setSelectedUserIds([]);
    } else {
      setSelectedUserIds(users.map((u) => u.id));
    }
  };

  const toggleUserSelection = (userId: string) => {
    if (selectedUserIds.includes(userId)) {
      setSelectedUserIds(selectedUserIds.filter((id) => id !== userId));
    } else {
      setSelectedUserIds([...selectedUserIds, userId]);
    }
  };

  return (
    <div className="space-y-6 pb-20 animate-in fade-in">
      {/* Encabezado */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400">
              <Gift className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
              Amigo Secreto Semanal
            </h1>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            {secretRound.assignments.length > 0
              ? `${secretRound.assignments.length} participantes activos en "${secretRound.title}".`
              : 'Dinámica de fraternidad y oración diaria anónima.'}
          </p>
        </div>

        {isAdmin && (
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => {
                setSelectedUserIds(users.map((u) => u.id));
                setShowConfigModal(true);
              }}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-2xl bg-purple-900 hover:bg-purple-800 text-white font-bold text-xs shadow-md transition active:scale-95"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Iniciar con Otras Personas</span>
            </button>

            {secretRound?.status === 'active' && secretRound.assignments.length > 0 && (
              <button
                onClick={() => {
                  if (confirm('¿Confirmas revelar la identidad de todos los amigos secretos del grupo ahora?')) {
                    revealSecretFriends();
                  }
                }}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md transition active:scale-95"
              >
                <Sparkles className="w-4 h-4" />
                <span>Revelar Amigos</span>
              </button>
            )}
          </div>
        )}
      </div>

      {/* Si la ronda fue revelada: Tarjeta de celebración */}
      {secretRound?.status === 'revealed' ? (
        <div className="p-6 rounded-3xl bg-gradient-to-r from-amber-500 via-pink-500 to-purple-600 text-white shadow-xl text-center">
          <Sparkles className="w-10 h-10 mx-auto text-yellow-200 animate-spin" />
          <h2 className="text-xl font-extrabold mt-2">¡Las identidades han sido reveladas!</h2>
          <p className="text-xs text-white/90 mt-1 max-w-md mx-auto">
            La ronda culminó. ¡Es hora del compartir y el abrazo fraterno en la reunión!
          </p>

          <div className="mt-5 max-w-sm mx-auto p-4 rounded-2xl bg-white/20 backdrop-blur-md border border-white/20">
            <span className="text-[10px] uppercase font-bold text-yellow-200">Tu amigo secreto que oraba por ti fue:</span>
            <div className="mt-2 flex items-center justify-center gap-3">
              <img
                src={myRevealedFriend?.avatarUrl}
                alt={myRevealedFriend?.name}
                className="w-12 h-12 rounded-full object-cover ring-2 ring-white"
              />
              <div className="text-left">
                <span className="block font-black text-lg text-white">{myRevealedFriend?.name}</span>
                <span className="text-xs text-yellow-100">¡Agradécele en la reunión! ❤️</span>
              </div>
            </div>
          </div>

          {isAdmin && (
            <button
              onClick={() => {
                setSelectedUserIds(users.map((u) => u.id));
                setShowConfigModal(true);
              }}
              className="mt-4 px-4 py-2 rounded-xl bg-white text-purple-900 font-bold text-xs hover:bg-purple-50 transition"
            >
              Comenzar Nueva Dinámica con Nuevos Participantes
            </button>
          )}
        </div>
      ) : (
        /* Tarjeta de Asignación Secreta del Usuario */
        <div className="p-6 rounded-3xl bg-gradient-to-br from-indigo-950 via-purple-900 to-blue-900 text-white shadow-xl">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
            <span className="px-3 py-1 rounded-full bg-purple-400/20 text-purple-200 font-bold text-[10px] uppercase tracking-wider flex items-center gap-1">
              <Lock className="w-3 h-3" /> Solo visible para ti
            </span>
            <span className="text-xs text-purple-200">
              Revelación: {new Date(secretRound.revealDate).toLocaleDateString('es-ES', { day: 'numeric', month: 'short' })}
            </span>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center gap-4">
            {mySecretTarget ? (
              <>
                <div className="w-16 h-16 rounded-full overflow-hidden ring-4 ring-purple-400/50 shrink-0">
                  <img
                    src={mySecretTarget.avatarUrl}
                    alt={mySecretTarget.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <span className="text-xs text-purple-200 block">Tu amigo secreto asignado es:</span>
                  <h2 className="text-xl font-extrabold text-white tracking-tight">
                    {mySecretTarget.name}
                  </h2>
                  <p className="text-xs text-purple-100/80 mt-0.5">
                    Cumpleaños: {new Date(mySecretTarget.birthday).toLocaleDateString('es-ES', { day: 'numeric', month: 'long' })}
                  </p>
                </div>
              </>
            ) : (
              <div className="text-xs text-purple-200">
                <p className="font-bold">No estás participando en la ronda actual o aún no se ha iniciado un sorteo.</p>
                {isAdmin && (
                  <p className="mt-1 text-[11px] text-purple-300">
                    Como coordinador, usa el botón "Iniciar con Otras Personas" para seleccionar los participantes y sortear.
                  </p>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Grid de 2 columnas: Dejar mensaje anónimo vs Buzón recibido */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Columna Izquierda: Enviar Mensaje Anónimo Diario */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Send className="w-4 h-4 text-purple-600" />
              Enviar Mensaje Diario Anónimo
            </h3>
            <span className="text-xs text-slate-500">
              Para: {mySecretTarget?.name.split(' ')[0] || '...'}
            </span>
          </div>

          {/* Selector de Día 1 a 7 con sugerencia */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Elige el día de la dinámica:
            </label>
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
              {DAILY_SUGGESTIONS.map((item) => (
                <button
                  key={item.day}
                  type="button"
                  onClick={() => setSelectedDay(item.day)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition ${
                    selectedDay === item.day
                      ? 'bg-purple-900 text-white shadow'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
                  }`}
                >
                  Día {item.day}
                </button>
              ))}
            </div>
          </div>

          {/* Caja de sugerencia para el día seleccionado */}
          <div className="p-3 rounded-2xl bg-purple-50 dark:bg-purple-950/40 border border-purple-100 dark:border-purple-900/50 flex items-start gap-2.5">
            <Lightbulb className="w-4 h-4 text-purple-600 shrink-0 mt-0.5" />
            <div className="text-xs">
              <span className="font-bold text-purple-900 dark:text-purple-300 block">
                {DAILY_SUGGESTIONS[selectedDay - 1].title}
              </span>
              <p className="text-slate-600 dark:text-slate-300 mt-0.5">
                {DAILY_SUGGESTIONS[selectedDay - 1].prompt}
              </p>
            </div>
          </div>

          <form onSubmit={handleSendMessage} className="space-y-3">
            <textarea
              rows={4}
              required
              disabled={!mySecretTarget}
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              placeholder={
                mySecretTarget
                  ? 'Escribe tu mensaje anónimo aquí... Llegará a su buzón sin revelar tu nombre.'
                  : 'Debes tener un amigo secreto asignado para enviar mensajes.'
              }
              className="w-full p-3.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-purple-600 leading-relaxed disabled:opacity-50"
            />

            <button
              type="submit"
              disabled={!messageText.trim() || !mySecretTarget}
              className="w-full py-2.5 rounded-2xl bg-purple-900 hover:bg-purple-800 disabled:opacity-40 text-white font-bold text-xs shadow-md transition active:scale-95 flex items-center justify-center gap-2"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Enviar Mensaje Anónimo (Día {selectedDay})</span>
            </button>
          </form>

          {/* Historial de lo que yo he enviado */}
          {sentByMe.length > 0 && (
            <div className="pt-3 border-t border-slate-100 dark:border-slate-800">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-2">
                Mensajes que le has enviado ({sentByMe.length})
              </span>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {sentByMe.map((m) => (
                  <div key={m.id} className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 text-xs text-slate-700 dark:text-slate-300">
                    <span className="font-bold text-purple-700 dark:text-purple-400 block text-[10px]">
                      Día {m.dayNumber} · {new Date(m.sentAt).toLocaleDateString('es-ES', { day: 'numeric', month: 'short' })}
                    </span>
                    <p className="mt-0.5">{m.text}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Columna Derecha: Mi Buzón Anónimo (Lo que recibo) */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <MessageCircle className="w-4 h-4 text-amber-500" />
              Tu Buzón Secreto (Mensajes para ti)
            </h3>
            <span className="text-xs text-slate-500">{receivedByMe.length} recibidos</span>
          </div>

          <p className="text-xs text-slate-500">
            Aquí aparecen los mensajes diarios que tu amigo secreto te envía con cariño y oración.
          </p>

          <div className="space-y-3 max-h-[480px] overflow-y-auto pr-1">
            {receivedByMe.length > 0 ? (
              receivedByMe.map((msg) => (
                <div
                  key={msg.id}
                  className="p-4 rounded-2xl bg-gradient-to-br from-amber-50/60 to-purple-50/40 dark:from-slate-800/70 dark:to-slate-800/40 border border-amber-200/60 dark:border-slate-700 shadow-sm"
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[11px] font-extrabold text-purple-900 dark:text-purple-300 flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-amber-500" />
                      De tu Amigo Secreto · Día {msg.dayNumber}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {new Date(msg.sentAt).toLocaleDateString('es-ES', {
                        day: 'numeric',
                        month: 'short',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                  <p className="text-xs text-slate-800 dark:text-slate-200 leading-relaxed italic">
                    "{msg.text}"
                  </p>
                </div>
              ))
            ) : (
              <div className="p-8 text-center text-slate-400 border border-dashed rounded-3xl">
                <Gift className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-xs font-semibold">Aún no has recibido mensajes en esta ronda.</p>
                <p className="text-[11px] mt-0.5">¡Revisa más tarde cuando tu amigo secreto te escriba!</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Modal de Configuración e Inicio de Nueva Ronda (Permite seleccionar integrantes) */}
      {showConfigModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="w-full max-w-lg rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 animate-in fade-in my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-purple-900 text-white flex items-center justify-center font-bold text-xs">
                  <Gift className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                    Iniciar Amigo Secreto con Integrantes Específicos
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Elige exactamente quiénes participan en este nuevo sorteo
                  </p>
                </div>
              </div>
              <button onClick={() => setShowConfigModal(false)} className="text-slate-400">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleStartRound} className="mt-4 space-y-4 text-xs">
              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Nombre o motivo de la dinámica *
                </label>
                <input
                  type="text"
                  required
                  value={roundTitle}
                  onChange={(e) => setRoundTitle(e.target.value)}
                  placeholder="Ej: Semana de la Fraternidad Mariana"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Duración de la dinámica
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[7, 10, 14].map((days) => (
                    <button
                      key={days}
                      type="button"
                      onClick={() => setDurationDays(days)}
                      className={`py-2 rounded-xl text-xs font-bold border transition ${
                        durationDays === days
                          ? 'bg-purple-900 text-white border-purple-900 shadow-sm'
                          : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {days} días
                    </button>
                  ))}
                </div>
              </div>

              {/* Selección de Integrantes Participantes */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                    <Users className="w-4 h-4 text-purple-600" />
                    <span>Seleccionar Participantes ({selectedUserIds.length} de {users.length})</span>
                  </label>
                  <button
                    type="button"
                    onClick={toggleSelectAll}
                    className="text-[11px] font-bold text-purple-700 dark:text-purple-400 hover:underline"
                  >
                    {selectedUserIds.length === users.length ? 'Deseleccionar todos' : 'Seleccionar todos'}
                  </button>
                </div>

                <div className="max-h-56 overflow-y-auto space-y-1.5 p-2 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                  {users.map((u) => {
                    const isSelected = selectedUserIds.includes(u.id);

                    return (
                      <div
                        key={u.id}
                        onClick={() => toggleUserSelection(u.id)}
                        className={`flex items-center justify-between p-2 rounded-xl cursor-pointer transition ${
                          isSelected
                            ? 'bg-purple-50 dark:bg-purple-950/50 border border-purple-200 dark:border-purple-800/60'
                            : 'hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => {}}
                            className="w-4 h-4 rounded text-purple-600"
                          />
                          <img
                            src={u.avatarUrl}
                            alt={u.name}
                            className="w-7 h-7 rounded-full object-cover shrink-0"
                          />
                          <div>
                            <span className="font-bold text-slate-900 dark:text-white block text-xs">
                              {u.name}
                            </span>
                            <span className="text-[10px] text-slate-400">
                              {u.role === 'admin' ? 'Coordinador' : 'Integrante'}
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
                <p className="text-[10px] text-slate-400 mt-1">
                  * Solo las personas marcadas entrarán en el sorteo circular.
                </p>
              </div>

              <div className="p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/50 text-[11px] text-amber-900 dark:text-amber-200 leading-relaxed">
                ✨ <strong>Garantía de Sorteo Seguro:</strong> El algoritmo crea un circuito circular perfecto (A → B → C → ... → A). Nadie se sortea a sí mismo, todos regalan a alguien diferente y nadie sabe quién le regala hasta el día de la revelación.
              </div>

              <button
                type="submit"
                disabled={selectedUserIds.length < 2}
                className="w-full py-3 rounded-2xl bg-purple-900 hover:bg-purple-800 disabled:opacity-40 text-white font-bold text-xs shadow-md transition active:scale-95 flex items-center justify-center gap-2"
              >
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>Sortear e Iniciar Nueva Dinámica ({selectedUserIds.length} participantes)</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
