export interface BannerPalette {
  id: string;
  name: string;
  description: string;
  gradientClass: string;
  borderClass: string;
  badgeAccent: string;
  badgeBg: string;
  primaryButtonClass: string;
  secondaryButtonClass: string;
  previewColors: string[];
}

export const BANNER_PALETTES: BannerPalette[] = [
  {
    id: 'azul-mariano',
    name: 'Azul Mariano Imperial',
    description: 'El azul de la Medalla Milagrosa con reflejos dorados y celestes clásicos',
    gradientClass: 'from-blue-950 via-blue-900 to-indigo-950',
    borderClass: 'border-blue-700/50',
    badgeAccent: 'text-amber-300',
    badgeBg: 'bg-amber-400/20 border-amber-300/30 text-amber-300',
    primaryButtonClass: 'bg-amber-400 hover:bg-amber-300 text-slate-950 shadow-amber-950/40',
    secondaryButtonClass: 'bg-white/10 hover:bg-white/20 text-white border-white/20',
    previewColors: ['#172554', '#1e40af', '#f59e0b'],
  },
  {
    id: 'esmeralda-esperanza',
    name: 'Esmeralda y Esperanza Vicenciana',
    description: 'Inspirada en el servicio, la vida en comunidad y la caridad renovada',
    gradientClass: 'from-emerald-950 via-teal-900 to-slate-950',
    borderClass: 'border-emerald-700/50',
    badgeAccent: 'text-emerald-300',
    badgeBg: 'bg-emerald-400/20 border-emerald-300/30 text-emerald-200',
    primaryButtonClass: 'bg-emerald-400 hover:bg-emerald-300 text-slate-950 shadow-emerald-950/40',
    secondaryButtonClass: 'bg-white/10 hover:bg-white/20 text-white border-white/20',
    previewColors: ['#064e3b', '#134e4a', '#34d399'],
  },
  {
    id: 'atardecer-misionero',
    name: 'Atardecer Misionero JMV',
    description: 'Calidez de los jóvenes en misión apostólica y fuego en el corazón',
    gradientClass: 'from-amber-950 via-orange-900 to-rose-950',
    borderClass: 'border-amber-700/50',
    badgeAccent: 'text-amber-200',
    badgeBg: 'bg-amber-400/20 border-amber-300/30 text-amber-200',
    primaryButtonClass: 'bg-amber-400 hover:bg-amber-300 text-slate-950 shadow-amber-950/40',
    secondaryButtonClass: 'bg-white/10 hover:bg-white/20 text-white border-white/20',
    previewColors: ['#451a03', '#7c2d12', '#fbbf24'],
  },
  {
    id: 'purpura-mariana',
    name: 'Púrpura y Medalla Milagrosa',
    description: 'Nobleza mariana, recogimiento espiritual y devoción a la Madre',
    gradientClass: 'from-purple-950 via-indigo-950 to-slate-950',
    borderClass: 'border-purple-700/50',
    badgeAccent: 'text-purple-200',
    badgeBg: 'bg-purple-400/20 border-purple-300/30 text-purple-200',
    primaryButtonClass: 'bg-purple-400 hover:bg-purple-300 text-slate-950 shadow-purple-950/40',
    secondaryButtonClass: 'bg-white/10 hover:bg-white/20 text-white border-white/20',
    previewColors: ['#3b0764', '#1e1b4b', '#c084fc'],
  },
  {
    id: 'rojo-sanvicente',
    name: 'Rojo Fuego de San Vicente',
    description: 'El ardor inagotable de la caridad que inflama a los jóvenes de servicio',
    gradientClass: 'from-rose-950 via-red-900 to-amber-950',
    borderClass: 'border-rose-700/50',
    badgeAccent: 'text-amber-300',
    badgeBg: 'bg-rose-400/20 border-rose-300/30 text-rose-200',
    primaryButtonClass: 'bg-amber-400 hover:bg-amber-300 text-slate-950 shadow-amber-950/40',
    secondaryButtonClass: 'bg-white/10 hover:bg-white/20 text-white border-white/20',
    previewColors: ['#4c0519', '#7f1d1d', '#fbbf24'],
  },
  {
    id: 'noche-celestial',
    name: 'Noche de Vigilia y Campamento',
    description: 'Manto estrellado nocturno con acentos celestes y destellos juveniles',
    gradientClass: 'from-slate-950 via-blue-950 to-cyan-950',
    borderClass: 'border-cyan-700/50',
    badgeAccent: 'text-cyan-300',
    badgeBg: 'bg-cyan-400/20 border-cyan-300/30 text-cyan-200',
    primaryButtonClass: 'bg-cyan-400 hover:bg-cyan-300 text-slate-950 shadow-cyan-950/40',
    secondaryButtonClass: 'bg-white/10 hover:bg-white/20 text-white border-white/20',
    previewColors: ['#020617', '#082f49', '#38bdf8'],
  },
  {
    id: 'aurora-dorada',
    name: 'Aurora Mariana de Gracia',
    description: 'Resplandor matutino celestial con destellos dorados y azul real',
    gradientClass: 'from-blue-900 via-amber-950 to-slate-950',
    borderClass: 'border-amber-600/50',
    badgeAccent: 'text-amber-300',
    badgeBg: 'bg-amber-400/20 border-amber-300/30 text-amber-200',
    primaryButtonClass: 'bg-amber-400 hover:bg-amber-300 text-slate-950 shadow-amber-950/40',
    secondaryButtonClass: 'bg-white/10 hover:bg-white/20 text-white border-white/20',
    previewColors: ['#1e3a8a', '#451a03', '#fde047'],
  },
];

export const getBannerPalette = (paletteId?: string): BannerPalette => {
  return BANNER_PALETTES.find((p) => p.id === paletteId) || BANNER_PALETTES[0];
};
