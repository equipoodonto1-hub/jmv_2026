/**
 * Modelos de datos para la aplicación JMV (Juventud Mariana Vicenciana)
 */

export type UserRole = 'admin' | 'tesorero' | 'integrante';
export type UserStatus = 'aprobado' | 'pendiente_aprobacion';

export interface GroupSummary {
  groupKey: string;
  groupName: string;
  parishName?: string;
  logoUrl?: string;
  updatedAt?: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string; // Correo electrónico de acceso
  cedula: string; // Cédula de identidad (credencial / clave personal)
  password?: string; // Clave personal de acceso (opcional, por defecto su cédula)
  groupKey?: string; // Identificador único del grupo al que pertenece
  groupName?: string; // Nombre del grupo al que pertenece
  status: UserStatus; // Aprobación requerida por el Administrador
  role: UserRole;
  isTreasurer?: boolean; // Encargado/a de economía del grupo
  avatarUrl: string;
  birthday: string; // YYYY-MM-DD
  phone?: string;
  joinedAt: string;
  points: number;
  badges: string[]; // 'constancia', 'servicio', 'alegria', 'oracion', 'fraternidad'
  imageConsentAccepted: boolean;
  isMinor?: boolean;
  tutorName?: string;
  tutorPhone?: string;
  serviceArea?: string; // Ej: 'Misión y Visitas', 'Música y Coro', 'Liturgia', 'Caridad', 'Deportes'
  spiritualQuote?: string; // Frase o intención vicenciana personal
  emergencyContact?: string;
}

export interface WeeklyChallenge {
  id: string;
  title: string;
  description: string;
  points: number;
  reward: string;
  startDate: string;
  endDate: string;
  isActive: boolean;
  createdBy: string;
}

export interface ChallengeSubmission {
  id: string;
  challengeId: string;
  userId: string;
  userName: string;
  userAvatar: string;
  submittedAt: string;
  comment?: string;
  imageUrl?: string;
  status: 'pending' | 'approved' | 'rejected';
  approvedBy?: string;
  approvedAt?: string;
}

export interface FeeWeek {
  id: string;
  weekNumber: number;
  title: string; // Ej: "Semana 1 - Aporte inicial", "Semana 8"
  date: string;
  amount: number; // Por defecto 1 USD
}

export interface FeeCampaign {
  id: string;
  title: string; // Ej: "Venta de Empanadas", "Venta de Polladas Pro-Retiro", "Venta de Postres"
  description?: string;
  type: 'venta' | 'extraordinaria' | 'semanal';
  unitLabel: string; // Ej: "empanada", "plato", "boleto", "porción", "cuota"
  unitPrice: number; // Precio por unidad vendida (USD)
  targetGoal: number; // Meta en USD (ej: 150)
  investmentPerPerson?: number; // Inversión inicial por integrante (ej: $2.00 para ingredientes)
  totalUnitsSold?: number; // Unidades totales vendidas
  grossRevenue?: number; // Recaudación bruta de ventas
  ingredientCosts?: number; // Gastos reales en insumos comprados
  deadline?: string;
  createdAt: string;
  isActive: boolean;
  createdBy: string;
}

export interface FeePayment {
  id: string;
  campaignId?: string; // ID de campaña si es una venta o cuota extraordinaria (por defecto cuota semanal)
  userId: string;
  userName: string;
  weekId?: string;
  weekNumber?: number;
  paymentType?: 'cuota_semanal' | 'inversion' | 'venta'; // Inversión inicial ($2) o recaudación por venta
  quantity?: number; // Para ventas: cantidad de unidades vendidas (ej. 10 empanadas)
  amount: number;
  status: 'pagado' | 'pendiente';
  paidAt?: string;
  registeredBy?: string;
  note?: string;
}

export interface ActivityExpense {
  id: string;
  title: string; // Ej: "Refrigerios y bebidas para la Jornada Misionera"
  description?: string;
  activityId?: string; // ID de la actividad del calendario (opcional)
  activityTitle?: string;
  amount: number; // Monto en USD (ej: 18.50)
  date: string; // YYYY-MM-DD
  category: 'refrigerio' | 'materiales' | 'transporte' | 'espiritualidad' | 'solidaridad' | 'otro';
  receiptUrl?: string; // Foto o comprobante comprimido
  registeredBy: string;
  registeredById: string;
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  userRole: UserRole;
  text: string;
  imageUrl?: string;
  createdAt: string;
  isPinned?: boolean;
  pinnedBy?: string;
  reactions?: Record<string, string[]>; // emoji -> array of userIds
  isReported?: boolean;
  reportCount?: number;
}

export interface ActivityEvent {
  id: string;
  title: string;
  description: string;
  type: 'reunion' | 'retiro' | 'servicio' | 'evento';
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  location: string;
  attendees: {
    userId: string;
    userName: string;
    userAvatar: string;
    status: 'voy' | 'no_voy' | 'tal_vez';
  }[];
  createdBy: string;
}

export interface ServiceExperience {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  title: string;
  description: string;
  location?: string;
  date: string;
  imageUrl?: string;
  likes: string[]; // userIds
  reactions: {
    oracion: number;
    amor: number;
    inspirador: number;
  };
  comments: {
    id: string;
    userId: string;
    userName: string;
    userAvatar: string;
    text: string;
    createdAt: string;
  }[];
}

export interface PhotoAlbum {
  id: string;
  title: string;
  description?: string;
  coverUrl: string;
  date: string;
  photoCount: number;
}

export interface PhotoItem {
  id: string;
  albumId: string;
  url: string;
  caption?: string;
  uploadedBy: string;
  uploadedByName: string;
  uploadedAt: string;
  likes: string[]; // userIds
  comments: {
    id: string;
    userId: string;
    userName: string;
    text: string;
    createdAt: string;
  }[];
}

export interface SecretFriendRound {
  id: string;
  title: string;
  startDate: string;
  revealDate: string;
  status: 'active' | 'revealed';
  assignments: {
    giverId: string; // Quién regala
    receiverId: string; // A quién le regala
  }[];
}

export interface SecretMessage {
  id: string;
  roundId: string;
  giverId: string;
  receiverId: string;
  dayNumber: number; // 1..7
  text: string;
  sentAt: string;
}

export interface PrayerRequest {
  id: string;
  userId: string;
  userName: string; // o "Anónimo"
  isAnonymous: boolean;
  type: 'peticion' | 'agradecimiento';
  title: string;
  description: string;
  createdAt: string;
  prayerCount: number;
  prayedBy: string[]; // userIds
}

export interface MeetingReminder {
  id: string;
  title: string;
  message: string;
  scheduledFor: string;
  isSent: boolean;
  isActive: boolean;
}

export interface AttendanceSession {
  id: string;
  title: string;
  date: string;
  records: {
    userId: string;
    userName: string;
    status: 'presente' | 'justificado' | 'ausente';
  }[];
}

export interface Poll {
  id: string;
  question: string;
  options: {
    id: string;
    text: string;
    votes: string[]; // userIds
  }[];
  createdBy: string;
  createdAt: string;
  expiresAt: string;
  isClosed?: boolean;
}

export interface AdvisorReflection {
  id: string;
  advisorName: string;
  advisorTitle: string;
  title: string;
  content: string;
  date: string;
  imageUrl?: string;
}

export interface PasswordRecoveryRequest {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  requestedAt: string;
  status: 'pending' | 'resolved';
}
