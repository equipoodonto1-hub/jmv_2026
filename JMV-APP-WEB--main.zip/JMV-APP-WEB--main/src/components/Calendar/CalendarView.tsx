import React, { useState } from 'react';
import {
  Calendar as CalendarIcon,
  Clock,
  MapPin,
  Plus,
  Users,
  CheckCircle,
  XCircle,
  HelpCircle,
  X,
  FileSpreadsheet,
  Upload,
  Sparkles,
  FileText,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ActivityEvent } from '../../types';

export const CalendarView: React.FC = () => {
  const { activities, createActivity, bulkCreateActivities, rsvpActivity, currentUser, users, isAdmin } =
    useApp();

  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showBulkModal, setShowBulkModal] = useState(false);

  // Formulario individual
  const [newTitle, setNewTitle] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newType, setNewType] = useState<ActivityEvent['type']>('reunion');
  const [newDate, setNewDate] = useState(
    new Date(Date.now() + 3 * 86400000).toISOString().split('T')[0]
  );
  const [newTime, setNewTime] = useState('17:00 - 19:00');
  const [newLocation, setNewLocation] = useState('Salón Parroquial San Vicente');

  // Carga masiva
  const defaultCsvTemplate = `2026-11-21, 17:00 - 19:00, Taller de Liderazgo y Oratoria Vicenciana, reunion, Salón Parroquial, Herramientas para coordinar dinámicas y cantos
2026-11-28, 09:00 - 13:00, Jornada Misionera en Barrio Santa Luisa, servicio, Punto de encuentro: Atrio, Visita y acompañamiento a familias
2026-12-05, 17:00 - 19:00, Rosario Iluminado por la Juventud, retiro, Patio Parroquial, Oración con antorchas y velas por las intenciones del grupo
2026-12-12, 16:00 - 19:30, Festival Deportivo y Convivencia Mariana, evento, Canchas parroquiales, Torneo de vóley y compartir fraterno
2026-12-19, 17:00 - 20:00, Celebración de Navidad Vicenciana y Amigo Secreto, evento, Salón Parroquial, Compartir navideño y revelación de amigos secretos`;

  const [csvText, setCsvText] = useState(defaultCsvTemplate);
  const [parsedPreview, setParsedPreview] = useState<
    Omit<ActivityEvent, 'id' | 'attendees' | 'createdBy'>[]
  >([]);

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    createActivity({
      title: newTitle.trim(),
      description: newDescription.trim(),
      type: newType,
      date: newDate,
      time: newTime.trim(),
      location: newLocation.trim(),
    });

    setNewTitle('');
    setNewDescription('');
    setShowCreateModal(false);
  };

  // Analizar texto CSV
  const parseCsvText = (text: string) => {
    const lines = text.split('\n').filter((l) => l.trim().length > 0);
    const parsed: Omit<ActivityEvent, 'id' | 'attendees' | 'createdBy'>[] = [];

    lines.forEach((line) => {
      const parts = line.split(',').map((p) => p.trim());
      if (parts.length >= 3) {
        const rawDate = parts[0];
        const rawTime = parts[1] || '17:00 - 19:00';
        const rawTitle = parts[2];
        const rawType = (['reunion', 'servicio', 'retiro', 'evento'].includes(parts[3])
          ? parts[3]
          : 'reunion') as ActivityEvent['type'];
        const rawLoc = parts[4] || 'Salón Parroquial San Vicente';
        const rawDesc = parts[5] || 'Actividad comunitaria de JMV';

        parsed.push({
          title: rawTitle,
          date: rawDate,
          time: rawTime,
          type: rawType,
          location: rawLoc,
          description: rawDesc,
        });
      }
    });

    return parsed;
  };

  // Generar plantilla de 6 sábados automáticos
  const handleGenerateSemesterTemplate = () => {
    const sampleTopics = [
      { title: 'Reunión Formativa: La Medalla Milagrosa y la Fe Juvenil', type: 'reunion' as const },
      { title: 'Jornada Solidaria: Comedor Popular Santa Luisa', type: 'servicio' as const },
      { title: 'Taller de Cantos y Formación de Acólitos/Lectores', type: 'reunion' as const },
      { title: 'Vigilia Juvenil bajo las Estrellas y Fogata', type: 'retiro' as const },
      { title: 'Tarde Deportiva y Dinámicas de Integración', type: 'evento' as const },
      { title: 'Misión Vicenciana: Visita a Familias del Sector', type: 'servicio' as const },
    ];

    const generated: Omit<ActivityEvent, 'id' | 'attendees' | 'createdBy'>[] = [];
    const baseDate = new Date();

    sampleTopics.forEach((t, i) => {
      const d = new Date(baseDate);
      d.setDate(d.getDate() + (i + 1) * 7); // Cada sábado siguiente
      generated.push({
        title: t.title,
        date: d.toISOString().split('T')[0],
        time: '17:00 - 19:00',
        type: t.type,
        location: 'Salón Parroquial San Vicente',
        description: 'Actividad oficial del cronograma del grupo juvenil.',
      });
    });

    bulkCreateActivities(generated);
    setShowBulkModal(false);
    alert(`¡Se crearon exitosamente ${generated.length} actividades en el calendario!`);
  };

  const handleImportParsed = () => {
    const events = parseCsvText(csvText);
    if (events.length === 0) {
      alert('No se encontraron actividades con formato válido. Revisa las líneas ingresadas.');
      return;
    }

    bulkCreateActivities(events);
    setShowBulkModal(false);
    alert(`¡Se importaron ${events.length} actividades al calendario exitosamente!`);
  };

  const getTypeBadge = (type: ActivityEvent['type']) => {
    switch (type) {
      case 'reunion':
        return { label: 'Reunión Semanal', bg: 'bg-blue-100 dark:bg-blue-950/60 text-blue-800 dark:text-blue-300' };
      case 'servicio':
        return { label: 'Jornada Solidaria', bg: 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300' };
      case 'retiro':
        return { label: 'Retiro Espiritual', bg: 'bg-purple-100 dark:bg-purple-950/60 text-purple-800 dark:text-purple-300' };
      default:
        return { label: 'Evento', bg: 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300' };
    }
  };

  return (
    <div className="space-y-6 pb-20 animate-in fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400">
              <CalendarIcon className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
              Calendario de Actividades del Mes
            </h1>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Reuniones formativas, retiros, jornadas de servicio vicenciano y eventos comunitarios.
          </p>
        </div>

        {isAdmin && (
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setShowBulkModal(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-2xl border border-blue-200 dark:border-blue-900/60 bg-blue-50 dark:bg-blue-950/40 text-blue-800 dark:text-blue-300 hover:bg-blue-100 text-xs font-bold transition shadow-sm"
              title="Cargar múltiples actividades a la vez o generar cronograma automático"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>Carga Masiva de Eventos</span>
            </button>

            <button
              onClick={() => setShowCreateModal(true)}
              className="flex items-center gap-2 px-4 py-2 rounded-2xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow-md transition active:scale-95 shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>Nueva Actividad</span>
            </button>
          </div>
        )}
      </div>

      {/* Lista de eventos */}
      <div className="space-y-4">
        {activities.map((act) => {
          const typeBadge = getTypeBadge(act.type);
          const myRsvp = act.attendees.find((a) => a.userId === currentUser.id);
          const goingAttendees = act.attendees.filter((a) => a.status === 'voy');

          return (
            <div
              key={act.id}
              className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm transition hover:border-slate-300"
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${typeBadge.bg}`}>
                      {typeBadge.label}
                    </span>
                    <span className="text-xs font-semibold text-slate-500">
                      {new Date(act.date).toLocaleDateString('es-ES', {
                        weekday: 'long',
                        day: 'numeric',
                        month: 'long',
                      })}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    {act.title}
                  </h3>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed max-w-2xl">
                    {act.description}
                  </p>

                  <div className="pt-2 flex flex-wrap items-center gap-4 text-xs text-slate-500">
                    <span className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-blue-600" />
                      {act.time}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-red-500" />
                      {act.location}
                    </span>
                  </div>
                </div>

                {/* Control de confirmación de asistencia RSVP */}
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 shrink-0">
                  <span className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1.5 text-center">
                    ¿Asistirás?
                  </span>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => rsvpActivity(act.id, 'voy')}
                      className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                        myRsvp?.status === 'voy'
                          ? 'bg-emerald-600 text-white shadow-sm'
                          : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 border'
                      }`}
                    >
                      <CheckCircle className="w-3.5 h-3.5" />
                      Voy
                    </button>
                    <button
                      onClick={() => rsvpActivity(act.id, 'tal_vez')}
                      className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                        myRsvp?.status === 'tal_vez'
                          ? 'bg-amber-500 text-slate-950 shadow-sm'
                          : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 border'
                      }`}
                    >
                      <HelpCircle className="w-3.5 h-3.5" />
                      Tal vez
                    </button>
                    <button
                      onClick={() => rsvpActivity(act.id, 'no_voy')}
                      className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                        myRsvp?.status === 'no_voy'
                          ? 'bg-slate-700 text-white shadow-sm'
                          : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 border'
                      }`}
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      No voy
                    </button>
                  </div>
                </div>
              </div>

              {/* Lista visual de asistentes confirmados */}
              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="flex -space-x-2 overflow-hidden">
                    {goingAttendees.slice(0, 6).map((att) => {
                      const liveAttendee = users.find((u) => u.id === att.userId);
                      const attAvatar = liveAttendee?.avatarUrl || att.userAvatar;
                      const attName = liveAttendee?.name || att.userName;
                      return (
                        <img
                          key={att.userId}
                          src={attAvatar}
                          alt={attName}
                          title={`${attName} asistirá`}
                          className="inline-block w-7 h-7 rounded-full ring-2 ring-white dark:ring-slate-900 object-cover"
                        />
                      );
                    })}
                  </div>
                  <span className="text-xs text-slate-500">
                    <strong>{goingAttendees.length}</strong> confirmados
                  </span>
                </div>

                <span className="text-[11px] text-slate-400">
                  Organizado por {act.createdBy}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal para Carga Masiva de Eventos */}
      {showBulkModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="w-full max-w-xl rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 animate-in fade-in my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-blue-900 text-white flex items-center justify-center font-bold text-xs">
                  <FileSpreadsheet className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                    Carga Masiva de Eventos al Calendario
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Importa cronogramas completos por lista o genera sábados automáticos
                  </p>
                </div>
              </div>
              <button onClick={() => setShowBulkModal(false)} className="text-slate-400">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="mt-4 space-y-4 text-xs">
              {/* Opción 1: Generador automático de sábados */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-900 via-indigo-900 to-blue-950 text-white shadow flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <span className="text-[10px] uppercase font-bold text-amber-400 flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5" /> Generador Rápido de Semestre
                  </span>
                  <h4 className="font-bold text-sm text-white mt-0.5">
                    Cronograma de los Próximos 6 Sábados
                  </h4>
                  <p className="text-[11px] text-blue-200 mt-0.5">
                    Crea automáticamente 6 reuniones sabatinas con temas vicencianos y servicios.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleGenerateSemesterTemplate}
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shrink-0 transition"
                >
                  Generar 6 Sábados
                </button>
              </div>

              {/* Opción 2: Pegar o Editar Formato Texto / CSV */}
              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-blue-600" />
                  O pega tu lista en formato CSV (1 actividad por línea):
                </label>
                <p className="text-[10px] text-slate-400 mb-2">
                  Formato: <code>AAAA-MM-DD, Horario, Título, Tipo (reunion/servicio/retiro/evento), Lugar, Descripción</code>
                </p>
                <textarea
                  rows={6}
                  value={csvText}
                  onChange={(e) => setCsvText(e.target.value)}
                  className="w-full p-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-[11px] font-mono leading-relaxed outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              {/* Vista previa de lo que se va a importar */}
              <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Vista Previa ({parseCsvText(csvText).length} eventos detectados):
                </span>
                <div className="max-h-36 overflow-y-auto space-y-1.5 text-[11px] text-slate-600 dark:text-slate-300">
                  {parseCsvText(csvText).map((ev, i) => (
                    <div key={i} className="flex items-center justify-between py-1 border-b border-slate-200 dark:border-slate-700">
                      <span className="font-semibold text-slate-900 dark:text-white truncate mr-2">
                        {ev.date} · {ev.title}
                      </span>
                      <span className="capitalize text-[10px] px-1.5 rounded bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300 shrink-0">
                        {ev.type}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowBulkModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 hover:bg-slate-50 text-xs font-semibold"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleImportParsed}
                  className="px-5 py-2 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow transition active:scale-95"
                >
                  Importar Actividades ({parseCsvText(csvText).length})
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal para crear actividad individual */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 animate-in fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                Nueva Actividad en el Calendario
              </h3>
              <button onClick={() => setShowCreateModal(false)} className="text-slate-400">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Título de la actividad *
                </label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="Ej: Retiro Espiritual Mariano"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Tipo de actividad
                </label>
                <select
                  value={newType}
                  onChange={(e) => setNewType(e.target.value as any)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                >
                  <option value="reunion">Reunión Semanal</option>
                  <option value="servicio">Jornada de Servicio</option>
                  <option value="retiro">Retiro Espiritual</option>
                  <option value="evento">Evento Especial / Fiesta</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Fecha *
                  </label>
                  <input
                    type="date"
                    required
                    value={newDate}
                    onChange={(e) => setNewDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Horario
                  </label>
                  <input
                    type="text"
                    value={newTime}
                    onChange={(e) => setNewTime(e.target.value)}
                    placeholder="17:00 - 19:00"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Lugar o punto de encuentro *
                </label>
                <input
                  type="text"
                  required
                  value={newLocation}
                  onChange={(e) => setNewLocation(e.target.value)}
                  placeholder="Ej: Salón Parroquial San Vicente"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Descripción o materiales a llevar
                </label>
                <textarea
                  rows={3}
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  placeholder="Detalles de la reunión..."
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow mt-2"
              >
                Guardar en el Calendario
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
