import React, { useState } from 'react';
import {
  Heart,
  Plus,
  HandHelping,
  Sparkles,
  Camera,
  MapPin,
  MessageSquare,
  X,
  Upload,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { compressImage } from '../../services/imageCompression';

export const ServiceWallView: React.FC = () => {
  const { serviceExperiences, addServiceExperience, reactToService, addServiceComment, users } = useApp();

  const [showAddModal, setShowAddModal] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [isCompressing, setIsCompressing] = useState(false);
  const [commentInput, setCommentInput] = useState<Record<string, string>>({});

  const handleImageFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsCompressing(true);
      const res = await compressImage(file, { maxWidth: 900, maxHeight: 900, quality: 0.8 });
      setImageUrl(res.dataUrl);
    } catch (err) {
      console.error(err);
    } finally {
      setIsCompressing(false);
    }
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) return;

    addServiceExperience({
      title: title.trim(),
      description: description.trim(),
      location: location.trim() || undefined,
      date: new Date().toISOString().split('T')[0],
      imageUrl: imageUrl || undefined,
    });

    setTitle('');
    setDescription('');
    setLocation('');
    setImageUrl('');
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6 pb-20 animate-in fade-in">
      {/* Encabezado */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
              <HandHelping className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
              Muro de Experiencias de Servicio
            </h1>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Testimonios y reflexiones de la caridad vicenciana vivida en comedores, asilos y comunidades.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow-md transition active:scale-95 shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Compartir Testimonio</span>
        </button>
      </div>

      {/* Lista de experiencias */}
      <div className="space-y-6">
        {serviceExperiences.map((exp) => {
          const expAuthor = users.find((u) => u.id === exp.userId);
          const expAvatar = expAuthor?.avatarUrl || exp.userAvatar;
          const expName = expAuthor?.name || exp.userName;
          return (
          <div
            key={exp.id}
            className="p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4"
          >
            {/* Cabecera del autor */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img
                  src={expAvatar}
                  alt={expName}
                  className="w-10 h-10 rounded-full object-cover ring-2 ring-slate-200 dark:ring-slate-700"
                />
                <div>
                  <h3 className="text-xs font-bold text-slate-900 dark:text-white">
                    {expName}
                  </h3>
                  <div className="flex items-center gap-2 text-[10px] text-slate-400">
                    <span>
                      {new Date(exp.date).toLocaleDateString('es-ES', {
                        day: 'numeric',
                        month: 'long',
                        year: 'numeric',
                      })}
                    </span>
                    {exp.location && (
                      <>
                        <span>·</span>
                        <span className="flex items-center gap-0.5">
                          <MapPin className="w-3 h-3 text-red-500" />
                          {exp.location}
                        </span>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Título y descripción */}
            <div>
              <h2 className="text-base font-extrabold text-slate-900 dark:text-white">
                {exp.title}
              </h2>
              <p className="mt-2 text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-wrap">
                {exp.description}
              </p>
            </div>

            {/* Foto si existe */}
            {exp.imageUrl && (
              <div className="rounded-3xl overflow-hidden max-h-96 bg-slate-100 dark:bg-slate-800 border border-slate-100 dark:border-slate-800">
                <img
                  src={exp.imageUrl}
                  alt={exp.title}
                  className="w-full h-full object-cover"
                />
              </div>
            )}

            {/* Barra de Reacciones Vicencianas */}
            <div className="pt-2 flex flex-wrap items-center gap-2 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => reactToService(exp.id, 'amor')}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-pink-50 dark:bg-pink-950/40 text-pink-700 dark:text-pink-300 hover:bg-pink-100 text-xs font-bold transition active:scale-95"
              >
                <span>❤️ Caridad</span>
                <span className="tabular-nums font-extrabold">{exp.reactions.amor}</span>
              </button>

              <button
                onClick={() => reactToService(exp.id, 'oracion')}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 hover:bg-blue-100 text-xs font-bold transition active:scale-95"
              >
                <span>🙏 Oración</span>
                <span className="tabular-nums font-extrabold">{exp.reactions.oracion}</span>
              </button>

              <button
                onClick={() => reactToService(exp.id, 'inspirador')}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 hover:bg-amber-100 text-xs font-bold transition active:scale-95"
              >
                <span>✨ Inspirador</span>
                <span className="tabular-nums font-extrabold">{exp.reactions.inspirador}</span>
              </button>
            </div>

            {/* Comentarios fraternos */}
            <div className="space-y-2 pt-2">
              {exp.comments.map((c) => {
                const cAuthor = users.find((u) => u.id === c.userId);
                const cAvatar = cAuthor?.avatarUrl || c.userAvatar;
                const cName = cAuthor?.name || c.userName;
                return (
                  <div key={c.id} className="p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 text-xs">
                    <div className="flex items-center gap-2 mb-1">
                      <img src={cAvatar} alt={cName} className="w-5 h-5 rounded-full object-cover" />
                      <span className="font-bold text-slate-800 dark:text-slate-200">{cName}</span>
                    </div>
                    <p className="text-slate-600 dark:text-slate-300 pl-7">{c.text}</p>
                  </div>
                );
              })}

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="text"
                  value={commentInput[exp.id] || ''}
                  onChange={(e) =>
                    setCommentInput({ ...commentInput, [exp.id]: e.target.value })
                  }
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      addServiceComment(exp.id, commentInput[exp.id] || '');
                      setCommentInput({ ...commentInput, [exp.id]: '' });
                    }
                  }}
                  placeholder="Escribe una palabra de aliento..."
                  className="flex-1 px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs outline-none"
                />
                <button
                  onClick={() => {
                    addServiceComment(exp.id, commentInput[exp.id] || '');
                    setCommentInput({ ...commentInput, [exp.id]: '' });
                  }}
                  className="px-3 py-2 rounded-xl bg-blue-900 text-white font-bold text-xs"
                >
                  Comentar
                </button>
              </div>
            </div>
          </div>
          );
        })}
      </div>

      {/* Modal: Compartir testimonio */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 animate-in fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                Compartir Experiencia de Servicio
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Título del testimonio *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Ej: Visita al asilo de ancianos"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Lugar
                </label>
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="Ej: Comedor Parroquial"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Tu testimonio o reflexión *
                </label>
                <textarea
                  rows={4}
                  required
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="¿Qué aprendiste sirviendo? ¿Cómo viste el rostro de Cristo en los demás?..."
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white leading-relaxed"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Foto (opcional, comprimida para internet lento)
                </label>
                {imageUrl ? (
                  <div className="relative rounded-2xl overflow-hidden h-36 bg-slate-100">
                    <img src={imageUrl} alt="Preview" className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => setImageUrl('')}
                      className="absolute top-2 right-2 p-1 rounded-full bg-black/60 text-white"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <label className="cursor-pointer border-2 border-dashed border-slate-200 dark:border-slate-700 hover:border-blue-500 rounded-2xl p-4 flex flex-col items-center justify-center gap-1.5 transition text-slate-500">
                    <Camera className="w-6 h-6 text-slate-400" />
                    <span className="font-semibold">
                      {isCompressing ? 'Comprimiendo imagen...' : 'Seleccionar foto'}
                    </span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageFile}
                      className="hidden"
                    />
                  </label>
                )}
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow mt-2"
              >
                Publicar en el Muro
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
