import React, { useState, useEffect } from 'react';
import {
  X,
  Heart,
  User,
  Calendar,
  Phone,
  Key,
  Upload,
  Camera,
  Mail,
  CreditCard,
  Lock,
  CheckCircle2,
  AlertCircle,
  LogIn,
  UserPlus,
  Eye,
  EyeOff,
  ShieldCheck,
  ArrowLeft,
  HelpCircle,
  Send,
  Clock,
  Users,
  PlusCircle,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { compressAvatarImage } from '../../services/imageCompression';
import marianMedalImg from '../../assets/images/jmv_marian_medal_1794117311829.jpg';

export const AuthModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'login' | 'register';
  isFullScreenGate?: boolean;
}> = ({ isOpen, onClose, initialMode = 'login', isFullScreenGate = false }) => {
  const {
    loginWithCredentials,
    registerMember,
    createGroupWorkspace,
    requestPasswordReminder,
    verifyCedulaAndRecoverPassword,
    settings,
    activeGroupKey,
    availableGroups,
    switchGroup,
  } = useApp();

  const [mode, setMode] = useState<'login' | 'register' | 'recover' | 'create-group'>(initialMode);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Estados de Login
  const [loginGroupKey, setLoginGroupKey] = useState<string>('auto');
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Estados de Recuperar / Recordar Contraseña
  const [recoverEmail, setRecoverEmail] = useState('');
  const [recoverCedula, setRecoverCedula] = useState('');
  const [recoverNewPassword, setRecoverNewPassword] = useState('');
  const [isRecovering, setIsRecovering] = useState(false);
  const [recoverStep, setRecoverStep] = useState<'email' | 'verify_cedula' | 'done'>('email');
  const [recoveredPassDisplay, setRecoveredPassDisplay] = useState('');
  const [recoveredEmailDisplay, setRecoveredEmailDisplay] = useState('');

  // Estados de Registro
  const [regGroupSelection, setRegGroupSelection] = useState<string>(activeGroupKey);
  const [regCustomGroupName, setRegCustomGroupName] = useState<string>('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [cedula, setCedula] = useState('');
  const [password, setPassword] = useState('');
  const [showRegPassword, setShowRegPassword] = useState(false);
  const [birthday, setBirthday] = useState('');
  const [phone, setPhone] = useState('');
  const [invitationCode, setInvitationCode] = useState('');
  const [avatarPreview, setAvatarPreview] = useState<string>('');
  const [imageConsent, setImageConsent] = useState(false);
  const [isMinor, setIsMinor] = useState(false);
  const [tutorName, setTutorName] = useState('');
  const [tutorPhone, setTutorPhone] = useState('');
  const [serviceArea] = useState('Misión y Visitas');
  const [isCompressing, setIsCompressing] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const [pendingRequestInfo, setPendingRequestInfo] = useState<{
    name: string;
    email: string;
    groupName?: string;
  } | null>(null);

  // Estados de Crear Nuevo Grupo Independiente
  const [newGroupName, setNewGroupName] = useState('');
  const [newParishName, setNewParishName] = useState('');
  const [newGroupCode, setNewGroupCode] = useState('');
  const [coordName, setCoordName] = useState('');
  const [coordEmail, setCoordEmail] = useState('');
  const [coordCedula, setCoordCedula] = useState('');
  const [coordPassword, setCoordPassword] = useState('');
  const [isCreatingGroup, setIsCreatingGroup] = useState(false);

  useEffect(() => {
    if (isOpen || isFullScreenGate) {
      setMode(initialMode);
      setErrorMsg('');
      setSuccessMsg('');
      setRecoverStep('email');
      setRecoveredPassDisplay('');
      setPendingRequestInfo(null);
      setRegGroupSelection(activeGroupKey);
    }
  }, [isOpen, initialMode, isFullScreenGate, activeGroupKey]);

  if (!isOpen && !isFullScreenGate) return null;

  const resetForms = () => {
    setLoginIdentifier('');
    setLoginPassword('');
    setName('');
    setEmail('');
    setCedula('');
    setPassword('');
    setBirthday('');
    setPhone('');
    setInvitationCode('');
    setAvatarPreview('');
    setImageConsent(false);
    setIsMinor(false);
    setTutorName('');
    setTutorPhone('');
    setRegCustomGroupName('');
    setNewGroupName('');
    setNewParishName('');
    setNewGroupCode('');
    setCoordName('');
    setCoordEmail('');
    setCoordCedula('');
    setCoordPassword('');
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!loginIdentifier.trim()) {
      setErrorMsg('Por favor ingresa tu correo electrónico o número de cédula.');
      return;
    }
    if (!loginPassword.trim()) {
      setErrorMsg('Por favor ingresa tu cédula o contraseña de acceso.');
      return;
    }

    setIsLoggingIn(true);
    try {
      const res = await loginWithCredentials(loginIdentifier, loginPassword, loginGroupKey);
      if (!res.success) {
        setErrorMsg(res.error || 'Credenciales inválidas.');
      } else {
        setSuccessMsg(`¡Bienvenido/a, ${res.user?.name}!`);
        resetForms();
        if (!isFullScreenGate) {
          onClose();
        }
      }
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleAvatarFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setErrorMsg('');
    try {
      setIsCompressing(true);
      const dataUrl = await compressAvatarImage(file);
      setAvatarPreview(dataUrl);
    } catch (err) {
      console.error(err);
      setErrorMsg('No se pudo procesar la foto elegida. Prueba con una imagen JPG o PNG.');
    } finally {
      setIsCompressing(false);
      e.target.value = '';
    }
  };

  const handleBirthdayChange = (val: string) => {
    setBirthday(val);
    if (val) {
      const birth = new Date(val);
      const ageDifMs = Date.now() - birth.getTime();
      const ageDate = new Date(ageDifMs);
      const calculatedAge = Math.abs(ageDate.getUTCFullYear() - 1970);
      setIsMinor(calculatedAge < 18);
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    const isCustomGroup = regGroupSelection === '__custom__';
    if (isCustomGroup && !regCustomGroupName.trim()) {
      setErrorMsg('Ingresa el nombre exacto del grupo JMV al que deseas registrarte.');
      return;
    }
    const selectedGroupObj = availableGroups.find((g) => g.groupKey === regGroupSelection);

    if (isMinor && (!tutorName.trim() || !tutorPhone.trim())) {
      setErrorMsg('Al ser menor de edad, se requiere el nombre y teléfono del padre, madre o apoderado.');
      return;
    }

    setIsRegistering(true);
    try {
      const res = await registerMember({
        name: name.trim(),
        email: email.trim(),
        cedula: cedula.trim(),
        password: password.trim() || cedula.trim(),
        birthday,
        phone: phone.trim() || undefined,
        invitationCode: invitationCode.replace(/[\s\u200B-\u200D\uFEFF]/g, '').toUpperCase(),
        groupKey: isCustomGroup ? undefined : regGroupSelection,
        groupName: isCustomGroup ? regCustomGroupName.trim() : selectedGroupObj?.groupName || settings.groupName,
        avatarUrl: avatarPreview || undefined,
        imageConsentAccepted: imageConsent,
        isMinor,
        tutorName: isMinor ? tutorName.trim() : undefined,
        tutorPhone: isMinor ? tutorPhone.trim() : undefined,
        serviceArea,
      });

      if (!res.success) {
        setErrorMsg(res.error || 'No se pudo completar el registro.');
      } else if (res.pendingApproval) {
        setPendingRequestInfo({
          name: res.userName || name.trim(),
          email: email.trim().toLowerCase(),
          groupName: res.groupName || selectedGroupObj?.groupName || settings.groupName,
        });
        setSuccessMsg(
          `¡Solicitud enviada al Administrador de "${res.groupName || settings.groupName}"! Solo podrás ingresar cuando autorice tu inscripción.`
        );
        resetForms();
      } else {
        setSuccessMsg('¡Registro completado!');
        resetForms();
        if (!isFullScreenGate) {
          onClose();
        }
      }
    } finally {
      setIsRegistering(false);
    }
  };

  const handleCreateGroupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setIsCreatingGroup(true);
    try {
      const res = await createGroupWorkspace({
        groupName: newGroupName,
        parishName: newParishName,
        invitationCode: newGroupCode.replace(/[\s\u200B-\u200D\uFEFF]/g, '').toUpperCase(),
        coordinatorName: coordName,
        coordinatorEmail: coordEmail,
        coordinatorCedula: coordCedula,
        coordinatorPassword: coordPassword || coordCedula,
      });
      if (!res.success) {
        setErrorMsg(res.error || 'No se pudo crear el espacio del grupo.');
      } else {
        resetForms();
        if (!isFullScreenGate) {
          onClose();
        }
      }
    } finally {
      setIsCreatingGroup(false);
    }
  };

  const handleSendReminder = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setIsRecovering(true);
    try {
      const res = await requestPasswordReminder(recoverEmail);
      if (!res.found) {
        setErrorMsg(res.message);
        return;
      }
      setRecoveredEmailDisplay(res.userEmail || recoverEmail.trim());
      if (res.sentViaEmail) {
        setSuccessMsg(res.message);
        setRecoverStep('done');
      } else {
        setSuccessMsg(res.message);
        setRecoverStep('verify_cedula');
      }
    } finally {
      setIsRecovering(false);
    }
  };

  const handleVerifyCedulaRecover = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setIsRecovering(true);
    try {
      const res = await verifyCedulaAndRecoverPassword(
        recoveredEmailDisplay || recoverEmail,
        recoverCedula,
        recoverNewPassword
      );
      if (!res.success) {
        setErrorMsg(res.error || 'No se pudo verificar la cédula.');
        return;
      }
      setRecoveredPassDisplay(res.recoveredPassword || '');
      setRecoveredEmailDisplay(res.userEmail || recoverEmail.trim());
      setSuccessMsg(
        recoverNewPassword.trim()
          ? `¡Contraseña actualizada para ${res.userName}! Ya puedes ingresar.`
          : `¡Identidad verificada, ${res.userName}! Aquí tienes tu contraseña actual.`
      );
      setRecoverStep('done');
    } finally {
      setIsRecovering(false);
    }
  };

  const wrapperClass = isFullScreenGate
    ? 'min-h-screen w-full flex flex-col items-center justify-center bg-gradient-to-br from-blue-950 via-slate-900 to-indigo-950 p-4 overflow-y-auto'
    : 'fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto';

  return (
    <div className={wrapperClass}>
      {isFullScreenGate && (
        <div className="mb-4 text-center text-white space-y-2 animate-in fade-in max-w-md px-2">
          <div className="w-20 h-20 mx-auto rounded-2xl overflow-hidden ring-2 ring-amber-400 bg-white p-1.5 shadow-xl flex items-center justify-center">
            <img
              src={settings.logoUrl || marianMedalImg}
              alt={settings.groupName}
              className="w-full h-full object-contain rounded-xl"
              referrerPolicy="no-referrer"
            />
          </div>
          <h1 className="text-xl font-extrabold tracking-tight">{settings.groupName}</h1>
          <p className="text-xs text-amber-300 font-semibold">
            {settings.parishName || 'Juventud Mariana Vicenciana'} · "A Jesús por María"
          </p>
        </div>
      )}

      <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 my-2 animate-in fade-in zoom-in-95">
        {/* Cabecera del Modal */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-white ring-1 ring-amber-400/70 p-0.5 shrink-0 shadow-sm flex items-center justify-center overflow-hidden">
              <img
                src={settings.logoUrl || marianMedalImg}
                alt={settings.groupName}
                className="w-full h-full object-contain rounded-xl"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="min-w-0">
              <h2 className="text-base font-extrabold text-slate-900 dark:text-white truncate">
                {mode === 'login'
                  ? `Acceso · ${settings.groupName}`
                  : mode === 'register'
                  ? 'Registro en Grupo JMV'
                  : mode === 'create-group'
                  ? 'Crear Nuevo Grupo JMV'
                  : `Recordar Clave · ${settings.groupName}`}
              </h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                {mode === 'login'
                  ? `${settings.parishName || 'Comunidad'} · Datos privados por grupo`
                  : mode === 'register'
                  ? 'Elige tu grupo e ingresa el código privado'
                  : mode === 'create-group'
                  ? 'Espacio independiente con sus propios integrantes'
                  : `${settings.parishName || 'Comunidad'} · Recuperación de acceso`}
              </p>
            </div>
          </div>
          {!isFullScreenGate && (
            <button
              type="button"
              onClick={onClose}
              aria-label="Cerrar ventana"
              className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Pestañas Iniciar Sesión / Registrarme / Nuevo Grupo */}
        <div className="mt-3 grid grid-cols-3 gap-1 p-1 rounded-2xl bg-slate-100 dark:bg-slate-800/80">
          <button
            type="button"
            onClick={() => {
              setMode('login');
              setPendingRequestInfo(null);
              setErrorMsg('');
              setSuccessMsg('');
            }}
            className={`py-2 px-1 text-[11px] font-bold rounded-xl transition flex items-center justify-center gap-1 ${
              mode === 'login' || mode === 'recover'
                ? 'bg-white dark:bg-slate-900 text-blue-900 dark:text-blue-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <LogIn className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">Ingresar</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('register');
              setPendingRequestInfo(null);
              setErrorMsg('');
              setSuccessMsg('');
            }}
            className={`py-2 px-1 text-[11px] font-bold rounded-xl transition flex items-center justify-center gap-1 ${
              mode === 'register'
                ? 'bg-white dark:bg-slate-900 text-blue-900 dark:text-blue-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <UserPlus className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">Registrarme</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('create-group');
              setPendingRequestInfo(null);
              setErrorMsg('');
              setSuccessMsg('');
            }}
            className={`py-2 px-1 text-[11px] font-bold rounded-xl transition flex items-center justify-center gap-1 ${
              mode === 'create-group'
                ? 'bg-white dark:bg-slate-900 text-emerald-700 dark:text-emerald-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <PlusCircle className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">Nuevo Grupo</span>
          </button>
        </div>

        {/* Mensajes de error o éxito */}
        {errorMsg && (
          <div className="mt-3 p-3 rounded-2xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900/50 text-xs text-red-700 dark:text-red-300 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="mt-3 p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/50 text-xs text-emerald-700 dark:text-emerald-300 flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* MODO 1: INICIAR SESIÓN */}
        {mode === 'login' ? (
          <form onSubmit={handleLoginSubmit} className="mt-4 space-y-4 text-xs">
            {/* Selector de Grupo (para entrar directo al espacio de ese grupo) */}
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-blue-600" />
                <span>Grupo JMV</span>
              </label>
              <select
                value={loginGroupKey}
                onChange={(e) => {
                  const val = e.target.value;
                  setLoginGroupKey(val);
                  if (val !== 'auto') {
                    void switchGroup(val);
                  }
                }}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-semibold outline-none focus:ring-2 focus:ring-blue-600 text-xs"
              >
                <option value="auto">Detectar automáticamente según mi cuenta</option>
                {availableGroups.map((g) => (
                  <option key={g.groupKey} value={g.groupKey}>
                    {g.groupName} {g.parishName ? `(${g.parishName})` : ''}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-blue-600" />
                <span>Correo Electrónico o Cédula *</span>
              </label>
              <input
                type="text"
                required
                autoComplete="off"
                value={loginIdentifier}
                onChange={(e) => setLoginIdentifier(e.target.value)}
                placeholder="Ingresa tu correo o número de cédula"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-blue-600 text-xs"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-amber-500" />
                <span>Cédula de Identidad o Contraseña *</span>
              </label>
              <div className="relative">
                <input
                  type={showLoginPassword ? 'text' : 'password'}
                  required
                  autoComplete="off"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="Ingresa tu cédula o contraseña"
                  className="w-full pl-3.5 pr-10 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-blue-600 text-xs font-mono"
                />
                <button
                  type="button"
                  onClick={() => setShowLoginPassword((prev) => !prev)}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1"
                  aria-label="Mostrar u ocultar clave"
                >
                  {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              <div className="mt-1.5 flex items-center justify-between gap-2 flex-wrap">
                <p className="text-[10px] text-slate-400">
                  Si no definiste una clave distinta, usa tu cédula.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setMode('recover');
                    setRecoverStep('email');
                    setRecoverEmail(loginIdentifier.includes('@') ? loginIdentifier : '');
                    setRecoverCedula('');
                    setRecoverNewPassword('');
                    setRecoveredPassDisplay('');
                    setErrorMsg('');
                    setSuccessMsg('');
                  }}
                  className="text-[11px] font-bold text-blue-700 dark:text-blue-400 hover:underline flex items-center gap-1"
                >
                  <HelpCircle className="w-3 h-3" />
                  <span>¿Olvidaste tu contraseña?</span>
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoggingIn}
              className="w-full py-3 px-4 rounded-2xl bg-blue-900 hover:bg-blue-800 disabled:opacity-60 active:scale-[0.98] text-white font-bold text-xs shadow-md transition flex items-center justify-center gap-2"
            >
              <LogIn className="w-4 h-4 text-amber-300" />
              <span>{isLoggingIn ? 'Verificando acceso...' : 'Entrar a mi Cuenta'}</span>
            </button>

            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700/70 flex items-start gap-2 text-[11px] text-slate-600 dark:text-slate-300">
              <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
              <span>
                <strong>Privacidad garantizada:</strong> Cada integrante accede únicamente a su propia ficha y aportes personales.
              </span>
            </div>
          </form>
        ) : mode === 'recover' ? (
          /* MODO 3: RECORDAR / RECUPERAR CONTRASEÑA */
          <div className="mt-4 space-y-4 text-xs">
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setErrorMsg('');
                setSuccessMsg('');
              }}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-blue-700 dark:text-blue-400 hover:underline"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Volver a Iniciar Sesión</span>
            </button>

            {recoverStep === 'email' && (
              <form onSubmit={handleSendReminder} className="space-y-3.5">
                <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                  Ingresa el <strong>correo electrónico</strong> con el que fuiste registrado. Intentaremos enviar el recordatorio a tu correo y notificaremos al Coordinador.
                </p>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-blue-600" />
                    <span>Correo Electrónico Registrado *</span>
                  </label>
                  <input
                    type="email"
                    required
                    autoComplete="off"
                    value={recoverEmail}
                    onChange={(e) => setRecoverEmail(e.target.value)}
                    placeholder="tucorreo@ejemplo.com"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-blue-600 text-xs"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isRecovering}
                  className="w-full py-3 px-4 rounded-2xl bg-blue-900 hover:bg-blue-800 disabled:opacity-60 text-white font-bold text-xs shadow-md transition flex items-center justify-center gap-2"
                >
                  <Send className="w-4 h-4 text-amber-300" />
                  <span>{isRecovering ? 'Buscando cuenta...' : 'Enviar Recordatorio al Correo'}</span>
                </button>
              </form>
            )}

            {recoverStep === 'verify_cedula' && (
              <form onSubmit={handleVerifyCedulaRecover} className="space-y-3.5">
                <div className="p-3 rounded-2xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 text-[11px] text-blue-900 dark:text-blue-200">
                  Para proteger la privacidad de <strong>{recoveredEmailDisplay}</strong>, confirma tu número de cédula para ver o cambiar tu clave al instante:
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                    <CreditCard className="w-3.5 h-3.5 text-blue-600" />
                    <span>Cédula de Identidad Registrada *</span>
                  </label>
                  <input
                    type="text"
                    required
                    autoComplete="off"
                    value={recoverCedula}
                    onChange={(e) => setRecoverCedula(e.target.value)}
                    placeholder="Ingresa tu número de cédula"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono outline-none focus:ring-2 focus:ring-blue-600 text-xs"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-amber-500" />
                    <span>Nueva contraseña (para restablecer acceso)</span>
                  </label>
                  <input
                    type="text"
                    autoComplete="new-password"
                    value={recoverNewPassword}
                    onChange={(e) => setRecoverNewPassword(e.target.value)}
                    placeholder="Escribe una nueva contraseña segura"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono outline-none focus:ring-2 focus:ring-blue-600 text-xs"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isRecovering}
                  className="w-full py-3 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 text-white font-bold text-xs shadow-md transition flex items-center justify-center gap-2"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>{isRecovering ? 'Verificando...' : 'Verificar Cédula y Recuperar Clave'}</span>
                </button>
              </form>
            )}

            {recoverStep === 'done' && (
              <div className="space-y-3">
                {recoveredPassDisplay && (
                  <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-1.5">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block">
                      Credenciales listas para ingresar
                    </span>
                    <div className="font-mono text-xs text-slate-900 dark:text-white">
                      <strong>Correo:</strong> {recoveredEmailDisplay}
                    </div>
                    <div className="font-mono text-xs text-slate-900 dark:text-white">
                      <strong>Contraseña:</strong>{' '}
                      <span className="px-2 py-0.5 rounded bg-blue-100 dark:bg-blue-900 text-blue-900 dark:text-blue-200 font-bold">
                        {recoveredPassDisplay}
                      </span>
                    </div>
                  </div>
                )}

                <button
                  type="button"
                  onClick={() => {
                    if (recoveredEmailDisplay) setLoginIdentifier(recoveredEmailDisplay);
                    if (recoveredPassDisplay) setLoginPassword(recoveredPassDisplay);
                    setMode('login');
                    setErrorMsg('');
                    setSuccessMsg('Datos listos. Pulsa "Entrar a mi Cuenta".');
                  }}
                  className="w-full py-3 px-4 rounded-2xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow-md transition flex items-center justify-center gap-2"
                >
                  <LogIn className="w-4 h-4 text-amber-300" />
                  <span>Ir a Iniciar Sesión</span>
                </button>
              </div>
            )}
          </div>
        ) : mode === 'create-group' ? (
          /* MODO 4: CREAR UN NUEVO GRUPO INDEPENDIENTE */
          <form onSubmit={handleCreateGroupSubmit} className="mt-4 space-y-3.5 text-xs max-h-[68vh] overflow-y-auto pr-1">
            <div className="p-3 rounded-2xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 text-[11px] text-blue-900 dark:text-blue-200 flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
              <span>
                Cada grupo creado tiene su <strong>propia lista de integrantes, datos personales, cuotas, actividades, chat y fotos totalmente aislados</strong> de otros grupos.
              </span>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-blue-600" />
                <span>Nombre del Nuevo Grupo JMV *</span>
              </label>
              <input
                type="text"
                required
                value={newGroupName}
                onChange={(e) => setNewGroupName(e.target.value)}
                placeholder="Ej: JMV San Vicente - Sede Norte"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-bold outline-none focus:ring-2 focus:ring-blue-600 text-xs"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Parroquia o Comunidad
                </label>
                <input
                  type="text"
                  value={newParishName}
                  onChange={(e) => setNewParishName(e.target.value)}
                  placeholder="Ej: Parroquia La Dolorosa"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-blue-600 text-xs"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1">
                  <Key className="w-3 h-3 text-amber-500" />
                  <span>Código Privado *</span>
                </label>
                <input
                  type="text"
                  required
                  value={newGroupCode}
                  onChange={(e) =>
                    setNewGroupCode(e.target.value.replace(/[\s\u200B-\u200D\uFEFF]/g, '').toUpperCase())
                  }
                  placeholder="Ej: JMVNORTE26"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono font-bold uppercase outline-none focus:ring-2 focus:ring-blue-600 text-xs"
                />
              </div>
            </div>

            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-3">
              <p className="text-[11px] font-bold text-slate-700 dark:text-slate-300">
                Datos del Coordinador/a Principal de este grupo:
              </p>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Nombre y Apellido del Coordinador/a *
                </label>
                <input
                  type="text"
                  required
                  value={coordName}
                  onChange={(e) => setCoordName(e.target.value)}
                  placeholder="Ej: María José Vela"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-blue-600 text-xs"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Correo Electrónico *
                  </label>
                  <input
                    type="email"
                    required
                    value={coordEmail}
                    onChange={(e) => setCoordEmail(e.target.value)}
                    placeholder="coordinador@ejemplo.com"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-blue-600 text-xs"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Cédula *
                  </label>
                  <input
                    type="text"
                    required
                    value={coordCedula}
                    onChange={(e) => setCoordCedula(e.target.value.replace(/\D/g, ''))}
                    placeholder="Número de cédula"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono font-bold outline-none focus:ring-2 focus:ring-blue-600 text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Contraseña del Coordinador/a (opcional)
                </label>
                <input
                  type="text"
                  value={coordPassword}
                  onChange={(e) => setCoordPassword(e.target.value)}
                  placeholder="Si la dejas vacía, se usará la cédula"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono outline-none focus:ring-2 focus:ring-blue-600 text-xs"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isCreatingGroup}
              className="w-full py-3 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98] disabled:opacity-60 text-white font-bold text-xs shadow-md transition flex items-center justify-center gap-2"
            >
              <PlusCircle className="w-4 h-4" />
              <span>{isCreatingGroup ? 'Creando espacio del grupo...' : 'Crear Grupo e Ingresar como Admin'}</span>
            </button>
          </form>
        ) : pendingRequestInfo ? (
          /* PANTALLA DE SOLICITUD ENVIADA PENDIENTE DE AUTORIZACIÓN */
          <div className="mt-4 space-y-4 text-xs">
            <div className="p-5 rounded-3xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-center space-y-3">
              <div className="w-12 h-12 mx-auto rounded-2xl bg-amber-100 dark:bg-amber-900/60 text-amber-600 dark:text-amber-300 flex items-center justify-center shadow-sm">
                <Clock className="w-6 h-6" />
              </div>
              <h3 className="text-sm font-extrabold text-slate-900 dark:text-white">
                Solicitud Enviada al Administrador
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                Hola <strong>{pendingRequestInfo.name}</strong>, tu solicitud para{' '}
                <strong>{pendingRequestInfo.groupName || settings.groupName}</strong> con el correo{' '}
                <span className="font-mono font-semibold text-blue-800 dark:text-blue-300">
                  {pendingRequestInfo.email}
                </span>{' '}
                quedó registrada correctamente.
              </p>
              <div className="p-3 rounded-2xl bg-white/80 dark:bg-slate-900/80 border border-amber-200/70 dark:border-amber-800/50 text-[11px] text-amber-900 dark:text-amber-200 font-semibold">
                El Administrador de ese grupo debe presionar <strong>&laquo;Aceptar nuevo integrante&raquo;</strong> en su panel para autorizar tu ingreso.
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                setLoginIdentifier(pendingRequestInfo.email);
                setPendingRequestInfo(null);
                setMode('login');
                setErrorMsg('');
                setSuccessMsg('');
              }}
              className="w-full py-3 px-4 rounded-2xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow-md transition flex items-center justify-center gap-2"
            >
              <LogIn className="w-4 h-4 text-amber-300" />
              <span>Entendido · Ir a Iniciar Sesión</span>
            </button>
          </div>
        ) : (
          /* MODO 2: REGISTRO DE NUEVO PARTICIPANTE */
          <form onSubmit={handleRegisterSubmit} className="mt-4 space-y-3.5 text-xs max-h-[68vh] overflow-y-auto pr-1">
            <div className="p-3 rounded-2xl bg-amber-50/80 dark:bg-amber-950/30 border border-amber-200/80 dark:border-amber-900/50 flex items-start gap-2 text-[11px] text-amber-900 dark:text-amber-200">
              <Clock className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <span>
                Tus datos personales se guardarán exclusivamente dentro del grupo que selecciones y solo podrás ingresar cuando su Administrador acepte tu solicitud.
              </span>
            </div>

            {/* Nombre del Grupo JMV */}
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-blue-600" />
                Grupo JMV al que te registras *
              </label>
              <select
                value={regGroupSelection}
                onChange={(e) => setRegGroupSelection(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-bold focus:ring-2 focus:ring-blue-600 outline-none text-xs"
              >
                {availableGroups.map((g) => (
                  <option key={g.groupKey} value={g.groupKey}>
                    {g.groupName} {g.parishName ? `· ${g.parishName}` : ''}
                  </option>
                ))}
                <option value="__custom__">Escribir el nombre exacto de otro grupo...</option>
              </select>
              {regGroupSelection === '__custom__' && (
                <input
                  type="text"
                  required
                  value={regCustomGroupName}
                  onChange={(e) => setRegCustomGroupName(e.target.value)}
                  placeholder="Nombre exacto del grupo (ej: JMV San Vicente Norte)"
                  className="mt-2 w-full px-3.5 py-2 rounded-xl border border-blue-300 dark:border-blue-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-semibold focus:ring-2 focus:ring-blue-600 outline-none text-xs"
                />
              )}
            </div>

            {/* Código de invitación PRIVADO */}
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Key className="w-3.5 h-3.5 text-amber-500" />
                Código privado de invitación del grupo *
              </label>
              <input
                type="text"
                required
                value={invitationCode}
                onChange={(e) => setInvitationCode(e.target.value.replace(/[\s\u200B-\u200D\uFEFF]/g, '').toUpperCase())}
                placeholder="Ingresa el código secreto del grupo elegido"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white uppercase tracking-wider font-mono font-bold focus:ring-2 focus:ring-blue-600 outline-none text-xs"
              />
              <p className="text-[10px] text-slate-400 mt-0.5">
                Este código es privado y propio de cada grupo. Solicítalo al coordinador de tu grupo.
              </p>
            </div>

            {/* Nombre completo */}
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-blue-600" />
                Nombre y apellido completos *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ej: Valeria Gómez"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-600 outline-none text-xs"
              />
            </div>

            {/* Correo y Cédula */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-blue-600" />
                  Correo Electrónico *
                </label>
                <input
                  type="email"
                  required
                  autoComplete="off"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="tucorreo@ejemplo.com"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-600 outline-none text-xs"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                  <CreditCard className="w-3.5 h-3.5 text-blue-600" />
                  Cédula de Identidad *
                </label>
                <input
                  type="text"
                  required
                  autoComplete="off"
                  value={cedula}
                  onChange={(e) => setCedula(e.target.value.replace(/\D/g, ''))}
                  placeholder="Número de cédula"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-600 outline-none text-xs font-mono font-bold"
                />
              </div>
            </div>

            {/* Contraseña opcional (si no se especifica, se usa su cédula) */}
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-slate-400" />
                Contraseña personalizada (opcional)
              </label>
              <div className="relative">
                <input
                  type={showRegPassword ? 'text' : 'password'}
                  autoComplete="new-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Si la dejas vacía, tu cédula será tu clave"
                  className="w-full pl-3 pr-10 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-600 outline-none text-xs"
                />
                <button
                  type="button"
                  onClick={() => setShowRegPassword((prev) => !prev)}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1"
                  aria-label="Mostrar u ocultar contraseña"
                >
                  {showRegPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Foto de perfil */}
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Camera className="w-3.5 h-3.5 text-blue-600" />
                Foto de perfil (opcional)
              </label>
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-full overflow-hidden bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shrink-0 flex items-center justify-center">
                  {avatarPreview ? (
                    <img src={avatarPreview} alt="Preview" className="w-full h-full object-cover" />
                  ) : (
                    <User className="w-5 h-5 text-slate-400" />
                  )}
                </div>
                <label className="cursor-pointer flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-medium transition text-xs">
                  <Upload className="w-3.5 h-3.5" />
                  <span>{isCompressing ? 'Comprimiendo...' : 'Subir foto'}</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleAvatarFile}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            {/* Cumpleaños y Teléfono */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-blue-600" />
                  Cumpleaños *
                </label>
                <input
                  type="date"
                  required
                  value={birthday}
                  onChange={(e) => handleBirthdayChange(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-600 outline-none text-xs"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-blue-600" />
                  WhatsApp
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+593 99..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-600 outline-none text-xs"
                />
              </div>
            </div>

            {/* Menor de edad */}
            {isMinor && (
              <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/20 space-y-2">
                <span className="text-[11px] font-bold text-amber-800 dark:text-amber-300 block">
                  🛡️ Datos del Apoderado (Menor de 18 años detectado):
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <input
                    type="text"
                    required
                    value={tutorName}
                    onChange={(e) => setTutorName(e.target.value)}
                    placeholder="Nombre del apoderado *"
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs"
                  />
                  <input
                    type="tel"
                    required
                    value={tutorPhone}
                    onChange={(e) => setTutorPhone(e.target.value)}
                    placeholder="Teléfono del apoderado *"
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs"
                  />
                </div>
              </div>
            )}

            {/* Consentimiento de uso de imagen */}
            <div className="p-3 rounded-2xl bg-blue-50/70 dark:bg-blue-950/30 border border-blue-100 dark:border-blue-900/40">
              <label className="flex items-start gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  required
                  checked={imageConsent}
                  onChange={(e) => setImageConsent(e.target.checked)}
                  className="w-4 h-4 mt-0.5 rounded text-blue-600 focus:ring-blue-500"
                />
                <div className="text-[11px] text-slate-700 dark:text-slate-300 leading-tight">
                  <strong>Autorización pastoral interna:</strong> Autorizo la publicación de fotos en la galería privada de JMV y álbumes de actividades con fines exclusivamente formativos y comunitarios.
                </div>
              </label>
            </div>

            <button
              type="submit"
              disabled={isRegistering}
              className="w-full py-3 px-4 rounded-2xl bg-blue-900 hover:bg-blue-800 active:scale-[0.98] disabled:opacity-60 text-white font-bold text-xs shadow-md transition flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4 text-amber-400" />
              <span>{isRegistering ? 'Verificando código y enviando...' : 'Enviar Solicitud de Registro'}</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
