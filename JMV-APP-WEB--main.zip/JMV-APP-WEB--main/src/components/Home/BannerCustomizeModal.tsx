import React, { useState } from 'react';
import {
  X,
  Palette,
  Camera,
  Upload,
  RotateCcw,
  Sparkles,
  Check,
  Eye,
  Sliders,
  Image as ImageIcon,
} from 'lucide-react';
import { BANNER_PALETTES, BannerPalette, getBannerPalette } from '../../data/bannerPalettes';
import { compressImage } from '../../services/imageCompression';
import heroYouthImg from '../../assets/images/jmv_hero_youth_1794117311900.jpg';

interface BannerCustomizeModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentPaletteId?: string;
  currentImageUrl?: string;
  currentImageOpacity?: number;
  groupName: string;
  onSave: (data: { paletteId: string; imageUrl?: string; imageOpacity: number }) => void;
}

export const BannerCustomizeModal: React.FC<BannerCustomizeModalProps> = ({
  isOpen,
  onClose,
  currentPaletteId = 'azul-mariano',
  currentImageUrl,
  currentImageOpacity = 30,
  groupName,
  onSave,
}) => {
  const [selectedPaletteId, setSelectedPaletteId] = useState(currentPaletteId);
  const [selectedImageUrl, setSelectedImageUrl] = useState<string>(currentImageUrl || heroYouthImg);
  const [selectedOpacity, setSelectedOpacity] = useState<number>(currentImageOpacity);
  const [isCompressing, setIsCompressing] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  if (!isOpen) return null;

  const activePalette: BannerPalette = getBannerPalette(selectedPaletteId);
  const isDefaultImage = selectedImageUrl === heroYouthImg;

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsCompressing(true);
      const res = await compressImage(file, { maxWidth: 1200, maxHeight: 800, quality: 0.85 });
      setSelectedImageUrl(res.dataUrl);
      setFeedback('¡Foto cargada exitosamente para la portada!');
      setTimeout(() => setFeedback(null), 3000);
    } catch (err) {
      console.error(err);
      setFeedback('Error al procesar la imagen.');
    } finally {
      setIsCompressing(false);
    }
  };

  const handleResetToDefault = () => {
    setSelectedImageUrl(heroYouthImg);
    setFeedback('Se restauró la foto de muestra original.');
    setTimeout(() => setFeedback(null), 3000);
  };

  const handleSaveAndApply = () => {
    onSave({
      paletteId: selectedPaletteId,
      imageUrl: selectedImageUrl,
      imageOpacity: selectedOpacity,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
      <div className="w-full max-w-2xl rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-5 sm:p-6 space-y-5 max-h-[92vh] overflow-y-auto">
        {/* Cabecera */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center">
              <Palette className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                Personalizar Cuadro Principal (Portada)
              </h2>
              <p className="text-[11px] text-slate-500">
                Cambia la paleta de colores y pon una foto real de tu grupo de jóvenes JMV
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Vista previa en vivo del Banner */}
        <div className="space-y-1.5">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
            <Eye className="w-3.5 h-3.5" />
            Vista previa en tiempo real:
          </span>

          <div
            className={`relative overflow-hidden rounded-3xl bg-gradient-to-br ${activePalette.gradientClass} text-white p-5 shadow-lg border ${activePalette.borderClass} transition-all duration-300`}
          >
            <div className="relative z-10 max-w-md">
              <div className="flex items-center gap-2 mb-1.5">
                <span
                  className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full ${activePalette.badgeBg}`}
                >
                  ✨ {groupName}
                </span>
              </div>
              <h3 className="text-base sm:text-lg font-black tracking-tight">
                ¡La paz esté contigo, Andrés!
              </h3>
              <p className="text-xs text-white/80 mt-0.5 leading-relaxed">
                "A Jesús por María". El fuego de la caridad vicenciana en nuestra comunidad.
              </p>
              <div className="mt-3 flex items-center gap-2">
                <span
                  className={`text-[11px] font-bold px-3 py-1.5 rounded-xl shadow transition ${activePalette.primaryButtonClass}`}
                >
                  Ver Reto Semanal
                </span>
                <span
                  className={`text-[11px] font-semibold px-3 py-1.5 rounded-xl border backdrop-blur-sm ${activePalette.secondaryButtonClass}`}
                >
                  Chat Grupal
                </span>
              </div>
            </div>

            {/* Foto del grupo en la vista previa */}
            <div
              className="absolute right-0 top-0 bottom-0 w-1/2 hidden sm:block pointer-events-none transition-opacity duration-300"
              style={{ opacity: selectedOpacity / 100 }}
            >
              <img
                src={selectedImageUrl}
                alt="Foto del grupo"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>

        {/* Sección 1: Selector de Paleta de Colores */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
            <Palette className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            1. Elige la Paleta de Colores Vicenciana:
          </label>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {BANNER_PALETTES.map((pal) => {
              const isSelected = pal.id === selectedPaletteId;
              return (
                <button
                  key={pal.id}
                  type="button"
                  onClick={() => setSelectedPaletteId(pal.id)}
                  className={`flex items-start gap-3 p-3 rounded-2xl border text-left transition-all relative ${
                    isSelected
                      ? 'border-blue-600 dark:border-blue-500 bg-blue-50/70 dark:bg-blue-950/40 shadow-sm ring-2 ring-blue-600/20'
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-white dark:bg-slate-800/60'
                  }`}
                >
                  {/* Muestra de color de la paleta */}
                  <div className="flex -space-x-1.5 shrink-0 mt-0.5">
                    {pal.previewColors.map((col, idx) => (
                      <span
                        key={idx}
                        className="w-4 h-4 rounded-full border border-white dark:border-slate-900 shadow-sm"
                        style={{ backgroundColor: col }}
                      />
                    ))}
                  </div>

                  <div className="flex-1 min-w-0 pr-4">
                    <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {pal.name}
                    </p>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5">
                      {pal.description}
                    </p>
                  </div>

                  {isSelected && (
                    <span className="absolute right-2.5 top-2.5 w-4 h-4 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px]">
                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Sección 2: Foto Propia del Grupo de Jóvenes */}
        <div className="space-y-3 pt-2 border-t border-slate-100 dark:border-slate-800">
          <label className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
            <Camera className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            2. Foto de Jóvenes de la Portada:
          </label>

          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center gap-4">
            {/* Miniatura de la foto actual */}
            <div className="relative w-24 h-24 rounded-2xl overflow-hidden ring-2 ring-amber-400 shrink-0 shadow-md bg-slate-200 dark:bg-slate-700">
              <img
                src={selectedImageUrl}
                alt="Foto seleccionada"
                className="w-full h-full object-cover"
              />
              {!isDefaultImage && (
                <span className="absolute bottom-1 right-1 bg-emerald-600 text-white text-[9px] font-black px-1.5 py-0.5 rounded-md shadow">
                  Propia
                </span>
              )}
            </div>

            <div className="flex-1 space-y-2 text-xs w-full text-center sm:text-left">
              <div>
                <p className="font-bold text-slate-900 dark:text-white">
                  {isDefaultImage
                    ? 'Foto de muestra actual'
                    : '¡Foto personalizada de tu grupo JMV!'}
                </p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                  Sube una foto de tus jóvenes en el campamento, retiro o reunión parroquial.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2 justify-center sm:justify-start">
                <label className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow transition active:scale-95">
                  <Upload className="w-3.5 h-3.5" />
                  <span>{isCompressing ? 'Comprimiendo...' : 'Subir Foto de Nuestro Grupo'}</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                    disabled={isCompressing}
                  />
                </label>

                {!isDefaultImage && (
                  <button
                    type="button"
                    onClick={handleResetToDefault}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold text-xs transition"
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
                    <span>Restaurar foto original</span>
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Selector de Opacidad / Intensidad de la foto */}
          <div className="flex items-center justify-between gap-3 p-3 rounded-2xl bg-slate-50/70 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800 text-xs">
            <span className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-slate-500" />
              Intensidad de la foto en la portada:
            </span>
            <div className="flex items-center gap-1.5">
              {[20, 30, 45, 60].map((op) => (
                <button
                  key={op}
                  type="button"
                  onClick={() => setSelectedOpacity(op)}
                  className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition ${
                    selectedOpacity === op
                      ? 'bg-blue-900 text-white shadow-sm'
                      : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100 border border-slate-200 dark:border-slate-700'
                  }`}
                >
                  {op}%
                </button>
              ))}
            </div>
          </div>
        </div>

        {feedback && (
          <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs font-semibold flex items-center gap-1.5">
            <Check className="w-3.5 h-3.5" />
            <span>{feedback}</span>
          </div>
        )}

        {/* Botones de acción */}
        <div className="pt-2 flex items-center gap-2 border-t border-slate-100 dark:border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-semibold text-xs hover:bg-slate-50 dark:hover:bg-slate-800 transition"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={handleSaveAndApply}
            className="flex-1 py-2.5 px-3 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow transition active:scale-95 flex items-center justify-center gap-1.5"
          >
            <Check className="w-4 h-4" />
            <span>Guardar y Aplicar Cambios</span>
          </button>
        </div>
      </div>
    </div>
  );
};
