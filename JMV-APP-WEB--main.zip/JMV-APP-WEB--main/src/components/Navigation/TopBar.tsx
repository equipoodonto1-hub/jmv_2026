import React, { useState } from 'react';
import { Moon, Sun, Database, ShieldCheck, UserCheck, ChevronDown, Sparkles, Cake, Settings, Menu, Users, User, Key, LogOut, UserPlus } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { PWAInstallButton } from '../Common/PWAInstallButton';
import marianMedalImg from '../../assets/images/jmv_marian_medal_1794117311829.jpg';

export const TopBar: React.FC<{
  onOpenRegister: () => void;
  onNavigateTab: (tab: string) => void;
  currentTab: string;
}> = ({ onOpenRegister, onNavigateTab, currentTab }) => {
  const {
    currentUser,
    users,
    isAdmin,
    theme,
    toggleTheme,
    settings,
    setShowSupabaseGuide,
    supabaseConnected,
    toggleMobileSidebar,
    logout,
    setShowAuthModal,
    setAuthModalMode,
  } = useApp();

  const [showUserDropdown, setShowUserDropdown] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full max-w-full bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
      <div className="max-w-5xl w-full mx-auto px-3 sm:px-4 h-14 flex items-center justify-between gap-2 sm:gap-3">
        {/* Botón Hamburguesa móvil para barra lateral */}
        <div className="flex items-center gap-1.5 sm:gap-2 min-w-0">
          <button
            onClick={toggleMobileSidebar}
            aria-label="Abrir barra lateral con opciones"
            className="xl:hidden p-2 -ml-1 rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors shrink-0"
          >
            <Menu className="w-5 h-5" />
          </button>

          {/* Zona 1: Marca oficial con logo, nombre del grupo y parroquia personalizables */}
          <div
            className="flex items-center gap-2.5 cursor-pointer group min-w-0"
            onClick={() => {
              if (isAdmin) {
                onNavigateTab('admin');
              } else {
                onNavigateTab('inicio');
              }
            }}
            title={isAdmin ? "Haz clic para cambiar el nombre, parroquia o logo oficial" : `${settings.groupName} · ${settings.parishName || ''}`}
          >
            <div className="relative w-9 h-9 sm:w-10 sm:h-10 rounded-2xl overflow-hidden ring-2 ring-amber-400/70 shadow-sm shrink-0 bg-white p-0.5 group-hover:ring-amber-500 transition-all flex items-center justify-center">
              <img
                src={settings.logoUrl || marianMedalImg}
                alt={settings.groupName}
                className="w-full h-full object-contain group-hover:scale-105 transition-transform rounded-xl"
                referrerPolicy="no-referrer"
              />
              {isAdmin && (
                <span className="absolute inset-0 bg-blue-950/60 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity text-amber-300 text-[10px] font-bold">
                  ✏️
                </span>
              )}
            </div>
            <div className="flex flex-col min-w-0">
              <span className="font-extrabold text-xs sm:text-sm tracking-tight text-blue-900 dark:text-blue-300 leading-tight group-hover:text-blue-700 dark:group-hover:text-blue-200 transition-colors max-w-[140px] sm:max-w-[200px] lg:max-w-[240px] truncate">
                {settings.groupName || 'JMV'}
              </span>
              <div className="flex items-center gap-1 min-w-0">
                <span className="text-[10px] font-semibold text-amber-600 dark:text-amber-400 leading-tight max-w-[130px] sm:max-w-[190px] lg:max-w-[230px] truncate">
                  {settings.parishName || 'Juventud Mariana'}
                </span>
                {isAdmin && (
                  <span className="text-[9px] text-blue-600 dark:text-blue-400 opacity-60 group-hover:opacity-100 font-bold hidden md:inline shrink-0">
                    (editar)
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Zona 2: Enlaces rápidos de escritorio completo */}
        <nav className="hidden xl:flex items-center gap-5 text-xs font-semibold text-slate-600 dark:text-slate-300">
          <button
            onClick={() => onNavigateTab('inicio')}
            className={`transition-colors hover:text-blue-700 dark:hover:text-blue-400 ${
              currentTab === 'inicio' ? 'text-blue-900 dark:text-blue-400 font-bold' : ''
            }`}
          >
            Inicio
          </button>
          <button
            onClick={() => onNavigateTab('retos')}
            className={`transition-colors hover:text-blue-700 dark:hover:text-blue-400 ${
              currentTab === 'retos' ? 'text-blue-900 dark:text-blue-400 font-bold' : ''
            }`}
          >
            Retos
          </button>
          <button
            onClick={() => onNavigateTab('cuotas')}
            className={`transition-colors hover:text-blue-700 dark:hover:text-blue-400 ${
              currentTab === 'cuotas' ? 'text-blue-900 dark:text-blue-400 font-bold' : ''
            }`}
          >
            Cuotas $1
          </button>
          <button
            onClick={() => onNavigateTab('chat')}
            className={`transition-colors hover:text-blue-700 dark:hover:text-blue-400 ${
              currentTab === 'chat' ? 'text-blue-900 dark:text-blue-400 font-bold' : ''
            }`}
          >
            Chat
          </button>
          <button
            onClick={() => onNavigateTab('actividades')}
            className={`transition-colors hover:text-blue-700 dark:hover:text-blue-400 ${
              currentTab === 'actividades' ? 'text-blue-900 dark:text-blue-400 font-bold' : ''
            }`}
          >
            Calendario
          </button>
          <button
            onClick={() => onNavigateTab('amigo-secreto')}
            className={`transition-colors hover:text-blue-700 dark:hover:text-blue-400 ${
              currentTab === 'amigo-secreto' ? 'text-blue-900 dark:text-blue-400 font-bold' : ''
            }`}
          >
            Amigo Secreto
          </button>
          {isAdmin && (
            <button
              onClick={() => onNavigateTab('admin')}
              className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl transition-colors ${
                currentTab === 'admin'
                  ? 'bg-emerald-600 text-white font-bold shadow-sm'
                  : 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-800 dark:text-emerald-300 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 font-bold'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Solicitudes y Admin</span>
              {users.filter((u) => u.status === 'pendiente_aprobacion').length > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-amber-400 text-slate-950 text-[10px] font-black">
                  {users.filter((u) => u.status === 'pendiente_aprobacion').length}
                </span>
              )}
            </button>
          )}
        </nav>

        {/* Zona 3: Acciones primarias contenidas perfectamente en cualquier ancho */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {isAdmin && (
            <button
              onClick={() => onNavigateTab('admin')}
              className={`xl:hidden inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-[11px] font-bold transition ${
                currentTab === 'admin'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
              }`}
              title="Abrir Panel de Solicitudes y Administrador"
            >
              <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
              <span>Solicitudes</span>
              {users.filter((u) => u.status === 'pendiente_aprobacion').length > 0 && (
                <span className="px-1.5 rounded-full bg-amber-400 text-slate-950 text-[10px] font-black">
                  {users.filter((u) => u.status === 'pendiente_aprobacion').length}
                </span>
              )}
            </button>
          )}
          {/* Cumpleaños (icono compacto en desktop) */}
          <button
            onClick={() => onNavigateTab('cumpleanios')}
            aria-label="Ver cumpleaños y tarjetas automáticas"
            className={`hidden xl:flex p-2 rounded-xl border transition-all ${
              currentTab === 'cumpleanios'
                ? 'bg-pink-100 dark:bg-pink-950/60 border-pink-400 text-pink-700'
                : 'border-slate-200 dark:border-slate-700 text-pink-600 dark:text-pink-400 hover:bg-pink-50'
            }`}
            title="Ver cumpleaños y generar tarjetas automáticas"
          >
            <Cake className="w-4 h-4" />
          </button>

          {/* Botón PWA en desktop grande */}
          <div className="hidden 2xl:flex">
            <PWAInstallButton compact />
          </div>

          {/* Guía / Estado Supabase */}
          <button
            onClick={() => setShowSupabaseGuide(true)}
            aria-label="Configuración de base de datos Supabase y Netlify"
            className={`hidden 2xl:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
              supabaseConnected
                ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
                : 'bg-blue-50 dark:bg-blue-950/40 text-blue-800 dark:text-blue-300 border-blue-200 dark:border-blue-900/60 hover:bg-blue-100'
            }`}
            title="Ver guía para publicar en Netlify y conectar Supabase"
          >
            <Database className="w-3.5 h-3.5" />
            <span>Supabase</span>
          </button>

          {/* Selector interactivo de perfil (Avatar compacto en móvil con insignia de rol; expande modal) */}
          <div className="relative">
            <button
              onClick={() => setShowUserDropdown(!showUserDropdown)}
              className="flex items-center gap-1.5 p-1 sm:px-2 sm:py-1 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 transition-colors"
              aria-label="Perfil de usuario y cambio de rol"
            >
              <div className="relative shrink-0">
                <img
                  src={currentUser.avatarUrl}
                  alt={currentUser.name}
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-700"
                  referrerPolicy="no-referrer"
                />
                {/* Insignia compacta de rol sobre el avatar */}
                <span
                  className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full flex items-center justify-center text-[8px] text-white font-extrabold shadow-sm ${
                    isAdmin
                      ? 'bg-amber-500 ring-1 ring-white dark:ring-slate-900'
                      : currentUser.role === 'tesorero' || currentUser.isTreasurer
                      ? 'bg-emerald-500 ring-1 ring-white dark:ring-slate-900'
                      : 'bg-blue-600 ring-1 ring-white dark:ring-slate-900'
                  }`}
                  title={isAdmin ? 'Administrador' : currentUser.role === 'tesorero' || currentUser.isTreasurer ? 'Tesorero' : 'Integrante'}
                >
                  {isAdmin ? '★' : currentUser.role === 'tesorero' || currentUser.isTreasurer ? '$' : '✓'}
                </span>
              </div>

              {/* Nombre y texto de rol: sólo en pantallas grandes donde hay espacio holgado */}
              <div className="hidden lg:flex flex-col text-left mr-0.5 max-w-[105px] xl:max-w-[130px]">
                <span className="text-xs font-bold text-slate-800 dark:text-slate-100 leading-tight truncate">
                  {currentUser.name}
                </span>
                <span className="text-[10px] font-semibold text-blue-700 dark:text-blue-400 leading-none flex items-center gap-0.5 truncate">
                  {isAdmin ? (
                    <>
                      <ShieldCheck className="w-2.5 h-2.5 shrink-0" /> Admin
                    </>
                  ) : currentUser.role === 'tesorero' || currentUser.isTreasurer ? (
                    <span className="text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-0.5">
                      💰 Tesorero
                    </span>
                  ) : (
                    <>
                      <UserCheck className="w-2.5 h-2.5 shrink-0" /> Integrante
                    </>
                  )}
                </span>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            </button>

            {/* Menú de perfil seguro y cambio de cuenta protegido por clave */}
            {showUserDropdown && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setShowUserDropdown(false)}
                />
                <div className="absolute right-0 mt-2 w-72 max-w-[calc(100vw-1.5rem)] rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl py-2 z-50 text-xs animate-in fade-in-50 zoom-in-95 duration-150">
                  <div className="px-3.5 py-2.5 border-b border-slate-100 dark:border-slate-800">
                    <div className="flex items-center justify-between gap-2">
                      <p className="font-bold text-slate-900 dark:text-white truncate">{currentUser.name}</p>
                      <span className={`text-[9px] font-extrabold px-2 py-0.5 rounded-full ${
                        currentUser.status === 'aprobado'
                          ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300'
                          : 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300'
                      }`}>
                        {currentUser.status === 'aprobado' ? '✓ Aprobado' : '⏳ Pendiente'}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 truncate mt-0.5">
                      {currentUser.email}
                    </p>
                    <p className="text-[10px] text-slate-400 mt-0.5">
                      Cédula: <span className="font-mono font-semibold">{currentUser.cedula}</span>
                    </p>
                    <div className="mt-1 flex items-center justify-between gap-1 text-[10px]">
                      <span className="font-semibold text-blue-600 dark:text-blue-400">
                        {isAdmin
                          ? '🛡️ Administrador/a'
                          : currentUser.role === 'tesorero' || currentUser.isTreasurer
                          ? '💰 Tesorero/a'
                          : '👤 Integrante'}
                      </span>
                      <span className="text-amber-600 dark:text-amber-400 font-semibold flex items-center gap-1">
                        <Sparkles className="w-3 h-3" /> {currentUser.points} pts
                      </span>
                    </div>
                  </div>

                  <div className="p-2 space-y-1.5">
                    <button
                      onClick={() => {
                        setShowUserDropdown(false);
                        onNavigateTab('perfil');
                      }}
                      className="w-full flex items-center gap-2 py-2 px-3 rounded-xl bg-blue-50 hover:bg-blue-100 dark:bg-blue-950/60 dark:hover:bg-blue-900/60 text-blue-900 dark:text-blue-300 font-bold text-xs transition"
                    >
                      <User className="w-4 h-4 text-blue-700 shrink-0" />
                      <span>Mi Ficha y Datos Privados</span>
                    </button>

                    {isAdmin && (
                      <button
                        onClick={() => {
                          setShowUserDropdown(false);
                          onNavigateTab('admin');
                        }}
                        className="w-full flex items-center justify-between gap-2 py-2 px-3 rounded-xl bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/60 text-indigo-900 dark:text-indigo-300 font-bold text-xs transition"
                      >
                        <span className="flex items-center gap-2">
                          <ShieldCheck className="w-4 h-4 text-indigo-600 shrink-0" />
                          <span>Panel Admin y Participantes</span>
                        </span>
                        {users.filter((u) => u.status === 'pendiente_aprobacion').length > 0 && (
                          <span className="px-1.5 py-0.5 rounded-full bg-emerald-600 text-white text-[10px] font-extrabold">
                            {users.filter((u) => u.status === 'pendiente_aprobacion').length}
                          </span>
                        )}
                      </button>
                    )}

                    <div className="pt-1 border-t border-slate-100 dark:border-slate-800 space-y-1">
                      <button
                        onClick={() => {
                          setShowUserDropdown(false);
                          setAuthModalMode('login');
                          setShowAuthModal(true);
                        }}
                        className="w-full flex items-center gap-2 py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-semibold text-xs transition"
                      >
                        <Key className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                        <span>Cambiar Cuenta con Correo/Cédula</span>
                      </button>

                      <button
                        onClick={() => {
                          setShowUserDropdown(false);
                          setAuthModalMode('register');
                          setShowAuthModal(true);
                        }}
                        className="w-full flex items-center gap-2 py-2 px-3 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs transition"
                      >
                        <UserPlus className="w-3.5 h-3.5 text-amber-300 shrink-0" />
                        <span>+ Registrar nuevo participante</span>
                      </button>

                      <button
                        onClick={() => {
                          setShowUserDropdown(false);
                          logout();
                        }}
                        className="w-full flex items-center gap-2 py-1.5 px-3 rounded-xl hover:bg-red-50 dark:hover:bg-red-950/40 text-red-600 dark:text-red-400 font-semibold text-xs transition"
                      >
                        <LogOut className="w-3.5 h-3.5 shrink-0" />
                        <span>Cerrar Sesión</span>
                      </button>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Botón de tema claro/oscuro */}
          <button
            onClick={toggleTheme}
            aria-label="Cambiar tema claro u oscuro"
            className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl flex items-center justify-center border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors shrink-0"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-blue-900" />}
          </button>
        </div>
      </div>
    </header>
  );
};
