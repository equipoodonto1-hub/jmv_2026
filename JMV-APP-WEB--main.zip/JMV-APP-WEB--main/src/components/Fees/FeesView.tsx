import React, { useState } from 'react';
import {
  DollarSign,
  Download,
  FileSpreadsheet,
  Printer,
  CheckCircle,
  Clock,
  Shirt,
  Sparkles,
  Search,
  Filter,
  Check,
  Plus,
  TrendingUp,
  TrendingDown,
  Receipt,
  ShoppingBag,
  ShieldCheck,
  Lock,
  UserCheck,
  Calendar,
  Trash2,
  Upload,
  X,
  PieChart,
  HelpCircle,
  AlertCircle,
  Tag,
  Coins,
  ChevronDown,
  ChevronUp,
  ArrowUpRight,
  Edit2,
  Users,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { compressImage } from '../../services/imageCompression';
import { FeeCampaign, ActivityExpense, FeePayment } from '../../types';

export const FeesView: React.FC = () => {
  const {
    currentUser,
    users,
    feeWeeks,
    feePayments,
    addFeeWeek,
    markFeePayment,
    exportFeesToCSV,
    settings,
    isAdmin,
    canManageFinances,
    isTreasurer,
    treasurerUser,
    setTreasurerUser,
    feeCampaigns,
    createFeeCampaign,
    recordCampaignPayment,
    deleteCampaignSalePayment,
    markCampaignSalePaid,
    toggleInvestmentPayment,
    updateCampaignFinancials,
    deleteFeeCampaign,
    cleanExampleCampaigns,
    activityExpenses,
    addActivityExpense,
    deleteActivityExpense,
    activities,
  } = useApp();

  // Sub-pestañas: 'cuota_semanal' | 'ventas_cuotas' | 'gastos_actividades' | 'balance_general'
  const [activeTab, setActiveTab] = useState<
    'cuota_semanal' | 'ventas_cuotas' | 'gastos_actividades' | 'balance_general'
  >('ventas_cuotas');

  // Filtros de la cuota semanal
  const [filterView, setFilterView] = useState<'todos' | 'mis_cuotas'>('todos');
  const [searchTerm, setSearchTerm] = useState('');

  // Campaña seleccionada para ver el desglose completo de inversión y ventas
  const [selectedCampaignId, setSelectedCampaignId] = useState<string>(
    feeCampaigns[0]?.id || 'camp-empanadas'
  );

  // Modales
  const [showNewCampaignModal, setShowNewCampaignModal] = useState(false);
  const [showNewExpenseModal, setShowNewExpenseModal] = useState(false);
  const [showRecordSaleModal, setShowRecordSaleModal] = useState<FeeCampaign | null>(null);
  const [showEditCostsModal, setShowEditCostsModal] = useState<FeeCampaign | null>(null);
  const [campaignToDelete, setCampaignToDelete] = useState<FeeCampaign | null>(null);
  const [showCleanExampleCampaignsModal, setShowCleanExampleCampaignsModal] = useState(false);
  const [editCostsAmount, setEditCostsAmount] = useState<number>(0);

  // Formulario de Nueva Cuota / Venta con Inversión
  const [campaignTitle, setCampaignTitle] = useState('Venta de Empanadas Caseras');
  const [campaignDesc, setCampaignDesc] = useState(
    'Todos ponemos $2.00 de inversión inicial para la carne, masa y aceite. Luego vendemos las empanadas a $1.00 c/u para generar ganancias para el retiro.'
  );
  const [campaignType, setCampaignType] = useState<FeeCampaign['type']>('venta');
  const [campaignUnitLabel, setCampaignUnitLabel] = useState('empanada');
  const [campaignUnitPrice, setCampaignUnitPrice] = useState<number>(1.0);
  const [campaignGoal, setCampaignGoal] = useState<number>(80);
  const [campaignInvestmentPerPerson, setCampaignInvestmentPerPerson] = useState<number>(2.0);
  const [campaignIngredientCosts, setCampaignIngredientCosts] = useState<number>(16.5);
  const [campaignDeadline, setCampaignDeadline] = useState(
    new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0]
  );

  // Formulario de Registro de Venta por Integrante
  const [saleMemberId, setSaleMemberId] = useState(users[0]?.id || '');
  const [saleQuantity, setSaleQuantity] = useState<number>(10);
  const [saleStatus, setSaleStatus] = useState<'pagado' | 'pendiente'>('pagado');
  const [saleNote, setSaleNote] = useState('');

  // Formulario de Nuevo Gasto
  const [expenseTitle, setExpenseTitle] = useState('');
  const [expenseDesc, setExpenseDesc] = useState('');
  const [expenseAmount, setExpenseAmount] = useState<number>(15.0);
  const [expenseDate, setExpenseDate] = useState(new Date().toISOString().split('T')[0]);
  const [expenseCategory, setExpenseCategory] = useState<ActivityExpense['category']>('refrigerio');
  const [expenseActivityTitle, setExpenseActivityTitle] = useState('Gasto general del grupo');
  const [expenseReceipt, setExpenseReceipt] = useState<string>('');
  const [isCompressingReceipt, setIsCompressingReceipt] = useState(false);

  // Estado de aprobación para visualización de aportes personales
  const isPendingApproval = currentUser.status === 'pendiente_aprobacion' && !canManageFinances;

  // --- CÁLCULOS GENERALES DE TESORERÍA ---
  // 1. Ingresos por Cuota Semanal $1
  const weeklyPaymentsPaid = feePayments.filter((p) => !p.campaignId && p.status === 'pagado');
  const totalWeeklyCollected = weeklyPaymentsPaid.reduce((acc, p) => acc + p.amount, 0);

  // 2. Ingresos por Ventas y Campañas (Inversiones + Ventas cobradas)
  const campaignPaymentsPaid = feePayments.filter(
    (p) => Boolean(p.campaignId) && p.status === 'pagado'
  );
  const totalCampaignsCollected = campaignPaymentsPaid.reduce((acc, p) => acc + p.amount, 0);

  // 3. Ingresos Totales
  const totalIncome = totalWeeklyCollected + totalCampaignsCollected;

  // 4. Gastos Totales
  const totalExpenses = activityExpenses.reduce((acc, e) => acc + e.amount, 0);

  // 5. Saldo Disponible en Caja
  const currentCashBalance = totalIncome - totalExpenses;

  // Progreso de la meta de chompas
  const hoodieGoalPercentage = Math.min(
    100,
    Math.round((totalWeeklyCollected / settings.hoodieGoalAmount) * 100)
  );

  // Mis cuotas personales
  const myPaidPayments = feePayments.filter(
    (p) => !p.campaignId && p.userId === currentUser.id && p.status === 'pagado'
  );
  const myTotalPaid = myPaidPayments.reduce((acc, p) => acc + p.amount, 0);
  const myPendingPayments = feePayments.filter(
    (p) => !p.campaignId && p.userId === currentUser.id && p.status === 'pendiente'
  );

  // Filtrado de usuarios en la tabla semanal
  const displayedUsers = users.filter((u) =>
    u.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Campaña activa seleccionada para el desglose detallado de Inversión y Ganancias
  const activeCampaign =
    feeCampaigns.find((c) => c.id === selectedCampaignId) || feeCampaigns[0];

  // Cálculos específicos para la campaña seleccionada
  const activeCampaignPayments = activeCampaign
    ? feePayments.filter((p) => p.campaignId === activeCampaign.id)
    : [];

  // Inversión inicial recaudada
  const investmentPaymentsPaid = activeCampaignPayments.filter(
    (p) => p.paymentType === 'inversion' && p.status === 'pagado'
  );
  const totalInvestmentCollected = investmentPaymentsPaid.reduce((acc, p) => acc + p.amount, 0);
  const totalInvestorsCount = investmentPaymentsPaid.length;

  // Ventas de productos realizadas
  const salesPaymentsPaid = activeCampaignPayments.filter(
    (p) => p.paymentType !== 'inversion' && p.status === 'pagado'
  );
  const totalGrossSales = salesPaymentsPaid.reduce((acc, p) => acc + p.amount, 0);
  const totalUnitsSold = salesPaymentsPaid.reduce((acc, p) => acc + (p.quantity || 1), 0);

  // Costo de insumos
  const ingredientCosts = activeCampaign?.ingredientCosts || 0;

  // GANANCIA NETA
  // Escenario 1: Ganancia Neta sobre insumos comprados = Ventas Brutas - Costo de Insumos
  const netProfit = totalGrossSales - ingredientCosts;
  // Escenario 2: Ganancia si se reintegra la inversión inicial a los jóvenes = Ventas - Inversión
  const netProfitAfterRefund = totalGrossSales - totalInvestmentCollected;
  // Margen de Rentabilidad
  const profitMarginPercent =
    ingredientCosts > 0 ? Math.round((netProfit / ingredientCosts) * 100) : 100;

  const handleReceiptUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsCompressingReceipt(true);
      const res = await compressImage(file, { maxWidth: 800, maxHeight: 800, quality: 0.75 });
      setExpenseReceipt(res.dataUrl);
    } catch (err) {
      console.error('Error al comprimir comprobante:', err);
    } finally {
      setIsCompressingReceipt(false);
    }
  };

  const handleCreateCampaignSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!campaignTitle.trim()) return;

    const created = createFeeCampaign({
      title: campaignTitle.trim(),
      description: campaignDesc.trim(),
      type: campaignType,
      unitLabel: campaignUnitLabel.trim(),
      unitPrice: Number(campaignUnitPrice),
      targetGoal: Number(campaignGoal),
      investmentPerPerson: Number(campaignInvestmentPerPerson),
      ingredientCosts: Number(campaignIngredientCosts),
      deadline: campaignDeadline,
    });

    setSelectedCampaignId(created.id);
    setCampaignTitle('');
    setCampaignDesc('');
    setShowNewCampaignModal(false);
  };

  const handleCreateExpenseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!expenseTitle.trim() || expenseAmount <= 0) return;

    addActivityExpense({
      title: expenseTitle.trim(),
      description: expenseDesc.trim(),
      amount: Number(expenseAmount),
      date: expenseDate,
      category: expenseCategory,
      activityTitle: expenseActivityTitle,
      receiptUrl: expenseReceipt || undefined,
    });

    setExpenseTitle('');
    setExpenseDesc('');
    setExpenseReceipt('');
    setShowNewExpenseModal(false);
  };

  const handleRecordSaleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!showRecordSaleModal || !saleMemberId) return;

    const totalAmount = saleQuantity * showRecordSaleModal.unitPrice;
    recordCampaignPayment(
      showRecordSaleModal.id,
      saleMemberId,
      saleQuantity,
      totalAmount,
      saleStatus === 'pagado',
      saleNote.trim(),
      'venta'
    );

    setSaleNote('');
    setShowRecordSaleModal(null);
  };

  const handleUpdateCostsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!showEditCostsModal) return;

    updateCampaignFinancials(showEditCostsModal.id, {
      ingredientCosts: Number(editCostsAmount),
    });
    setShowEditCostsModal(null);
  };

  const getCategoryBadge = (cat: ActivityExpense['category']) => {
    switch (cat) {
      case 'refrigerio':
        return { label: 'Refrigerio', bg: 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300' };
      case 'materiales':
        return { label: 'Materiales', bg: 'bg-blue-100 dark:bg-blue-950/60 text-blue-800 dark:text-blue-300' };
      case 'transporte':
        return { label: 'Transporte', bg: 'bg-purple-100 dark:bg-purple-950/60 text-purple-800 dark:text-purple-300' };
      case 'espiritualidad':
        return { label: 'Espiritualidad', bg: 'bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300' };
      case 'solidaridad':
        return { label: 'Solidaridad', bg: 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300' };
      default:
        return { label: 'Otro', bg: 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300' };
    }
  };

  return (
    <div className="space-y-6 pb-20 animate-in fade-in">
      {/* Encabezado Principal */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
              <DollarSign className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
              Economía y Tesorería JMV
            </h1>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Cuota semanal de $1, ventas con inversión y cálculo de ganancia, gastos en actividades y balance.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={exportFeesToCSV}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition active:scale-95"
            title="Exportar archivo CSV con cuotas, inversiones y ventas"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Exportar Excel</span>
          </button>
          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 px-3 py-2 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 text-xs font-semibold transition"
            title="Imprimir reporte o guardar en PDF"
          >
            <Printer className="w-4 h-4" />
            <span className="hidden sm:inline">Imprimir / PDF</span>
          </button>
        </div>
      </div>

      {/* Banner de Identificación del Rol de Economía */}
      <div
        className={`p-4 rounded-3xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs transition ${
          canManageFinances
            ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-900 dark:text-emerald-200'
            : 'bg-blue-50/80 dark:bg-blue-950/30 border-blue-200 dark:border-blue-900/50 text-slate-700 dark:text-slate-300'
        }`}
      >
        <div className="flex items-center gap-3">
          <div
            className={`w-9 h-9 rounded-2xl flex items-center justify-center shrink-0 font-bold ${
              canManageFinances
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'bg-blue-900 text-white shadow-sm'
            }`}
          >
            {canManageFinances ? <ShieldCheck className="w-5 h-5" /> : <Lock className="w-4 h-4" />}
          </div>
          <div>
            <div className="font-bold flex items-center gap-1.5">
              <span>
                {canManageFinances
                  ? isTreasurer
                    ? '💰 Panel Activo del Encargado de Economía / Tesorería'
                    : '🛡️ Panel de Coordinador / Administrador (Acceso Total a Economía)'
                  : '🔍 Modo Transparente / Consulta Comunitaria'}
              </span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
              {canManageFinances
                ? 'Tienes autorización para registrar cuotas, aportes de inversión, entregas de ventas y gastos de actividades.'
                : `Solo la persona encargada de economía (${
                    treasurerUser?.name || 'Tesorero/a del grupo'
                  }) puede registrar pagos y gastos. Todos los miembros pueden consultar con total transparencia.`}
            </p>
          </div>
        </div>

        {/* Encargado oficial */}
        {treasurerUser && (
          <div className="flex items-center gap-2 self-start sm:self-auto bg-white dark:bg-slate-900 px-3 py-1.5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm shrink-0">
            <img
              src={treasurerUser.avatarUrl}
              alt={treasurerUser.name}
              className="w-5 h-5 rounded-full object-cover"
            />
            <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-300">
              Tesorero/a: <strong>{treasurerUser.name}</strong>
            </span>
          </div>
        )}
      </div>

      {/* Pestañas de Navegación del Módulo de Economía */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        <button
          onClick={() => setActiveTab('ventas_cuotas')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap transition active:scale-95 ${
            activeTab === 'ventas_cuotas'
              ? 'bg-blue-900 text-white shadow-md'
              : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50'
          }`}
        >
          <ShoppingBag className="w-4 h-4" />
          <span>Ventas, Inversión y Ganancias ({feeCampaigns.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('cuota_semanal')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap transition active:scale-95 ${
            activeTab === 'cuota_semanal'
              ? 'bg-blue-900 text-white shadow-md'
              : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50'
          }`}
        >
          <Shirt className="w-4 h-4" />
          <span>Cuota Semanal $1 (Chompas)</span>
        </button>

        <button
          onClick={() => setActiveTab('gastos_actividades')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap transition active:scale-95 ${
            activeTab === 'gastos_actividades'
              ? 'bg-blue-900 text-white shadow-md'
              : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50'
          }`}
        >
          <Receipt className="w-4 h-4" />
          <span>Gastos en Actividades (${totalExpenses.toFixed(2)})</span>
        </button>

        <button
          onClick={() => setActiveTab('balance_general')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap transition active:scale-95 ${
            activeTab === 'balance_general'
              ? 'bg-blue-900 text-white shadow-md'
              : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50'
          }`}
        >
          <PieChart className="w-4 h-4" />
          <span>Balance de Caja (${currentCashBalance.toFixed(2)})</span>
        </button>
      </div>

      {/* --------------------------------------------------------------------------------- */}
      {/* PESTAÑA 1: VENTAS COMUNITARIAS, INVERSIÓN INICIAL ($2) Y CÁLCULO DE GANANCIA REAL */}
      {/* --------------------------------------------------------------------------------- */}
      {activeTab === 'ventas_cuotas' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-purple-600" />
                Ventas Comunitarias: Inversión, Ventas y Ganancias
              </h2>
              <p className="text-xs text-slate-500">
                Ejemplo: venta de empanadas donde todos aportan $2.00 de inversión inicial y se calcula la ganancia neta.
              </p>
            </div>

            {canManageFinances && (
              <div className="flex items-center gap-2 flex-wrap shrink-0">
                {feeCampaigns.some((c) => ['camp-empanadas', 'camp-1', 'camp-2', 'camp-3'].includes(c.id)) && (
                  <button
                    type="button"
                    onClick={() => setShowCleanExampleCampaignsModal(true)}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-2xl bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/60 dark:hover:bg-amber-900/60 text-amber-900 dark:text-amber-300 font-bold text-xs border border-amber-200 dark:border-amber-800 transition"
                    title="Eliminar todas las ventas de ejemplo de una sola vez"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-amber-600" />
                    <span>Limpiar Ejemplos</span>
                  </button>
                )}

                <button
                  onClick={() => setShowNewCampaignModal(true)}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-2xl bg-purple-900 hover:bg-purple-800 text-white font-bold text-xs shadow-md transition active:scale-95 shrink-0"
                >
                  <Plus className="w-4 h-4" />
                  <span>+ Crear Nueva Venta / Actividad</span>
                </button>
              </div>
            )}
          </div>

          {/* Selector Horizontal de Campañas */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            {feeCampaigns.map((camp) => {
              const isSelected = (activeCampaign?.id || '') === camp.id;
              return (
                <button
                  key={camp.id}
                  onClick={() => setSelectedCampaignId(camp.id)}
                  className={`px-4 py-2 rounded-2xl text-xs font-bold whitespace-nowrap transition border ${
                    isSelected
                      ? 'bg-purple-900 text-white border-purple-900 shadow-md ring-2 ring-purple-400/40'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50'
                  }`}
                >
                  <span>{camp.title}</span>
                  {camp.investmentPerPerson && (
                    <span className="ml-1.5 text-[10px] opacity-80">
                      (${camp.investmentPerPerson} inv.)
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {activeCampaign ? (
            <div className="space-y-6">
              {/* TARJETA PRINCIPAL DE RENDICIÓN FINANCIERA: INVERSIÓN VS VENTAS VS GANANCIA */}
              <div className="p-6 rounded-3xl bg-gradient-to-br from-indigo-950 via-purple-950 to-slate-900 text-white shadow-xl border border-purple-800/40 space-y-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-400 text-slate-950">
                        {activeCampaign.type === 'venta' ? '🛍️ Venta Comunitaria' : '📌 Cuota Extraordinaria'}
                      </span>
                      <span className="text-xs text-purple-200 font-semibold">
                        Fecha límite: {new Date(activeCampaign.deadline || '').toLocaleDateString('es-ES', { day: 'numeric', month: 'short' })}
                      </span>
                    </div>
                    <h3 className="text-xl sm:text-2xl font-black text-white">
                      {activeCampaign.title}
                    </h3>
                    <p className="text-xs text-purple-200/90 mt-1 max-w-2xl leading-relaxed">
                      {activeCampaign.description}
                    </p>
                  </div>

                  {canManageFinances && (
                    <div className="flex items-center gap-2 flex-wrap self-start sm:self-auto shrink-0">
                      <button
                        onClick={() => {
                          setEditCostsAmount(activeCampaign.ingredientCosts || 0);
                          setShowEditCostsModal(activeCampaign);
                        }}
                        className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold backdrop-blur-sm border border-white/20 transition flex items-center gap-1.5"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                        <span>Editar Costo Insumos</span>
                      </button>

                      <button
                        onClick={() => {
                          setSaleMemberId(users[0]?.id || '');
                          setSaleQuantity(1);
                          setSaleStatus('pagado');
                          setSaleNote('');
                          setShowRecordSaleModal(activeCampaign);
                        }}
                        className="px-3.5 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-extrabold shadow transition flex items-center gap-1.5"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Sumar / Registrar Venta</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setCampaignToDelete(activeCampaign)}
                        className="px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-600 text-rose-200 hover:text-white text-xs font-bold border border-rose-400/40 transition flex items-center gap-1.5"
                        title="Eliminar esta venta o actividad"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Eliminar</span>
                      </button>
                    </div>
                  )}
                </div>

                {/* LAS 4 CAJAS DE RENDICIÓN FINANCIERA (INVERSIÓN -> INSUMOS -> VENTAS -> GANANCIA) */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-2">
                  {/* 1. Inversión Inicial */}
                  <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/10">
                    <div className="flex items-center justify-between text-amber-300 text-[11px] font-bold">
                      <span>1. Inversión Inicial</span>
                      <Coins className="w-4 h-4" />
                    </div>
                    <div className="mt-1.5 text-2xl font-black text-white tabular-nums">
                      ${totalInvestmentCollected.toFixed(2)}
                    </div>
                    <p className="text-[10px] text-purple-200 mt-1">
                      {totalInvestorsCount} de {users.length} miembros ({activeCampaign.investmentPerPerson ? `$${activeCampaign.investmentPerPerson} c/u` : '$2 c/u'})
                    </p>
                  </div>

                  {/* 2. Costo de Insumos */}
                  <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/10">
                    <div className="flex items-center justify-between text-red-300 text-[11px] font-bold">
                      <span>2. Costo de Insumos</span>
                      <Receipt className="w-4 h-4" />
                    </div>
                    <div className="mt-1.5 text-2xl font-black text-red-300 tabular-nums">
                      ${ingredientCosts.toFixed(2)}
                    </div>
                    <p className="text-[10px] text-purple-200 mt-1">
                      Masa, carne, aceite y empaques
                    </p>
                  </div>

                  {/* 3. Ventas Brutas Realizadas */}
                  <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/10">
                    <div className="flex items-center justify-between text-blue-300 text-[11px] font-bold">
                      <span>3. Ventas Totales</span>
                      <TrendingUp className="w-4 h-4" />
                    </div>
                    <div className="mt-1.5 text-2xl font-black text-white tabular-nums">
                      ${totalGrossSales.toFixed(2)}
                    </div>
                    <p className="text-[10px] text-purple-200 mt-1">
                      {totalUnitsSold} {activeCampaign.unitLabel}s vendidas a ${activeCampaign.unitPrice.toFixed(2)}
                    </p>
                  </div>

                  {/* 4. GANANCIA NETA FINAL (RESULTADO DEL NEGOCIO) */}
                  <div className="p-4 rounded-2xl bg-emerald-500/25 border-2 border-emerald-400 text-emerald-100 shadow-lg">
                    <div className="flex items-center justify-between text-emerald-300 text-[11px] font-black uppercase tracking-wider">
                      <span>4. ¡Ganancia Neta!</span>
                      <Sparkles className="w-4 h-4 text-amber-300" />
                    </div>
                    <div className="mt-1.5 text-2xl sm:text-3xl font-black text-emerald-300 tabular-nums">
                      +${netProfit.toFixed(2)} USD
                    </div>
                    <p className="text-[10px] text-emerald-200 font-semibold mt-1">
                      {profitMarginPercent > 0 ? `+${profitMarginPercent}% de rentabilidad grupal` : 'En punto de equilibrio'}
                    </p>
                  </div>
                </div>

                {/* Explicación Matemática Transparente */}
                <div className="p-3.5 rounded-2xl bg-black/30 border border-white/10 text-xs text-purple-100 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400" />
                    <span>
                      <strong>Fórmula de Ganancia:</strong> Ventas Totales (${totalGrossSales.toFixed(2)}) - Costo Insumos (${ingredientCosts.toFixed(2)}) = <strong>${netProfit.toFixed(2)} de ganancia para el grupo</strong>.
                    </span>
                  </div>
                  {totalInvestmentCollected > 0 && (
                    <span className="text-[11px] text-amber-300">
                      💡 Si se devuelve la inversión inicial de ${activeCampaign.investmentPerPerson || 2} a los miembros: ganancia líquida es <strong>${netProfitAfterRefund.toFixed(2)}</strong>.
                    </span>
                  )}
                </div>
              </div>

              {/* MATRIZ DE CONTROL DE INTEGRANTES: INVERSIÓN Y VENTAS POR PERSONA */}
              <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
                <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                      <Users className="w-4 h-4 text-purple-600" />
                      Registro por Integrante: Inversión de $2.00 y Ventas de Empanadas
                    </h3>
                    <p className="text-xs text-slate-500">
                      {canManageFinances
                        ? 'Toca el botón de Inversión para marcar quién ya puso su cuota, y registra las empanadas entregadas por cada uno.'
                        : 'Consulta transparente de aportes de inversión y ventas por hermano.'}
                    </p>
                  </div>

                  <span className="text-xs font-semibold px-3 py-1 rounded-xl bg-purple-50 dark:bg-purple-950 text-purple-700 dark:text-purple-300">
                    {totalInvestorsCount} de {users.length} han puesto su inversión inicial
                  </span>
                </div>

                {!canManageFinances && (
                  <div className="mx-4 mb-3 p-3 rounded-2xl bg-blue-50/80 dark:bg-blue-950/40 border border-blue-200/80 dark:border-blue-900/60 text-xs text-blue-900 dark:text-blue-300 flex items-center gap-2">
                    <Lock className="w-4 h-4 shrink-0 text-blue-600 dark:text-blue-400" />
                    <span>
                      <strong>Privacidad garantizada:</strong> Visualizando tu aporte e inversión personal. Por protección de datos, la lista completa del grupo solo está disponible para Coordinación y Tesorería.
                    </span>
                  </div>
                )}

                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left">
                    <thead>
                      <tr className="border-b border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                        <th className="py-3 px-4 min-w-[160px]">Integrante</th>
                        <th className="py-3 px-3 text-center min-w-[140px]">
                          Inversión Inicial (${activeCampaign.investmentPerPerson || 2}.00)
                        </th>
                        <th className="py-3 px-3 text-center min-w-[150px]">
                          {activeCampaign.unitLabel}s Vendidas
                        </th>
                        <th className="py-3 px-3 text-center min-w-[110px]">Total Entregado</th>
                        {canManageFinances && (
                          <th className="py-3 px-3 text-center min-w-[100px]">Acción</th>
                        )}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {(canManageFinances ? users : [currentUser]).map((user) => {
                        // Pago de inversión de este integrante
                        const invPayment = activeCampaignPayments.find(
                          (p) => p.userId === user.id && p.paymentType === 'inversion'
                        );
                        const hasPaidInvestment = invPayment?.status === 'pagado';

                        // Ventas entregadas por este integrante (pagadas + por entregar)
                        const memberSales = activeCampaignPayments.filter(
                          (p) => p.userId === user.id && p.paymentType !== 'inversion' && p.status === 'pagado'
                        );
                        const memberPendingSales = activeCampaignPayments.filter(
                          (p) => p.userId === user.id && p.paymentType !== 'inversion' && p.status === 'pendiente'
                        );
                        const totalSoldUnits = memberSales.reduce(
                          (acc, p) => acc + (p.quantity || 1),
                          0
                        );
                        const totalSoldAmount = memberSales.reduce((acc, p) => acc + p.amount, 0);
                        const pendingUnits = memberPendingSales.reduce(
                          (acc, p) => acc + (p.quantity || 1),
                          0
                        );

                        return (
                          <tr
                            key={user.id}
                            className={`hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition ${
                              user.id === currentUser.id ? 'bg-purple-50/30 dark:bg-purple-950/20' : ''
                            }`}
                          >
                            {/* Integrante */}
                            <td className="py-3 px-4">
                              <div className="flex items-center gap-2.5">
                                <img
                                  src={user.avatarUrl}
                                  alt={user.name}
                                  className="w-8 h-8 rounded-full object-cover shrink-0"
                                />
                                <div className="truncate">
                                  <span className="font-bold text-slate-900 dark:text-white block truncate">
                                    {user.name} {user.id === currentUser.id && '· Tú'}
                                  </span>
                                  <span className="text-[10px] text-slate-400">
                                    {user.role === 'admin'
                                      ? '🛡️ Coordinador'
                                      : user.role === 'tesorero' || user.isTreasurer
                                      ? '💰 Tesorero'
                                      : 'Integrante'}
                                  </span>
                                </div>
                              </div>
                            </td>

                            {/* Inversión Inicial ($2.00) con Toggle Interactivo */}
                            <td className="py-3 px-3 text-center">
                              {canManageFinances ? (
                                <button
                                  onClick={() =>
                                    toggleInvestmentPayment(
                                      activeCampaign.id,
                                      user.id,
                                      !hasPaidInvestment,
                                      activeCampaign.investmentPerPerson || 2.0
                                    )
                                  }
                                  title="Click para alternar estado de la inversión"
                                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold text-xs transition active:scale-95 ${
                                    hasPaidInvestment
                                      ? 'bg-emerald-500 hover:bg-emerald-600 text-white shadow-sm'
                                      : 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-300 dark:border-amber-700'
                                  }`}
                                >
                                  {hasPaidInvestment ? (
                                    <>
                                      <Check className="w-3.5 h-3.5" />
                                      <span>Inversión Pagada ($2)</span>
                                    </>
                                  ) : (
                                    <>
                                      <Clock className="w-3.5 h-3.5 text-amber-600" />
                                      <span>Falta $2 Inversión</span>
                                    </>
                                  )}
                                </button>
                              ) : (
                                <span
                                  className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-bold ${
                                    hasPaidInvestment
                                      ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                                      : 'bg-slate-100 text-slate-500 dark:bg-slate-800'
                                  }`}
                                >
                                  {hasPaidInvestment ? '✓ $2 Puesto' : 'Pendiente'}
                                </span>
                              )}
                            </td>

                            {/* Unidades Vendidas (Acumuladas) */}
                            <td className="py-3 px-3 text-center">
                              <div className="flex flex-col items-center">
                                <div>
                                  <span className="font-extrabold text-slate-900 dark:text-white tabular-nums text-sm">
                                    {totalSoldUnits}
                                  </span>
                                  <span className="text-[11px] text-slate-400 ml-1">
                                    {activeCampaign.unitLabel}s
                                  </span>
                                </div>
                                {memberSales.length > 1 && (
                                  <span className="text-[10px] text-purple-600 dark:text-purple-400 font-semibold">
                                    {memberSales.length} entregas sumadas
                                  </span>
                                )}
                                {pendingUnits > 0 && (
                                  <span className="text-[10px] text-amber-600 dark:text-amber-400 font-bold">
                                    +{pendingUnits} por entregar
                                  </span>
                                )}
                              </div>
                            </td>

                            {/* Total Entregado */}
                            <td className="py-3 px-3 text-center">
                              <div className="font-black text-emerald-600 dark:text-emerald-400 tabular-nums text-sm">
                                ${totalSoldAmount.toFixed(2)}
                              </div>
                              {totalSoldUnits > 0 && (
                                <div className="text-[10px] text-slate-400 tabular-nums">
                                  {totalSoldUnits} × ${activeCampaign.unitPrice.toFixed(2)}
                                </div>
                              )}
                            </td>

                            {/* Botón para sumar ventas de este miembro */}
                            {canManageFinances && (
                              <td className="py-3 px-3 text-center">
                                <button
                                  onClick={() => {
                                    setSaleMemberId(user.id);
                                    setSaleQuantity(1);
                                    setSaleStatus('pagado');
                                    setSaleNote('');
                                    setShowRecordSaleModal(activeCampaign);
                                  }}
                                  className="px-2.5 py-1 rounded-xl bg-purple-50 dark:bg-purple-950 hover:bg-purple-100 text-purple-800 dark:text-purple-300 font-bold text-[11px] border border-purple-200 dark:border-purple-800 transition"
                                >
                                  + Sumar Venta
                                </button>
                              </td>
                            )}
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-10 text-center rounded-3xl bg-white dark:bg-slate-900 border border-dashed border-slate-300 dark:border-slate-700 text-slate-500 space-y-3">
              <ShoppingBag className="w-10 h-10 mx-auto opacity-50 text-purple-600" />
              <div className="space-y-1">
                <p className="text-sm font-bold text-slate-800 dark:text-white">
                  No hay ventas ni actividades registradas
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Crea la primera actividad real de tu comunidad para empezar a registrar inversiones, ventas y ganancias.
                </p>
              </div>
              {canManageFinances && (
                <button
                  type="button"
                  onClick={() => setShowNewCampaignModal(true)}
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-2xl bg-purple-900 hover:bg-purple-800 text-white font-bold text-xs shadow-md transition"
                >
                  <Plus className="w-4 h-4" />
                  <span>Crear Nueva Venta / Actividad</span>
                </button>
              )}
            </div>
          )}
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* PESTAÑA 2: CUOTA SEMANAL DE $1 (CHOMPAS Y CAMISETAS) */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'cuota_semanal' && (
        <div className="space-y-6">
          {/* Tarjeta de Progreso de la Meta Grupal */}
          <div className="p-6 rounded-3xl bg-gradient-to-br from-emerald-900 via-teal-900 to-slate-900 text-white shadow-xl shadow-emerald-950/20">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="text-[10px] font-extrabold tracking-wider uppercase text-emerald-300 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" /> Meta Grupal: Chompas y Camisetas Oficiales
                </span>
                <div className="mt-2 flex items-baseline gap-3">
                  <span className="text-3xl sm:text-4xl font-black text-white tabular-nums">
                    ${totalWeeklyCollected}.00
                  </span>
                  <span className="text-emerald-200 text-sm">
                    recaudados de <strong>${settings.hoodieGoalAmount}.00 USD</strong>
                  </span>
                </div>
              </div>

              <div className="text-right sm:text-right">
                <span className="text-2xl font-black text-emerald-300 tabular-nums">
                  {hoodieGoalPercentage}%
                </span>
                <p className="text-[11px] text-emerald-100">
                  {weeklyPaymentsPaid.length} aportes de $1 registrados
                </p>
              </div>
            </div>

            {/* Barra de progreso */}
            <div className="mt-4 w-full h-3.5 rounded-full bg-black/30 overflow-hidden p-0.5 border border-white/10">
              <div
                className="h-full bg-gradient-to-r from-emerald-400 via-teal-300 to-amber-300 rounded-full transition-all duration-700 shadow-sm"
                style={{ width: `${hoodieGoalPercentage}%` }}
              />
            </div>

            <div className="mt-4 pt-3 border-t border-white/15 flex flex-wrap items-center justify-between text-xs text-emerald-100 gap-2">
              <span>
                👕 Valor estimado por persona: <strong>${settings.hoodieCostPerPerson}.00</strong>
              </span>

              {canManageFinances && (
                <button
                  onClick={addFeeWeek}
                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs shadow transition active:scale-95"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Agregar Semana {feeWeeks.length + 1}</span>
                </button>
              )}
            </div>
          </div>

          {/* Resumen personal del usuario actual (requiere aprobación de Admin) */}
          {isPendingApproval ? (
            <div className="p-5 rounded-3xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/50 text-amber-950 dark:text-amber-200 flex items-start gap-3">
              <Clock className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div className="space-y-1 text-xs">
                <h3 className="font-bold text-sm">
                  Aportes personales bloqueados temporalmente (Pendiente de Aprobación)
                </h3>
                <p className="leading-relaxed opacity-90">
                  Tu cuenta está en revisión. Una vez que el Administrador o Coordinador/a apruebe tu registro en el grupo, podrás ver tus aportes semanales de $1 y tu historial personal aquí.
                </p>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
                <span className="text-[10px] uppercase font-bold text-slate-400">Tu Total Pagado</span>
                <div className="text-xl font-extrabold text-emerald-600 dark:text-emerald-400 tabular-nums mt-1">
                  ${myTotalPaid}.00 USD
                </div>
                <span className="text-[11px] text-slate-500">{myPaidPayments.length} semanas al día</span>
              </div>

              <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
                <span className="text-[10px] uppercase font-bold text-slate-400">Cuotas Pendientes</span>
                <div className="text-xl font-extrabold text-amber-600 dark:text-amber-400 tabular-nums mt-1">
                  ${myPendingPayments.length}.00 USD
                </div>
                <span className="text-[11px] text-slate-500">
                  {myPendingPayments.length} semanas por cancelar
                </span>
              </div>

              <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
                <span className="text-[10px] uppercase font-bold text-slate-400">Para completar tu chompa</span>
                <div className="text-xl font-extrabold text-blue-900 dark:text-blue-400 tabular-nums mt-1">
                  ${Math.max(0, settings.hoodieCostPerPerson - myTotalPaid)}.00 USD
                </div>
                <span className="text-[11px] text-slate-500">
                  {myTotalPaid >= settings.hoodieCostPerPerson
                    ? '¡Ya completaste el 100%! 🎉'
                    : '¡Falta poco, ánimo!'}
                </span>
              </div>
            </div>
          )}

          {/* Filtros y Búsqueda (Protección de privacidad para integrantes) */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            {canManageFinances ? (
              <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800/80 rounded-2xl w-full sm:w-auto">
                <button
                  onClick={() => setFilterView('todos')}
                  className={`flex-1 sm:flex-none px-4 py-2 text-xs font-bold rounded-xl transition ${
                    filterView === 'todos'
                      ? 'bg-white dark:bg-slate-900 text-blue-900 dark:text-blue-400 shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  Matriz General del Grupo ({users.length})
                </button>
                <button
                  onClick={() => setFilterView('mis_cuotas')}
                  className={`flex-1 sm:flex-none px-4 py-2 text-xs font-bold rounded-xl transition ${
                    filterView === 'mis_cuotas'
                      ? 'bg-white dark:bg-slate-900 text-blue-900 dark:text-blue-400 shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  Solo Mi Historial ({currentUser.name.split(' ')[0]})
                </button>
              </div>
            ) : (
              <div className="p-3 rounded-2xl bg-blue-50/80 dark:bg-blue-950/40 border border-blue-200/80 dark:border-blue-900/60 text-xs text-blue-900 dark:text-blue-300 flex items-center gap-2">
                <Lock className="w-4 h-4 shrink-0 text-blue-600 dark:text-blue-400" />
                <span>
                  <strong>Privacidad de Cuotas:</strong> Solo tú y el equipo de Coordinación/Tesorería pueden ver tus aportes personales. Nadie más en el grupo tiene acceso a tus estados de pago.
                </span>
              </div>
            )}

            {canManageFinances && filterView === 'todos' && (
              <div className="relative flex-1 max-w-xs">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Buscar integrante..."
                  className="w-full pl-9 pr-3 py-2 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>
            )}
          </div>

          {/* TABLA DE CUOTAS SEMANALES */}
          {canManageFinances && filterView === 'todos' ? (
            <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
              <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="text-xs font-bold text-slate-900 dark:text-white">
                    Matriz de Cuotas Semanales ({feeWeeks.length} semanas creadas)
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    {canManageFinances
                      ? 'Toca cualquier casilla para alternar entre Pagado ($1) y Pendiente'
                      : 'Modo lectura para integrantes. Solo el tesorero registra pagos.'}
                  </p>
                </div>

                {canManageFinances && (
                  <button
                    onClick={addFeeWeek}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs transition"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>+ Agregar Semana {feeWeeks.length + 1}</span>
                  </button>
                )}
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead>
                    <tr className="border-b border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                      <th className="py-3 px-4 min-w-[160px] sticky left-0 bg-slate-50 dark:bg-slate-800 z-10 shadow-sm">
                        Integrante
                      </th>
                      <th className="py-3 px-3 text-center min-w-[70px]">Total</th>
                      {feeWeeks.map((w) => (
                        <th key={w.id} className="py-3 px-2 text-center min-w-[55px]">
                          Sem {w.weekNumber}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {displayedUsers.map((user) => {
                      const userPayments = feePayments.filter(
                        (p) => !p.campaignId && p.userId === user.id
                      );
                      const paidTotal = userPayments.filter((p) => p.status === 'pagado').length;

                      return (
                        <tr
                          key={user.id}
                          className={`hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition ${
                            user.id === currentUser.id ? 'bg-blue-50/40 dark:bg-blue-950/20' : ''
                          }`}
                        >
                          <td className="py-3 px-4 sticky left-0 bg-white dark:bg-slate-900 z-10 shadow-sm">
                            <div className="flex items-center gap-2.5">
                              <img
                                src={user.avatarUrl}
                                alt={user.name}
                                className="w-7 h-7 rounded-full object-cover shrink-0"
                              />
                              <div className="truncate">
                                <span className="font-bold text-slate-900 dark:text-white block truncate">
                                  {user.name} {user.id === currentUser.id && '· Tú'}
                                </span>
                                <span className="text-[10px] text-slate-400">
                                  {user.role === 'admin'
                                    ? '🛡️ Coordinador'
                                    : user.role === 'tesorero' || user.isTreasurer
                                    ? '💰 Tesorero'
                                    : 'Integrante'}
                                </span>
                              </div>
                            </div>
                          </td>

                          <td className="py-3 px-3 text-center font-extrabold text-blue-900 dark:text-blue-400 tabular-nums">
                            ${paidTotal}.00
                          </td>

                          {feeWeeks.map((week) => {
                            const payment = userPayments.find(
                              (p) => p.weekNumber === week.weekNumber
                            );
                            const isPaid = payment?.status === 'pagado';

                            return (
                              <td key={week.id} className="py-2 px-1 text-center">
                                {canManageFinances ? (
                                  <button
                                    onClick={() =>
                                      markFeePayment(user.id, week.weekNumber, !isPaid)
                                    }
                                    title={`${user.name} - Sem ${week.weekNumber}: Click para marcar como ${
                                      isPaid ? 'Pendiente' : 'Pagado'
                                    }`}
                                    className={`w-8 h-8 rounded-xl mx-auto flex items-center justify-center font-bold text-xs transition active:scale-90 ${
                                      isPaid
                                        ? 'bg-emerald-500 text-white shadow-sm hover:bg-emerald-600'
                                        : 'bg-slate-100 dark:bg-slate-800 text-slate-400 hover:bg-slate-200'
                                    }`}
                                  >
                                    {isPaid ? <Check className="w-4 h-4" /> : '$1'}
                                  </button>
                                ) : (
                                  <div
                                    className={`w-8 h-8 rounded-xl mx-auto flex items-center justify-center font-bold text-xs ${
                                      isPaid
                                        ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300'
                                        : 'bg-slate-100 dark:bg-slate-800 text-slate-400'
                                    }`}
                                  >
                                    {isPaid ? '✓' : '-'}
                                  </div>
                                )}
                              </td>
                            );
                          })}
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          ) : isPendingApproval ? (
            <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 text-center space-y-2">
              <Lock className="w-8 h-8 text-amber-500 mx-auto" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Historial Personal en Espera de Aprobación
              </h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                Cuando el Administrador valide tu registro en JMV, se habilitará aquí el detalle semana por semana de tus aportes de $1.00 USD.
              </p>
            </div>
          ) : (
            /* Vista individual del historial */
            <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 shadow-sm space-y-4">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Historial Personal de Cuotas: {currentUser.name}
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3">
                {feeWeeks.map((w) => {
                  const p = feePayments.find(
                    (pay) => !pay.campaignId && pay.userId === currentUser.id && pay.weekNumber === w.weekNumber
                  );
                  const isPaid = p?.status === 'pagado';

                  return (
                    <div
                      key={w.id}
                      className={`p-3 rounded-2xl border text-center transition ${
                        isPaid
                          ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300'
                          : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      <span className="text-[10px] font-bold uppercase tracking-wider block">
                        Semana {w.weekNumber}
                      </span>
                      <span className="text-base font-extrabold block my-1">$1.00 USD</span>
                      <span
                        className={`inline-block px-2 py-0.5 rounded-full text-[9px] font-extrabold uppercase ${
                          isPaid ? 'bg-emerald-200 dark:bg-emerald-900 text-emerald-900 dark:text-emerald-200' : 'bg-slate-200 dark:bg-slate-700'
                        }`}
                      >
                        {isPaid ? 'Pagado' : 'Pendiente'}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* PESTAÑA 3: GASTOS EN ACTIVIDADES (EGRESOS) */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'gastos_actividades' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <Receipt className="w-5 h-5 text-red-500" />
                Gastos Registrados en Actividades y Misiones
              </h2>
              <p className="text-xs text-slate-500">
                Rendición transparente de cuentas con comprobantes de compras, transporte y refrigerios.
              </p>
            </div>

            {canManageFinances && (
              <button
                onClick={() => setShowNewExpenseModal(true)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-2xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-md transition active:scale-95 shrink-0"
              >
                <Plus className="w-4 h-4" />
                <span>+ Registrar Nuevo Gasto</span>
              </button>
            )}
          </div>

          {/* Tarjeta de Resumen de Egresos */}
          <div className="p-4 sm:p-5 rounded-3xl bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-900/40 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-red-700 dark:text-red-400 block">
                Total de Egresos del Grupo
              </span>
              <span className="text-2xl sm:text-3xl font-black text-red-600 dark:text-red-400 tabular-nums">
                ${totalExpenses.toFixed(2)} USD
              </span>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300 max-w-sm">
              Cada gasto debe estar respaldado por la aprobación del asesor o coordinador, indicando la actividad y guardando su factura o recibo.
            </p>
          </div>

          {/* Lista de Gastos */}
          <div className="space-y-3">
            {activityExpenses.length > 0 ? (
              activityExpenses.map((exp) => {
                const badge = getCategoryBadge(exp.category);

                return (
                  <div
                    key={exp.id}
                    className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                  >
                    <div className="flex items-start gap-3.5">
                      <div className="w-11 h-11 rounded-2xl bg-red-50 dark:bg-red-950/40 border border-red-100 dark:border-red-900/40 flex items-center justify-center text-red-600 shrink-0 font-bold">
                        <TrendingDown className="w-5 h-5" />
                      </div>

                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider ${badge.bg}`}>
                            {badge.label}
                          </span>
                          <span className="text-xs text-slate-400">
                            · {new Date(exp.date).toLocaleDateString('es-ES', { day: 'numeric', month: 'short', year: 'numeric' })}
                          </span>
                        </div>

                        <h4 className="text-sm font-bold text-slate-900 dark:text-white mt-1">
                          {exp.title}
                        </h4>

                        {exp.description && (
                          <p className="text-xs text-slate-500 mt-0.5">
                            {exp.description}
                          </p>
                        )}

                        <div className="mt-1 flex items-center gap-2 text-[11px] text-slate-400">
                          <span>Actividad: {exp.activityTitle || 'General'}</span>
                          <span>· Registrado por: {exp.registeredBy}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0 pt-2 sm:pt-0 border-t sm:border-0 border-slate-100 dark:border-slate-800">
                      {exp.receiptUrl && (
                        <a
                          href={exp.receiptUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[11px] font-semibold flex items-center gap-1 hover:bg-slate-200"
                        >
                          <Receipt className="w-3.5 h-3.5" />
                          <span>Comprobante</span>
                        </a>
                      )}

                      <span className="text-base font-black text-red-600 dark:text-red-400 tabular-nums">
                        -${exp.amount.toFixed(2)} USD
                      </span>

                      {canManageFinances && (
                        <button
                          onClick={() => {
                            if (confirm(`¿Eliminar el gasto "${exp.title}"?`)) {
                              deleteActivityExpense(exp.id);
                            }
                          }}
                          className="p-1.5 text-slate-400 hover:text-red-500 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                          title="Eliminar gasto"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="p-8 text-center rounded-3xl bg-white dark:bg-slate-900 border border-dashed border-slate-200 dark:border-slate-800 text-slate-400">
                <Receipt className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm font-bold">No hay gastos registrados todavía.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* PESTAÑA 4: BALANCE GENERAL DE CAJA Y DESIGNACIÓN */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'balance_general' && (
        <div className="space-y-6">
          <div>
            <h2 className="text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <PieChart className="w-5 h-5 text-blue-900 dark:text-blue-400" />
              Estado de Caja y Balance de Tesorería
            </h2>
            <p className="text-xs text-slate-500">
              Resumen financiero global consolidando cuotas semanales, ventas y gastos de actividades.
            </p>
          </div>

          {/* Tarjetas de Tres Columnas: Ingresos, Gastos, Saldo */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
              <div className="flex items-center justify-between text-emerald-600">
                <span className="text-xs font-bold uppercase tracking-wider">Total Ingresos</span>
                <TrendingUp className="w-5 h-5" />
              </div>
              <div className="mt-2 text-2xl sm:text-3xl font-black text-emerald-600 dark:text-emerald-400 tabular-nums">
                +${totalIncome.toFixed(2)} USD
              </div>
              <div className="mt-2 text-[11px] text-slate-500 space-y-0.5">
                <p>· Cuota Semanal $1: ${totalWeeklyCollected.toFixed(2)}</p>
                <p>· Ventas y Cuotas extras: ${totalCampaignsCollected.toFixed(2)}</p>
              </div>
            </div>

            <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
              <div className="flex items-center justify-between text-red-500">
                <span className="text-xs font-bold uppercase tracking-wider">Total Gastos</span>
                <TrendingDown className="w-5 h-5" />
              </div>
              <div className="mt-2 text-2xl sm:text-3xl font-black text-red-500 dark:text-red-400 tabular-nums">
                -${totalExpenses.toFixed(2)} USD
              </div>
              <p className="mt-2 text-[11px] text-slate-500">
                {activityExpenses.length} egresos documentados con comprobantes.
              </p>
            </div>

            <div className="p-5 rounded-3xl bg-gradient-to-br from-blue-900 via-indigo-900 to-slate-900 text-white shadow-xl">
              <div className="flex items-center justify-between text-amber-300">
                <span className="text-xs font-bold uppercase tracking-wider">Saldo en Caja Actual</span>
                <Sparkles className="w-5 h-5" />
              </div>
              <div className="mt-2 text-2xl sm:text-3xl font-black text-white tabular-nums">
                ${currentCashBalance.toFixed(2)} USD
              </div>
              <p className="mt-2 text-[11px] text-blue-200">
                Fondo disponible en efectivo / cuenta para gastos comunitarios.
              </p>
            </div>
          </div>

          {/* Designación de la Persona Encargada de Economía (Solo para Administradores) */}
          {isAdmin && (
            <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-blue-900 dark:text-blue-400" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Designar Encargado/a de Economía (Tesorero/a)
                </h3>
              </div>
              <p className="text-xs text-slate-500">
                Como coordinador general, puedes seleccionar a un integrante de confianza para que gestione las cuotas, registre los gastos y cree las ventas en la aplicación.
              </p>

              <div className="flex flex-wrap items-center gap-3">
                <div className="flex-1 min-w-[200px]">
                  <select
                    value={treasurerUser?.id || ''}
                    onChange={(e) => setTreasurerUser(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs font-semibold"
                  >
                    {users.map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.name} ({u.role === 'admin' ? 'Coordinador' : u.role === 'tesorero' || u.isTreasurer ? 'Tesorero actual' : 'Integrante'})
                      </option>
                    ))}
                  </select>
                </div>
                <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                  ✓ Rol de Tesorería Activo
                </span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* MODAL: CREAR NUEVA CUOTA / CAMPAÑA DE VENTA */}
      {/* ---------------------------------------------------- */}
      {showNewCampaignModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-md w-full overflow-hidden p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-purple-600" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Crear Nueva Venta o Cuota
                </h3>
              </div>
              <button
                onClick={() => setShowNewCampaignModal(false)}
                className="p-1 rounded-xl text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateCampaignSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Título de la Actividad o Venta *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ej: Venta de Empanadas Caseras"
                  value={campaignTitle}
                  onChange={(e) => setCampaignTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-bold"
                />
              </div>

              {/* SECCIÓN DE INVERSIÓN INICIAL POR INTEGRANTE */}
              <div className="p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/50 space-y-2.5">
                <div className="flex items-center gap-1.5 font-bold text-amber-800 dark:text-amber-300">
                  <Coins className="w-4 h-4 text-amber-600" />
                  <span>Inversión Inicial de los Integrantes ($2.00)</span>
                </div>
                <p className="text-[11px] text-slate-600 dark:text-slate-400">
                  Cada integrante aportará este capital semilla para comprar los insumos (masa, carne, aceite).
                </p>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                      Inversión por persona ($ USD)
                    </label>
                    <input
                      type="number"
                      step="0.50"
                      min="0"
                      required
                      value={campaignInvestmentPerPerson}
                      onChange={(e) => setCampaignInvestmentPerPerson(Number(e.target.value))}
                      className="w-full px-3.5 py-2 rounded-xl border border-amber-300 dark:border-amber-800 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-bold"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                      Gasto en ingredientes ($ USD)
                    </label>
                    <input
                      type="number"
                      step="0.50"
                      min="0"
                      required
                      value={campaignIngredientCosts}
                      onChange={(e) => setCampaignIngredientCosts(Number(e.target.value))}
                      className="w-full px-3.5 py-2 rounded-xl border border-amber-300 dark:border-amber-800 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-bold"
                    />
                  </div>
                </div>
              </div>

              {/* DATOS DE VENTA */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Etiqueta del producto
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="empanada, plato, porción"
                    value={campaignUnitLabel}
                    onChange={(e) => setCampaignUnitLabel(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Precio de Venta ($ USD)
                  </label>
                  <input
                    type="number"
                    step="0.25"
                    min="0.25"
                    required
                    value={campaignUnitPrice}
                    onChange={(e) => setCampaignUnitPrice(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Meta en Ventas ($ USD)
                  </label>
                  <input
                    type="number"
                    step="5"
                    min="10"
                    required
                    value={campaignGoal}
                    onChange={(e) => setCampaignGoal(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-bold"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Fecha límite
                  </label>
                  <input
                    type="date"
                    required
                    value={campaignDeadline}
                    onChange={(e) => setCampaignDeadline(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Descripción o propósito
                </label>
                <textarea
                  rows={2}
                  placeholder="Detalles sobre lo que se recaudará y su propósito..."
                  value={campaignDesc}
                  onChange={(e) => setCampaignDesc(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-purple-900 hover:bg-purple-800 text-white font-bold text-xs shadow transition"
              >
                Crear Actividad de Venta
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* MODAL: AJUSTAR COSTO DE INSUMOS O INGREDIENTES */}
      {/* ---------------------------------------------------- */}
      {showEditCostsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-sm w-full overflow-hidden p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-red-500" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Editar Gasto en Insumos
                </h3>
              </div>
              <button
                onClick={() => setShowEditCostsModal(null)}
                className="p-1 rounded-xl text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleUpdateCostsSubmit} className="space-y-3 text-xs">
              <p className="text-xs text-slate-500">
                Ajusta el total gastado en los ingredientes (masa, carne, aceite, recipientes) para calcular con exactitud la ganancia neta de <strong>{showEditCostsModal.title}</strong>.
              </p>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Costo Total de Insumos ($ USD)
                </label>
                <input
                  type="number"
                  step="0.50"
                  min="0"
                  required
                  value={editCostsAmount}
                  onChange={(e) => setEditCostsAmount(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-bold text-base"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-purple-900 hover:bg-purple-800 text-white font-bold text-xs shadow transition"
              >
                Actualizar Costos y Recalcular Ganancia
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* MODAL: REGISTRAR GASTO EN ACTIVIDAD */}
      {/* ---------------------------------------------------- */}
      {showNewExpenseModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-md w-full overflow-hidden p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-red-600" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Registrar Gasto de Actividad
                </h3>
              </div>
              <button
                onClick={() => setShowNewExpenseModal(false)}
                className="p-1 rounded-xl text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateExpenseSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Concepto o Nombre del Gasto
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ej: Refrigerios y jugos para la Jornada Solidaria"
                  value={expenseTitle}
                  onChange={(e) => setExpenseTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Monto ($ USD)
                  </label>
                  <input
                    type="number"
                    step="0.50"
                    min="0.50"
                    required
                    value={expenseAmount}
                    onChange={(e) => setExpenseAmount(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-bold"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Fecha del Gasto
                  </label>
                  <input
                    type="date"
                    required
                    value={expenseDate}
                    onChange={(e) => setExpenseDate(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Categoría
                  </label>
                  <select
                    value={expenseCategory}
                    onChange={(e) =>
                      setExpenseCategory(e.target.value as ActivityExpense['category'])
                    }
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  >
                    <option value="refrigerio">Refrigerios y Alimentos</option>
                    <option value="materiales">Materiales y Papelería</option>
                    <option value="transporte">Transporte y Movilización</option>
                    <option value="espiritualidad">Espiritualidad y Liturgia</option>
                    <option value="solidaridad">Solidaridad y Caridad</option>
                    <option value="otro">Otro</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Actividad Vinculada
                  </label>
                  <select
                    value={expenseActivityTitle}
                    onChange={(e) => setExpenseActivityTitle(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  >
                    <option value="Gasto general del grupo">Gasto general del grupo</option>
                    {activities.map((a) => (
                      <option key={a.id} value={a.title}>
                        {a.title}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Subida de foto comprobante */}
              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Comprobante o Factura (Opcional)
                </label>
                <div className="flex items-center gap-3">
                  <label className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-semibold text-xs hover:bg-slate-200">
                    <Upload className="w-4 h-4" />
                    <span>{isCompressingReceipt ? 'Comprimiendo...' : 'Subir Foto / Recibo'}</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleReceiptUpload}
                      className="hidden"
                    />
                  </label>
                  {expenseReceipt && (
                    <span className="text-[11px] text-emerald-600 font-bold">✓ Foto lista</span>
                  )}
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Notas adicionales
                </label>
                <textarea
                  rows={2}
                  placeholder="Detalles sobre proveedores, personas beneficiadas, etc..."
                  value={expenseDesc}
                  onChange={(e) => setExpenseDesc(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow transition"
              >
                Registrar Gasto
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* MODAL: REGISTRAR / SUMAR VENTAS POR INTEGRANTE */}
      {/* ---------------------------------------------------- */}
      {showRecordSaleModal && (() => {
        const selectedMember = users.find((u) => u.id === saleMemberId) || users[0];
        const memberAllSales = feePayments.filter(
          (p) =>
            p.campaignId === showRecordSaleModal.id &&
            p.userId === saleMemberId &&
            p.paymentType !== 'inversion'
        );
        const paidSales = memberAllSales.filter((p) => p.status === 'pagado');
        const currentPaidUnits = paidSales.reduce((acc, p) => acc + (p.quantity || 1), 0);
        const currentPaidAmount = paidSales.reduce((acc, p) => acc + p.amount, 0);
        const addedQty = Math.max(0, Number(saleQuantity) || 0);
        const addedAmount = addedQty * showRecordSaleModal.unitPrice;
        const projectedUnits = currentPaidUnits + (saleStatus === 'pagado' ? addedQty : 0);
        const projectedAmount = currentPaidAmount + (saleStatus === 'pagado' ? addedAmount : 0);

        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto p-6 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Sumar Ventas: {showRecordSaleModal.title}
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    ${showRecordSaleModal.unitPrice.toFixed(2)} por {showRecordSaleModal.unitLabel} · Se acumula al total del integrante
                  </p>
                </div>
                <button
                  onClick={() => setShowRecordSaleModal(null)}
                  className="p-1 rounded-xl text-slate-400 hover:text-slate-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleRecordSaleSubmit} className="space-y-3 text-xs">
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Integrante que realiza / entrega la venta
                  </label>
                  <div className="flex items-center gap-2.5">
                    {selectedMember && (
                      <img
                        src={selectedMember.avatarUrl}
                        alt={selectedMember.name}
                        className="w-9 h-9 rounded-full object-cover ring-2 ring-purple-200 dark:ring-purple-800 shrink-0"
                      />
                    )}
                    <select
                      value={saleMemberId}
                      onChange={(e) => setSaleMemberId(e.target.value)}
                      className="flex-1 px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-semibold"
                    >
                      {users.map((u) => (
                        <option key={u.id} value={u.id}>
                          {u.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Resumen de acumulado y suma en tiempo real */}
                <div className="p-3 rounded-2xl bg-purple-50/80 dark:bg-purple-950/40 border border-purple-200/80 dark:border-purple-900/60 space-y-1.5">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-slate-600 dark:text-slate-300 font-medium">
                      Acumulado actual entregado:
                    </span>
                    <span className="font-bold text-slate-900 dark:text-white tabular-nums">
                      {currentPaidUnits} {showRecordSaleModal.unitLabel}s (${currentPaidAmount.toFixed(2)})
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] pt-1 border-t border-purple-200/60 dark:border-purple-800/60">
                    <span className="text-purple-900 dark:text-purple-200 font-bold">
                      Nuevo total acumulado:
                    </span>
                    <span className="font-black text-emerald-700 dark:text-emerald-400 tabular-nums">
                      {projectedUnits} {showRecordSaleModal.unitLabel}s × ${showRecordSaleModal.unitPrice.toFixed(2)} = ${projectedAmount.toFixed(2)} USD
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                      Nuevas a sumar ({showRecordSaleModal.unitLabel}s)
                    </label>
                    <input
                      type="number"
                      min="1"
                      required
                      value={saleQuantity}
                      onChange={(e) => setSaleQuantity(Number(e.target.value))}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-bold"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                      Valor de esta entrega
                    </label>
                    <div className="w-full px-3.5 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 font-black text-emerald-600 dark:text-emerald-400 tabular-nums">
                      +${addedAmount.toFixed(2)} USD
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Estado del Dinero
                  </label>
                  <div className="flex items-center gap-3">
                    <label className="flex items-center gap-1.5 cursor-pointer font-semibold">
                      <input
                        type="radio"
                        name="saleStatus"
                        checked={saleStatus === 'pagado'}
                        onChange={() => setSaleStatus('pagado')}
                        className="text-emerald-600"
                      />
                      <span>Entregado en efectivo</span>
                    </label>
                    <label className="flex items-center gap-1.5 cursor-pointer font-semibold">
                      <input
                        type="radio"
                        name="saleStatus"
                        checked={saleStatus === 'pendiente'}
                        onChange={() => setSaleStatus('pendiente')}
                        className="text-amber-600"
                      />
                      <span>Por entregar</span>
                    </label>
                  </div>
                </div>

                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Nota o Comentario (Opcional)
                  </label>
                  <input
                    type="text"
                    placeholder="Ej: Segunda ronda vendida el domingo"
                    value={saleNote}
                    onChange={(e) => setSaleNote(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-purple-900 hover:bg-purple-800 text-white font-bold text-xs shadow transition active:scale-95"
                >
                  + Sumar Venta al Acumulado
                </button>
              </form>

              {/* Historial de entregas individuales de este integrante */}
              {memberAllSales.length > 0 && (
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
                  <div className="flex items-center justify-between text-[11px] font-bold text-slate-600 dark:text-slate-300">
                    <span>Entregas registradas ({memberAllSales.length})</span>
                    <span className="text-slate-400 font-normal">Puedes cobrar o corregir</span>
                  </div>
                  <div className="max-h-40 overflow-y-auto space-y-1.5 pr-1">
                    {memberAllSales.map((entry) => (
                      <div
                        key={entry.id}
                        className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700 flex items-center justify-between gap-2 text-[11px]"
                      >
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="font-extrabold text-slate-900 dark:text-white">
                              +{entry.quantity || 1} {showRecordSaleModal.unitLabel}s
                            </span>
                            <span className="font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
                              (${entry.amount.toFixed(2)})
                            </span>
                            <span
                              className={`px-1.5 py-0.5 rounded-full text-[9px] font-bold ${
                                entry.status === 'pagado'
                                  ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                                  : 'bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300'
                              }`}
                            >
                              {entry.status === 'pagado' ? 'Entregado' : 'Por entregar'}
                            </span>
                          </div>
                          {entry.note && (
                            <p className="text-[10px] text-slate-500 truncate">{entry.note}</p>
                          )}
                        </div>
                        <div className="flex items-center gap-1 shrink-0">
                          {entry.status !== 'pagado' && (
                            <button
                              type="button"
                              onClick={() => markCampaignSalePaid(entry.id, true)}
                              title="Marcar como entregado en efectivo"
                              className="px-2 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px] transition"
                            >
                              Cobrar
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => deleteCampaignSalePayment(entry.id)}
                            title="Eliminar esta entrega"
                            className="p-1.5 rounded-lg text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/60 transition"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        );
      })()}

      {/* MODAL: CONFIRMAR ELIMINACIÓN DE VENTA / ACTIVIDAD INDIVIDUAL */}
      {campaignToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-sm w-full p-6 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2 text-rose-600 dark:text-rose-400 font-bold text-sm">
                <Trash2 className="w-4 h-4" />
                <span>Eliminar Venta / Actividad</span>
              </div>
              <button
                onClick={() => setCampaignToDelete(null)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700 text-xs space-y-1">
              <p className="font-bold text-slate-900 dark:text-white">{campaignToDelete.title}</p>
              <p className="text-slate-500 dark:text-slate-400">
                Se eliminará esta actividad junto con sus registros de inversión y ventas asociadas.
              </p>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => setCampaignToDelete(null)}
                className="flex-1 py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-semibold text-xs hover:bg-slate-50 dark:hover:bg-slate-800 transition"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  const remaining = feeCampaigns.filter((c) => c.id !== campaignToDelete.id);
                  deleteFeeCampaign(campaignToDelete.id);
                  setSelectedCampaignId(remaining[0]?.id || '');
                  setCampaignToDelete(null);
                }}
                className="flex-1 py-2.5 px-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow transition flex items-center justify-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Sí, Eliminar</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: LIMPIAR TODAS LAS VENTAS DE EJEMPLO */}
      {showCleanExampleCampaignsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-sm w-full p-6 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400 font-bold text-sm">
                <Trash2 className="w-4 h-4" />
                <span>Limpiar Ventas de Ejemplo</span>
              </div>
              <button
                onClick={() => setShowCleanExampleCampaignsModal(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/50 text-xs text-amber-900 dark:text-amber-200 space-y-1.5">
              <p className="font-bold">¿Deseas quitar las actividades de muestra?</p>
              <p>
                Se eliminarán las ventas de ejemplo iniciales (Empanadas, Pollada, Postres y Bus Convivencia) y sus montos de prueba, conservando cualquier actividad real que hayas creado.
              </p>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => setShowCleanExampleCampaignsModal(false)}
                className="flex-1 py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-semibold text-xs hover:bg-slate-50 dark:hover:bg-slate-800 transition"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  const remaining = feeCampaigns.filter(
                    (c) => !['camp-empanadas', 'camp-1', 'camp-2', 'camp-3'].includes(c.id)
                  );
                  cleanExampleCampaigns();
                  setSelectedCampaignId(remaining[0]?.id || '');
                  setShowCleanExampleCampaignsModal(false);
                }}
                className="flex-1 py-2.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow transition flex items-center justify-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Limpiar Ejemplos</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
