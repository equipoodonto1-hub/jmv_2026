import React, { useState } from 'react';
import {
  UserCheck,
  Award,
  CheckCircle,
  XCircle,
  AlertCircle,
  Plus,
  Sparkles,
  Calendar,
  X,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const AttendanceView: React.FC = () => {
  const { users, attendanceSessions, recordAttendance, isAdmin, currentUser } = useApp();

  const [showRecordModal, setShowRecordModal] = useState(false);
  const [meetingTitle, setMeetingTitle] = useState('Reunión Semanal de Formación');
  const [meetingDate, setMeetingDate] = useState(
    new Date().toISOString().split('T')[0]
  );
  const [attendanceDraft, setAttendanceDraft] = useState<
    Record<string, 'presente' | 'justificado' | 'ausente'>
  >(() => {
    const draft: Record<string, 'presente' | 'justificado' | 'ausente'> = {};
    users.forEach((u) => {
      draft[u.id] = 'presente';
    });
    return draft;
  });

  // Calcular porcentaje de asistencia por usuario
  const totalSessions = attendanceSessions.length;

  const userStats = users.map((user) => {
    let presentCount = 0;
    let justifiedCount = 0;
    let absentCount = 0;

    attendanceSessions.forEach((session) => {
      const record = session.records.find((r) => r.userId === user.id);
      if (record?.status === 'presente') presentCount++;
      else if (record?.status === 'justificado') justifiedCount++;
      else if (record?.status === 'ausente') absentCount++;
    });

    // Justificado cuenta como 0.5 o no penaliza
    const rate = totalSessions > 0 ? Math.round((presentCount / totalSessions) * 100) : 100;

    return {
      user,
      presentCount,
      justifiedCount,
      absentCount,
      rate,
      isConstant: rate >= 80,
    };
  });

  const handleSaveAttendance = (e: React.FormEvent) => {
    e.preventDefault();
    if (!meetingTitle.trim()) return;

    const records = users.map((u) => ({
      userId: u.id,
      status: attendanceDraft[u.id] || 'presente',
    }));

    recordAttendance(meetingTitle.trim(), meetingDate, records);
    setShowRecordModal(false);
  };

  return (
    <div className="space-y-6 pb-20 animate-in fade-in">
      {/* Encabezado */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400">
              <UserCheck className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
              Registro de Asistencia y Constancia
            </h1>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Control de asistencia por reunión formativa y reconocimiento a la fidelidad vicenciana.
          </p>
        </div>

        {isAdmin && (
          <button
            onClick={() => setShowRecordModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow-md transition active:scale-95 shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Pasar Asistencia Hoy</span>
          </button>
        )}
      </div>

      {/* Reconocimiento a la Constancia */}
      <div className="p-6 rounded-3xl bg-gradient-to-br from-amber-500 via-amber-600 to-yellow-600 text-slate-950 shadow-xl">
        <div className="flex items-center gap-2 text-xs font-black uppercase tracking-wider text-amber-950">
          <Sparkles className="w-4 h-4" /> Cuadro de Honor Vicenciano (Constancia $\ge$ 80%)
        </div>
        <h2 className="text-lg font-black mt-1">¡Fidelidad y Alegría en la Misión!</h2>
        <p className="text-xs text-amber-950/80 mt-1 max-w-xl">
          Quienes perseveran semana a semana son los cimientos de nuestra comunidad juvenil.
        </p>

        <div className="mt-4 flex flex-wrap gap-2.5">
          {userStats
            .filter((s) => s.isConstant)
            .map((s) => (
              <div
                key={s.user.id}
                className="flex items-center gap-2 p-1.5 pr-3 rounded-full bg-white/90 backdrop-blur-sm text-xs font-bold text-slate-900 shadow-sm"
              >
                <img
                  src={s.user.avatarUrl}
                  alt={s.user.name}
                  className="w-7 h-7 rounded-full object-cover ring-2 ring-amber-400"
                />
                <span>{s.user.name}</span>
                <span className="text-[10px] font-extrabold px-1.5 py-0.2 rounded-full bg-amber-100 text-amber-800">
                  {s.rate}%
                </span>
              </div>
            ))}
        </div>
      </div>

      {/* Tabla de Asistencia por Integrante */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-900 dark:text-white">
            Porcentaje General de Asistencia ({totalSessions} reuniones evaluadas)
          </h3>
          <span className="text-[11px] text-slate-400">Total integrantes: {users.length}</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="border-b border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                <th className="py-3 px-4">Integrante</th>
                <th className="py-3 px-3 text-center">Asistencias</th>
                <th className="py-3 px-3 text-center">Justificadas</th>
                <th className="py-3 px-3 text-center">Faltas</th>
                <th className="py-3 px-4 text-center">Porcentaje</th>
                <th className="py-3 px-4 text-center">Distinción</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {userStats.map((stat) => (
                <tr
                  key={stat.user.id}
                  className={`hover:bg-slate-50 dark:hover:bg-slate-800/50 transition ${
                    stat.user.id === currentUser.id ? 'bg-blue-50/40 dark:bg-blue-950/20' : ''
                  }`}
                >
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2.5">
                      <img
                        src={stat.user.avatarUrl}
                        alt={stat.user.name}
                        className="w-8 h-8 rounded-full object-cover"
                      />
                      <div>
                        <span className="font-bold text-slate-900 dark:text-white block">
                          {stat.user.name} {stat.user.id === currentUser.id && '· Tú'}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          {stat.user.role === 'admin' ? 'Coordinador' : 'Integrante'}
                        </span>
                      </div>
                    </div>
                  </td>

                  <td className="py-3 px-3 text-center font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
                    {stat.presentCount}
                  </td>
                  <td className="py-3 px-3 text-center text-amber-600 dark:text-amber-400 tabular-nums">
                    {stat.justifiedCount}
                  </td>
                  <td className="py-3 px-3 text-center text-red-500 tabular-nums">
                    {stat.absentCount}
                  </td>

                  <td className="py-3 px-4 text-center">
                    <div className="inline-flex items-center gap-2">
                      <div className="w-16 h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                        <div
                          className="h-full bg-blue-900 dark:bg-blue-400 rounded-full"
                          style={{ width: `${stat.rate}%` }}
                        />
                      </div>
                      <span className="font-extrabold text-blue-900 dark:text-blue-400 tabular-nums">
                        {stat.rate}%
                      </span>
                    </div>
                  </td>

                  <td className="py-3 px-4 text-center">
                    {stat.isConstant ? (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-700 dark:text-amber-400 bg-amber-100 dark:bg-amber-950/60 px-2.5 py-0.5 rounded-full">
                        <Award className="w-3 h-3" /> Constante
                      </span>
                    ) : (
                      <span className="text-[11px] text-slate-400">En progreso</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Historial de reuniones evaluadas */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm p-5 space-y-4">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Calendar className="w-4 h-4 text-blue-600" /> Historial de Sesiones Registradas
        </h3>

        <div className="space-y-3">
          {attendanceSessions.map((s) => {
            const presentCount = s.records.filter((r) => r.status === 'presente').length;

            return (
              <div
                key={s.id}
                className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
              >
                <div>
                  <h4 className="font-bold text-slate-900 dark:text-white text-xs">{s.title}</h4>
                  <span className="text-[10px] text-slate-400">
                    Fecha: {new Date(s.date).toLocaleDateString('es-ES', { day: 'numeric', month: 'long', year: 'numeric' })}
                  </span>
                </div>

                <div className="flex items-center gap-3 text-xs">
                  <span className="text-emerald-600 dark:text-emerald-400 font-semibold">
                    {presentCount} presentes de {s.records.length}
                  </span>
                  <span className="text-[10px] text-slate-400">
                    ({Math.round((presentCount / s.records.length) * 100)}% asistencia)
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Modal: Pasar Asistencia */}
      {showRecordModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="w-full max-w-lg rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 animate-in fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                Pasar Asistencia de Reunión
              </h3>
              <button onClick={() => setShowRecordModal(false)} className="text-slate-400">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveAttendance} className="mt-4 space-y-3.5 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Nombre de la reunión *
                  </label>
                  <input
                    type="text"
                    required
                    value={meetingTitle}
                    onChange={(e) => setMeetingTitle(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Fecha *
                  </label>
                  <input
                    type="date"
                    required
                    value={meetingDate}
                    onChange={(e) => setMeetingDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs"
                  />
                </div>
              </div>

              <div className="mt-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <span className="block font-bold text-slate-700 dark:text-slate-300 mb-2">
                  Marcar asistencia por integrante:
                </span>

                <div className="max-h-60 overflow-y-auto space-y-2 pr-1">
                  {users.map((u) => (
                    <div
                      key={u.id}
                      className="p-2 rounded-2xl bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2">
                        <img src={u.avatarUrl} alt={u.name} className="w-6 h-6 rounded-full object-cover" />
                        <span className="font-semibold text-xs text-slate-800 dark:text-slate-200">{u.name}</span>
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => setAttendanceDraft({ ...attendanceDraft, [u.id]: 'presente' })}
                          className={`px-2 py-1 rounded-lg text-[10px] font-bold ${
                            attendanceDraft[u.id] === 'presente'
                              ? 'bg-emerald-600 text-white'
                              : 'bg-white dark:bg-slate-800 text-slate-600'
                          }`}
                        >
                          Presente
                        </button>
                        <button
                          type="button"
                          onClick={() => setAttendanceDraft({ ...attendanceDraft, [u.id]: 'justificado' })}
                          className={`px-2 py-1 rounded-lg text-[10px] font-bold ${
                            attendanceDraft[u.id] === 'justificado'
                              ? 'bg-amber-500 text-slate-950'
                              : 'bg-white dark:bg-slate-800 text-slate-600'
                          }`}
                        >
                          Justificado
                        </button>
                        <button
                          type="button"
                          onClick={() => setAttendanceDraft({ ...attendanceDraft, [u.id]: 'ausente' })}
                          className={`px-2 py-1 rounded-lg text-[10px] font-bold ${
                            attendanceDraft[u.id] === 'ausente'
                              ? 'bg-red-500 text-white'
                              : 'bg-white dark:bg-slate-800 text-slate-600'
                          }`}
                        >
                          Falta
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow mt-2"
              >
                Guardar Registro de Asistencia
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
