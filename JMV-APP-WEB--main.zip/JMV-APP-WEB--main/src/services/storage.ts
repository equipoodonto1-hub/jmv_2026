import {
  UserProfile,
  WeeklyChallenge,
  ChallengeSubmission,
  FeeWeek,
  FeePayment,
  ChatMessage,
  ActivityEvent,
  ServiceExperience,
  PhotoAlbum,
  PhotoItem,
  SecretFriendRound,
  SecretMessage,
  PrayerRequest,
  MeetingReminder,
  AttendanceSession,
  Poll,
  AdvisorReflection,
  FeeCampaign,
  ActivityExpense,
  PasswordRecoveryRequest,
  GroupSummary,
} from '../types';

import heroYouthImg from '../assets/images/jmv_hero_youth_1794117311900.jpg';
import marianMedalImg from '../assets/images/jmv_marian_medal_1794117311829.jpg';
import serviceExpImg from '../assets/images/jmv_service_experience_1794117312126.jpg';
import groupRetreatImg from '../assets/images/jmv_group_retreat_1794117313130.jpg';

export const normalizeGroupKey = (groupName?: string): string => {
  const raw = String(groupName || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
  return raw || 'default';
};

const GLOBAL_KEYS = {
  LEGACY_GROUP_KEY: 'jmv_legacy_group_key_v1',
  ACTIVE_GROUP_KEY: 'jmv_active_group_key_v1',
  GROUPS_REGISTRY: 'jmv_groups_registry_v1',
};

const STORAGE_KEYS = {
  USERS: 'jmv_users_v1',
  CURRENT_USER_ID: 'jmv_current_user_id_v1',
  CHALLENGES: 'jmv_challenges_v1',
  SUBMISSIONS: 'jmv_submissions_v1',
  FEE_WEEKS: 'jmv_fee_weeks_v1',
  FEE_PAYMENTS: 'jmv_fee_payments_v1',
  FEE_CAMPAIGNS: 'jmv_fee_campaigns_v1',
  ACTIVITY_EXPENSES: 'jmv_activity_expenses_v1',
  CHAT_MESSAGES: 'jmv_chat_messages_v1',
  ACTIVITIES: 'jmv_activities_v1',
  SERVICE_EXPERIENCES: 'jmv_service_experiences_v1',
  PHOTO_ALBUMS: 'jmv_photo_albums_v1',
  PHOTO_ITEMS: 'jmv_photo_items_v1',
  SECRET_FRIEND_ROUNDS: 'jmv_secret_friend_rounds_v1',
  SECRET_MESSAGES: 'jmv_secret_messages_v1',
  PRAYERS: 'jmv_prayers_v1',
  REMINDERS: 'jmv_reminders_v1',
  ATTENDANCE: 'jmv_attendance_v1',
  POLLS: 'jmv_polls_v1',
  REFLECTIONS: 'jmv_reflections_v1',
  GROUP_SETTINGS: 'jmv_group_settings_v1',
  PASSWORD_REQUESTS: 'jmv_password_requests_v1',
};

// Configuración general del grupo
export interface GroupSettings {
  groupKey?: string;
  groupName: string;
  parishName?: string;
  logoUrl?: string;
  invitationCode: string;
  hoodieGoalAmount: number;
  hoodieCostPerPerson: number;
  advisorName: string;
  nextMeetingDate: string; // ISO date string
  meetingLocation: string;
  bannerPalette?: string; // ID de paleta (ej: 'azul-mariano', 'esmeralda-esperanza', etc.)
  bannerImageUrl?: string; // Foto propia de los jóvenes de la comunidad
  bannerImageOpacity?: number; // 20, 30, 45, 60 % de visibilidad
  emailjsServiceId?: string;
  emailjsTemplateId?: string;
  emailjsPublicKey?: string;
}

const DEFAULT_SETTINGS: GroupSettings = {
  groupName: 'JMV Santa María de la Esperanza',
  parishName: 'Parroquia San Vicente de Paúl',
  logoUrl: marianMedalImg,
  invitationCode: 'JMV2026',
  hoodieGoalAmount: 480, // Meta para chompas y camisetas
  hoodieCostPerPerson: 40,
  advisorName: 'Padre Javier Martínez, C.M.',
  nextMeetingDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000 + 4 * 60 * 60 * 1000).toISOString(),
  meetingLocation: 'Salón Juvenil Parroquial San Vicente',
  bannerPalette: 'azul-mariano',
  bannerImageUrl: heroYouthImg,
  bannerImageOpacity: 30,
};

// Admin de ejemplo garantizado para acceso inicial o recuperación si se borraron los ejemplos
export const EXAMPLE_ADMIN: UserProfile = {
  id: 'user-admin-1',
  name: 'Andrés Morales (Admin Ejemplo)',
  email: 'andres.jmv@gmail.com',
  cedula: '1720000001',
  password: 'admin',
  status: 'aprobado',
  role: 'admin',
  isTreasurer: true, // Coordinador con acceso a tesorería
  avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
  birthday: '1999-04-12',
  phone: '+593 99 123 4567',
  joinedAt: '2023-01-15',
  points: 480,
  badges: ['constancia', 'servicio', 'alegria', 'oracion', 'fraternidad'],
  imageConsentAccepted: true,
  isMinor: false,
};

// Datos semilla de integrantes
const INITIAL_USERS: UserProfile[] = [
  EXAMPLE_ADMIN,
  {
    id: 'user-2',
    name: 'Sofía Martínez',
    email: 'sofia.martinez@gmail.com',
    cedula: '1720000002',
    password: 'sofia',
    status: 'aprobado',
    role: 'integrante',
    avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80',
    birthday: '2004-11-14', // Cumpleaños próximo
    phone: '+593 98 765 4321',
    joinedAt: '2023-03-20',
    points: 390,
    badges: ['servicio', 'alegria', 'oracion'],
    imageConsentAccepted: true,
    isMinor: false,
  },
  {
    id: 'user-3',
    name: 'Carlos Paredes',
    email: 'carlos.paredes@gmail.com',
    cedula: '1720000003',
    password: 'carlos',
    status: 'aprobado',
    role: 'tesorero',
    isTreasurer: true, // Encargado oficial de economía y tesorería JMV
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
    birthday: '2005-02-28',
    phone: '+593 97 456 7890',
    joinedAt: '2023-06-10',
    points: 340,
    badges: ['constancia', 'servicio'],
    imageConsentAccepted: true,
    isMinor: false,
  },
  {
    id: 'user-4',
    name: 'Lucía Fernández',
    email: 'lucia.jmv@gmail.com',
    cedula: '1720000004',
    password: 'lucia',
    status: 'aprobado',
    role: 'integrante',
    avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=200&q=80',
    birthday: '2006-11-20', // Cumpleaños este mes
    phone: '+593 96 321 6549',
    joinedAt: '2023-08-01',
    points: 410,
    badges: ['alegria', 'fraternidad', 'oracion'],
    imageConsentAccepted: true,
    isMinor: true,
    tutorName: 'Rosa Fernández (Madre)',
    tutorPhone: '+593 96 111 2233',
  },
  {
    id: 'user-5',
    name: 'Mateo Ramírez',
    email: 'mateo.ramirez@gmail.com',
    cedula: '1720000005',
    password: 'mateo',
    status: 'aprobado',
    role: 'integrante',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80',
    birthday: '2004-07-09',
    phone: '+593 95 888 7766',
    joinedAt: '2023-04-15',
    points: 290,
    badges: ['servicio', 'alegria'],
    imageConsentAccepted: true,
    isMinor: false,
  },
  {
    id: 'user-6',
    name: 'Camila Silva',
    email: 'camila.silva@gmail.com',
    cedula: '1720000006',
    password: 'camila',
    status: 'aprobado',
    role: 'integrante',
    avatarUrl: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=200&q=80',
    birthday: '2005-12-03',
    phone: '+593 94 333 4455',
    joinedAt: '2023-09-12',
    points: 310,
    badges: ['constancia', 'oracion'],
    imageConsentAccepted: true,
    isMinor: false,
  },
];

// Semanas de cuota de 1 USD (total 16 semanas para financiar chompas y camisetas)
const INITIAL_FEE_WEEKS: FeeWeek[] = Array.from({ length: 12 }, (_, i) => {
  const weekNum = i + 1;
  const d = new Date();
  d.setDate(d.getDate() - (12 - weekNum) * 7);
  return {
    id: `week-${weekNum}`,
    weekNumber: weekNum,
    title: `Semana ${weekNum}`,
    date: d.toISOString().split('T')[0],
    amount: 1.0,
  };
});

// Pagos registrados de cuota
const generateInitialPayments = (): FeePayment[] => {
  const payments: FeePayment[] = [];
  INITIAL_USERS.forEach((u) => {
    // Simular que la mayoría pagó semanas 1 a 6
    const paidWeeksCount = u.id === 'user-admin-1' ? 9 : u.id === 'user-2' ? 8 : u.id === 'user-3' ? 6 : 5;
    for (let w = 1; w <= 12; w++) {
      const isPaid = w <= paidWeeksCount;
      payments.push({
        id: `pay-${u.id}-${w}`,
        userId: u.id,
        userName: u.name,
        weekId: `week-${w}`,
        weekNumber: w,
        amount: 1.0,
        status: isPaid ? 'pagado' : 'pendiente',
        paidAt: isPaid ? new Date(Date.now() - (12 - w) * 7 * 86400000).toISOString() : undefined,
        registeredBy: isPaid ? 'Andrés Morales (Tesorero)' : undefined,
      });
    }
  });

  // Aportes de inversión inicial para la Venta de Empanadas ($2.00 por integrante)
  INITIAL_USERS.forEach((u, idx) => {
    const isPaid = idx < 5; // 5 de 6 integrantes ya entregaron su inversión de $2
    payments.push({
      id: `pay-inv-empanadas-${u.id}`,
      campaignId: 'camp-empanadas',
      userId: u.id,
      userName: u.name,
      paymentType: 'inversion',
      amount: 2.0,
      status: isPaid ? 'pagado' : 'pendiente',
      paidAt: isPaid ? new Date(Date.now() - 2 * 86400000).toISOString() : undefined,
      registeredBy: isPaid ? 'Carlos Paredes (Tesorero)' : undefined,
      note: 'Inversión inicial para masa, carne y aceite',
    });
  });

  // Ventas de empanadas entregadas por integrantes ($1 c/u)
  const sampleSales = [
    { userId: 'user-admin-1', quantity: 15, amount: 15.0 },
    { userId: 'user-2', quantity: 18, amount: 18.0 },
    { userId: 'user-3', quantity: 20, amount: 20.0 },
    { userId: 'user-4', quantity: 12, amount: 12.0 },
  ];

  sampleSales.forEach((s) => {
    const u = INITIAL_USERS.find((usr) => usr.id === s.userId);
    payments.push({
      id: `pay-sale-empanadas-${s.userId}`,
      campaignId: 'camp-empanadas',
      userId: s.userId,
      userName: u?.name || 'Integrante',
      paymentType: 'venta',
      quantity: s.quantity,
      amount: s.amount,
      status: 'pagado',
      paidAt: new Date(Date.now() - 1 * 86400000).toISOString(),
      registeredBy: 'Carlos Paredes (Tesorero)',
      note: `${s.quantity} empanadas entregadas ($1 c/u)`,
    });
  });

  return payments;
};

// Campañas de ventas y cuotas adicionales
const INITIAL_FEE_CAMPAIGNS: FeeCampaign[] = [
  {
    id: 'camp-empanadas',
    title: 'Venta de Empanadas Caseras JMV',
    description: 'Actividad de recaudación pro-retiro. Cada integrante aporta $2.00 de capital de inversión para los ingredientes (masa, carne, aceite) y luego vendemos las empanadas a $1.00 cada una para obtener ganancias.',
    type: 'venta',
    unitLabel: 'empanada',
    unitPrice: 1.00,
    targetGoal: 80.0,
    investmentPerPerson: 2.00,
    ingredientCosts: 16.50,
    deadline: '2026-11-29',
    createdAt: new Date(Date.now() - 3 * 86400000).toISOString(),
    isActive: true,
    createdBy: 'Carlos Paredes (Tesorero)',
  },
  {
    id: 'camp-1',
    title: 'Venta de Pollada Pro-Retiro Juvenil',
    description: 'Venta de platos de pollada con ensalada y papas para costear el transporte y hospedaje del retiro anual.',
    type: 'venta',
    unitLabel: 'plato',
    unitPrice: 3.50,
    targetGoal: 140.0,
    investmentPerPerson: 1.50,
    ingredientCosts: 35.00,
    deadline: '2026-11-28',
    createdAt: new Date(Date.now() - 5 * 86400000).toISOString(),
    isActive: true,
    createdBy: 'Carlos Paredes (Tesorero)',
  },
  {
    id: 'camp-2',
    title: 'Venta de Postres y Gelatinas Caseras',
    description: 'Postres elaborados por la comunidad juvenil vendidos a la salida de las misas dominicales.',
    type: 'venta',
    unitLabel: 'porción',
    unitPrice: 1.50,
    targetGoal: 60.0,
    investmentPerPerson: 1.00,
    ingredientCosts: 12.00,
    deadline: '2026-12-06',
    createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
    isActive: true,
    createdBy: 'Carlos Paredes (Tesorero)',
  },
  {
    id: 'camp-3',
    title: 'Cuota Extraordinaria: Bus Convivencia Mariana',
    description: 'Aporte personal para el alquiler del autobús a la jornada diocesana.',
    type: 'extraordinaria',
    unitLabel: 'cuota',
    unitPrice: 2.00,
    targetGoal: 40.0,
    deadline: '2026-12-15',
    createdAt: new Date(Date.now() - 8 * 86400000).toISOString(),
    isActive: true,
    createdBy: 'Carlos Paredes (Tesorero)',
  },
];

// Gastos registrados en actividades comunitarias
const INITIAL_ACTIVITY_EXPENSES: ActivityExpense[] = [
  {
    id: 'exp-1',
    title: 'Refrigerios, frutas y galletas para la Jornada Solidaria',
    description: 'Compra de víveres para compartir con los abuelitos y niños del comedor Santa Luisa.',
    activityTitle: 'Jornada Solidaria: Comedor Santa Luisa',
    amount: 16.50,
    date: '2026-11-05',
    category: 'refrigerio',
    registeredBy: 'Carlos Paredes (Tesorero)',
    registeredById: 'user-3',
    createdAt: new Date(Date.now() - 3 * 86400000).toISOString(),
  },
  {
    id: 'exp-2',
    title: 'Velas, antorchas y cartulinas para el Rosario Iluminado',
    description: 'Materiales litúrgicos y antorchas para la vigilia y rezo con los jóvenes.',
    activityTitle: 'Rosario Iluminado por la Juventud',
    amount: 12.00,
    date: '2026-10-28',
    category: 'espiritualidad',
    registeredBy: 'Carlos Paredes (Tesorero)',
    registeredById: 'user-3',
    createdAt: new Date(Date.now() - 11 * 86400000).toISOString(),
  },
  {
    id: 'exp-3',
    title: 'Pasajes de transporte público para visitas a enfermos',
    description: 'Movilización del grupo misionero a sectores alejados de la parroquia.',
    activityTitle: 'Misión Vicenciana: Visita a Familias',
    amount: 8.00,
    date: '2026-10-20',
    category: 'transporte',
    registeredBy: 'Carlos Paredes (Tesorero)',
    registeredById: 'user-3',
    createdAt: new Date(Date.now() - 19 * 86400000).toISOString(),
  },
];

// Retos semanales
const INITIAL_CHALLENGES: WeeklyChallenge[] = [
  {
    id: 'ch-active-1',
    title: 'Misión Vicenciana: Visita y Alegría',
    description: 'Dedica 30 minutos a visitar o llamar a un abuelito, familiar enfermo o vecino que viva solo. Llévale una sonrisa, escucha con paciencia y comparte una oración sencilla.',
    points: 50,
    reward: 'Elegir la dinámica del sábado + Insignia de Servicio',
    startDate: new Date(Date.now() - 3 * 86400000).toISOString().split('T')[0],
    endDate: new Date(Date.now() + 4 * 86400000).toISOString().split('T')[0],
    isActive: true,
    createdBy: 'Andrés Morales',
  },
  {
    id: 'ch-past-1',
    title: 'Rosario Joven por las Familias',
    description: 'Rezar un misterio del Santo Rosario ofreciéndolo por la paz y unión de las familias de nuestro grupo JMV.',
    points: 40,
    reward: 'Sticker conmemorativo de la Virgen Milagrosa',
    startDate: new Date(Date.now() - 10 * 86400000).toISOString().split('T')[0],
    endDate: new Date(Date.now() - 3 * 86400000).toISOString().split('T')[0],
    isActive: false,
    createdBy: 'Andrés Morales',
  },
];

const INITIAL_SUBMISSIONS: ChallengeSubmission[] = [
  {
    id: 'sub-1',
    challengeId: 'ch-active-1',
    userId: 'user-2',
    userName: 'Sofía Martínez',
    userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80',
    submittedAt: new Date(Date.now() - 1 * 86400000).toISOString(),
    comment: 'Fui con mi mamá a visitar a doña Rosa, le llevamos unas frutas y rezamos el Padrenuestro juntos. ¡Fue una tarde hermosa y llena de paz!',
    imageUrl: serviceExpImg,
    status: 'approved',
    approvedBy: 'Andrés Morales',
    approvedAt: new Date(Date.now() - 12 * 3600000).toISOString(),
  },
  {
    id: 'sub-2',
    challengeId: 'ch-active-1',
    userId: 'user-4',
    userName: 'Lucía Fernández',
    userAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=200&q=80',
    submittedAt: new Date(Date.now() - 6 * 3600000).toISOString(),
    comment: 'Llamé a mi tía abuela en el campo que vive solita, estuvimos hablando casi una hora de sus recuerdos. Me bendijo mucho.',
    status: 'pending',
  },
];

// Mensajes de chat
const INITIAL_CHAT_MESSAGES: ChatMessage[] = [
  {
    id: 'msg-pinned-1',
    userId: 'user-admin-1',
    userName: 'Andrés Morales',
    userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    userRole: 'admin',
    text: '🌟 ¡Bienvenidos chicos! Recordatorio: este sábado tenemos ensayo de cantos a las 16:00 y nuestra reunión a las 17:00 en el salón parroquial. Traigan su Biblia y su cuota semanal de 1 dólar para las chompas.',
    createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
    isPinned: true,
    pinnedBy: 'Andrés Morales',
    reactions: { '❤️': ['user-2', 'user-4', 'user-5'], '🙌': ['user-3', 'user-6'] },
  },
  {
    id: 'msg-2',
    userId: 'user-2',
    userName: 'Sofía Martínez',
    userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80',
    userRole: 'integrante',
    text: '¡Hola a todos! Qué alegría ver la aplicación activa. ¿Quién lleva la guitarra este sábado?',
    createdAt: new Date(Date.now() - 1 * 86400000 + 3600000).toISOString(),
    reactions: { '🎸': ['user-3', 'user-5'] },
  },
  {
    id: 'msg-3',
    userId: 'user-3',
    userName: 'Carlos Paredes',
    userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
    userRole: 'integrante',
    text: 'Yo la llevo con gusto Carlos. Ya tengo afinadas las canciones del cancionero mariano 🎶',
    createdAt: new Date(Date.now() - 1 * 86400000 + 7200000).toISOString(),
    reactions: { '👏': ['user-2', 'user-4'] },
  },
  {
    id: 'msg-4',
    userId: 'user-4',
    userName: 'Lucía Fernández',
    userAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=200&q=80',
    userRole: 'integrante',
    text: 'Miren la foto del compartir del sábado pasado, ¡quedó hermosa!',
    imageUrl: heroYouthImg,
    createdAt: new Date(Date.now() - 4 * 3600000).toISOString(),
    reactions: { '❤️': ['user-admin-1', 'user-2', 'user-3', 'user-5', 'user-6'] },
  },
];

// Actividades del mes
const INITIAL_ACTIVITIES: ActivityEvent[] = [
  {
    id: 'act-1',
    title: 'Reunión Semanal de Formación y Dinámicas',
    description: 'Tema formativo: "La Medalla Milagrosa en el siglo XXI: Llevar esperanza a los jóvenes". Trae tu cuaderno y tu espíritu alegre.',
    type: 'reunion',
    date: new Date(Date.now() + 3 * 86400000).toISOString().split('T')[0],
    time: '17:00 - 19:00',
    location: 'Salón Parroquial San Vicente de Paúl',
    createdBy: 'Andrés Morales',
    attendees: [
      { userId: 'user-admin-1', userName: 'Andrés Morales', userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80', status: 'voy' },
      { userId: 'user-2', userName: 'Sofía Martínez', userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80', status: 'voy' },
      { userId: 'user-3', userName: 'Carlos Paredes', userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80', status: 'voy' },
      { userId: 'user-4', userName: 'Lucía Fernández', userAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=200&q=80', status: 'voy' },
    ],
  },
  {
    id: 'act-2',
    title: 'Jornada Solidaria: Entrega de Canastas Vicentinas',
    description: 'Visita a 15 familias del barrio Cristo Rey para entrega de víveres recolectados por el grupo, escucha y oración comunitaria.',
    type: 'servicio',
    date: new Date(Date.now() + 10 * 86400000).toISOString().split('T')[0],
    time: '09:00 - 13:00',
    location: 'Punto de encuentro: Atrio de la Parroquia',
    createdBy: 'Andrés Morales',
    attendees: [
      { userId: 'user-admin-1', userName: 'Andrés Morales', userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80', status: 'voy' },
      { userId: 'user-2', userName: 'Sofía Martínez', userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80', status: 'voy' },
      { userId: 'user-5', userName: 'Mateo Ramírez', userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80', status: 'tal_vez' },
    ],
  },
  {
    id: 'act-3',
    title: 'Fogata y Noche de Vigilia Juvenil',
    description: 'Espacio de oración bajo las estrellas, fogata, cantos con guitarra, testimonios de fe y consagración mariana.',
    type: 'retiro',
    date: new Date(Date.now() + 18 * 86400000).toISOString().split('T')[0],
    time: '19:30 - 22:30',
    location: 'Patio de la Casa de Retiro Betania',
    createdBy: 'Andrés Morales',
    attendees: [
      { userId: 'user-admin-1', userName: 'Andrés Morales', userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80', status: 'voy' },
      { userId: 'user-3', userName: 'Carlos Paredes', userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80', status: 'voy' },
    ],
  },
];

// Experiencias de servicio
const INITIAL_SERVICE_EXPERIENCES: ServiceExperience[] = [
  {
    id: 'srv-1',
    userId: 'user-2',
    userName: 'Sofía Martínez',
    userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80',
    title: 'Comedor Solidario "Santa Luisa de Marillac"',
    description: 'Servir el almuerzo a más de 60 abuelitos y personas en situación de calle nos enseñó que la caridad vicenciana no es dar lo que nos sobra, sino compartir con respeto, ternura y alegría. Don Manuel nos regaló una sonrisa que guardo en el corazón.',
    location: 'Comedor Santa Luisa',
    date: new Date(Date.now() - 5 * 86400000).toISOString().split('T')[0],
    imageUrl: serviceExpImg,
    likes: ['user-admin-1', 'user-3', 'user-4', 'user-5'],
    reactions: { oracion: 8, amor: 12, inspirador: 10 },
    comments: [
      {
        id: 'c-1',
        userId: 'user-admin-1',
        userName: 'Andrés Morales',
        userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
        text: '¡Qué gran testimonio Sofía! San Vicente decía: "El amor es inventivo hasta el infinito". Dios bendiga tus manos servidoras.',
        createdAt: new Date(Date.now() - 4 * 86400000).toISOString(),
      },
    ],
  },
  {
    id: 'srv-2',
    userId: 'user-3',
    userName: 'Carlos Paredes',
    userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
    title: 'Tarde de Juegos y Apoyo Escolar con los Niños',
    description: 'Fuimos al oratorio del barrio San Vicente a ayudar a los niños con sus tareas escolares y luego organizamos partidos de fútbol y dinámicas de grupo. Su energía y abrazos nos recargaron el alma a todos los voluntarios.',
    location: 'Oratorio San Vicente',
    date: new Date(Date.now() - 12 * 86400000).toISOString().split('T')[0],
    likes: ['user-admin-1', 'user-2', 'user-4'],
    reactions: { oracion: 5, amor: 9, inspirador: 7 },
    comments: [],
  },
];

// Álbumes de fotos
const INITIAL_ALBUMS: PhotoAlbum[] = [
  {
    id: 'alb-1',
    title: 'Retiro "Luz en la Noche" 2026',
    description: 'Momentos de oración, fraternidad y fogata en nuestro retiro espiritual.',
    coverUrl: groupRetreatImg,
    date: '2026-03',
    photoCount: 18,
  },
  {
    id: 'alb-2',
    title: 'Jornada Solidaria de Víveres',
    description: 'Armado de kits de ayuda y visitas a familias del sector.',
    coverUrl: serviceExpImg,
    date: '2026-02',
    photoCount: 24,
  },
  {
    id: 'alb-3',
    title: 'Encuentro Mariano y Deportes',
    description: 'Integración, música, dinámicas y torneo relámpago de vóley.',
    coverUrl: heroYouthImg,
    date: '2026-01',
    photoCount: 32,
  },
];

const INITIAL_PHOTOS: PhotoItem[] = [
  {
    id: 'ph-1',
    albumId: 'alb-1',
    url: groupRetreatImg,
    caption: 'Oración comunitaria alrededor de la fogata bajo las estrellas ✨',
    uploadedBy: 'user-admin-1',
    uploadedByName: 'Andrés Morales',
    uploadedAt: new Date(Date.now() - 8 * 86400000).toISOString(),
    likes: ['user-2', 'user-3', 'user-4'],
    comments: [{ id: 'pc-1', userId: 'user-2', userName: 'Sofía', text: '¡Esa noche fue inolvidable!', createdAt: new Date().toISOString() }],
  },
  {
    id: 'ph-2',
    albumId: 'alb-2',
    url: serviceExpImg,
    caption: 'Listos para repartir las donaciones con la mejor sonrisa vicenciana.',
    uploadedBy: 'user-2',
    uploadedByName: 'Sofía Martínez',
    uploadedAt: new Date(Date.now() - 6 * 86400000).toISOString(),
    likes: ['user-admin-1', 'user-4', 'user-5'],
    comments: [],
  },
  {
    id: 'ph-3',
    albumId: 'alb-3',
    url: heroYouthImg,
    caption: '¡La familia JMV unida celebrando nuestro aniversario de grupo!',
    uploadedBy: 'user-3',
    uploadedByName: 'Carlos Paredes',
    uploadedAt: new Date(Date.now() - 14 * 86400000).toISOString(),
    likes: ['user-admin-1', 'user-2', 'user-4', 'user-6'],
    comments: [],
  },
];

// Amigo Secreto Semanal
const INITIAL_SECRET_ROUND: SecretFriendRound = {
  id: 'round-1',
  title: 'Semana de la Fraternidad Mariana',
  startDate: new Date(Date.now() - 4 * 86400000).toISOString().split('T')[0],
  revealDate: new Date(Date.now() + 3 * 86400000).toISOString().split('T')[0],
  status: 'active',
  // Sorteo circular cerrado (ninguno se asigna a sí mismo)
  assignments: [
    { giverId: 'user-admin-1', receiverId: 'user-2' }, // Andrés regala a Sofía
    { giverId: 'user-2', receiverId: 'user-3' }, // Sofía regala a Carlos
    { giverId: 'user-3', receiverId: 'user-4' }, // Carlos regala a Lucía
    { giverId: 'user-4', receiverId: 'user-5' }, // Lucía regala a Mateo
    { giverId: 'user-5', receiverId: 'user-6' }, // Mateo regala a Camila
    { giverId: 'user-6', receiverId: 'user-admin-1' }, // Camila regala a Andrés
  ],
};

const INITIAL_SECRET_MESSAGES: SecretMessage[] = [
  {
    id: 'sm-1',
    roundId: 'round-1',
    giverId: 'user-admin-1',
    receiverId: 'user-2',
    dayNumber: 1,
    text: '🕊️ Día 1 - Oración por ti: Hoy ofrecí mi día y el Padrenuestro de la mañana por tus proyectos y tu familia. ¡Que la Virgen te cuide siempre!',
    sentAt: new Date(Date.now() - 3 * 86400000).toISOString(),
  },
  {
    id: 'sm-2',
    roundId: 'round-1',
    giverId: 'user-admin-1',
    receiverId: 'user-2',
    dayNumber: 2,
    text: '🌟 Día 2 - Frase motivacional: "Ten valor en todo lo que emprendas, Dios camina a tu lado". Tu alegría en las reuniones ilumina a todo el grupo.',
    sentAt: new Date(Date.now() - 2 * 86400000).toISOString(),
  },
  {
    id: 'sm-3',
    roundId: 'round-1',
    giverId: 'user-6',
    receiverId: 'user-admin-1',
    dayNumber: 1,
    text: '🙏 Día 1: Gracias por tu paciencia guiando a JMV. Hoy pedí por tu fuerza y paz interior.',
    sentAt: new Date(Date.now() - 3 * 86400000).toISOString(),
  },
];

// Muro de oración
const INITIAL_PRAYERS: PrayerRequest[] = [
  {
    id: 'pr-1',
    userId: 'user-5',
    userName: 'Mateo Ramírez',
    isAnonymous: false,
    type: 'peticion',
    title: 'Por la salud de mi abuelita Carmen',
    description: 'Les pido de corazón que nos unamos en oración por mi abuelita que está delicada en el hospital. Confiamos en la intercesión de la Virgen Milagrosa.',
    createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
    prayerCount: 14,
    prayedBy: ['user-admin-1', 'user-2', 'user-3', 'user-4'],
  },
  {
    id: 'pr-2',
    userId: 'user-anon',
    userName: 'Hermano/a en Cristo',
    isAnonymous: true,
    type: 'agradecimiento',
    title: 'Agradecimiento por una bendición laboral en mi familia',
    description: 'Doy gracias a Dios porque después de meses difíciles mi papá consiguió trabajo. La oración comunitaria tiene un poder inmenso.',
    createdAt: new Date(Date.now() - 1 * 86400000).toISOString(),
    prayerCount: 9,
    prayedBy: ['user-2', 'user-4'],
  },
];

// Recordatorios motivacionales
const INITIAL_REMINDERS: MeetingReminder[] = [
  {
    id: 'rem-1',
    title: '¡Te esperamos el sábado!',
    message: '¡Hola! Recuerda que este sábado tenemos nuestra reunión JMV a las 17:00. Tu presencia hace que nuestra familia esté completa. ¡No faltes!',
    scheduledFor: '2026-11-14T12:00:00',
    isSent: false,
    isActive: true,
  },
  {
    id: 'rem-2',
    title: 'Recuerda tu cuota de $1',
    message: 'Hola vicentino/a, recuerda traer tu cuota de $1 para las chompas y camisetas del grupo. ¡Cada aporte suma para vernos todos con los colores de María!',
    scheduledFor: '2026-11-13T10:00:00',
    isSent: false,
    isActive: true,
  },
];

// Asistencias pasadas
const INITIAL_ATTENDANCE: AttendanceSession[] = [
  {
    id: 'att-1',
    title: 'Reunión de Inicio de Mes',
    date: new Date(Date.now() - 7 * 86400000).toISOString().split('T')[0],
    records: [
      { userId: 'user-admin-1', userName: 'Andrés Morales', status: 'presente' },
      { userId: 'user-2', userName: 'Sofía Martínez', status: 'presente' },
      { userId: 'user-3', userName: 'Carlos Paredes', status: 'presente' },
      { userId: 'user-4', userName: 'Lucía Fernández', status: 'presente' },
      { userId: 'user-5', userName: 'Mateo Ramírez', status: 'justificado' },
      { userId: 'user-6', userName: 'Camila Silva', status: 'presente' },
    ],
  },
  {
    id: 'att-2',
    title: 'Taller de Liderazgo Vicenciano',
    date: new Date(Date.now() - 14 * 86400000).toISOString().split('T')[0],
    records: [
      { userId: 'user-admin-1', userName: 'Andrés Morales', status: 'presente' },
      { userId: 'user-2', userName: 'Sofía Martínez', status: 'presente' },
      { userId: 'user-3', userName: 'Carlos Paredes', status: 'presente' },
      { userId: 'user-4', userName: 'Lucía Fernández', status: 'presente' },
      { userId: 'user-5', userName: 'Mateo Ramírez', status: 'presente' },
      { userId: 'user-6', userName: 'Camila Silva', status: 'ausente' },
    ],
  },
];

// Encuestas
const INITIAL_POLLS: Poll[] = [
  {
    id: 'poll-1',
    question: '¿Qué color de detalles preferimos para la chompa oficial JMV 2026?',
    options: [
      { id: 'opt-1', text: 'Azul marino con bordado dorado', votes: ['user-admin-1', 'user-2', 'user-4'] },
      { id: 'opt-2', text: 'Blanco perla con vivos azul cielo', votes: ['user-3'] },
      { id: 'opt-3', text: 'Azul rey con capucha blanca', votes: ['user-5', 'user-6'] },
    ],
    createdBy: 'Andrés Morales',
    createdAt: new Date(Date.now() - 3 * 86400000).toISOString(),
    expiresAt: new Date(Date.now() + 5 * 86400000).toISOString(),
  },
];

// Reflexión del asesor
const INITIAL_REFLECTION: AdvisorReflection = {
  id: 'ref-1',
  advisorName: 'Padre Javier Martínez, C.M.',
  advisorTitle: 'Asesor Espiritual JMV',
  title: 'El fuego que todo lo renueva: La caridad vicenciana',
  content:
    'Queridos jóvenes: San Vicente de Paúl nos recordaba con insistencia que "el amor no es sólo un hermoso sentimiento, sino la entrega concreta de nuestras manos y nuestro tiempo". En un mundo donde todo parece rápido e individualista, cuando un joven de JMV se detiene a escuchar a un anciano, a tender la mano a quien sufre o a rezar con sinceridad por su compañero, está encendiendo una luz que nada puede apagar. Que María Santísima, Madre de la Medalla Milagrosa, guíe siempre su alegría y su entrega.',
  date: new Date(Date.now() - 2 * 86400000).toISOString().split('T')[0],
  imageUrl: marianMedalImg,
};

// Frases motivacionales para rotar diariamente de forma automática según la fecha del año
export const MOTIVATIONAL_QUOTES = [
  { text: 'A Jesús por María.', author: 'Lema oficial de JMV' },
  { text: 'La caridad es el fuego que todo lo renueva.', author: 'San Vicente de Paúl' },
  { text: 'Hagan todo lo que Él les diga.', author: 'San Juan 2, 5' },
  { text: 'Sean diligentes en servir a los pobres, con dulzura, respeto y cordialidad.', author: 'Santa Luisa de Marillac' },
  { text: 'La juventud no está hecha para el placer, sino para el heroísmo.', author: 'Paul Claudel' },
  { text: 'No temas, María, porque has hallado gracia delante de Dios.', author: 'San Lucas 1, 30' },
  { text: 'Los rayos de gracia caen sobre quienes con confianza los piden.', author: 'Santa Catalina Labouré' },
  { text: 'El amor es inventivo hasta el infinito.', author: 'San Vicente de Paúl' },
  { text: 'No basta con amar, es necesario que los pobres sientan que son amados.', author: 'San Vicente de Paúl' },
  { text: 'La caridad es el lazo perfecto de la unidad fraternal.', author: 'Colosenses 3, 14' },
  { text: 'No nos cansemos de hacer el bien, porque a su debido tiempo cosecharemos.', author: 'Gálatas 6, 9' },
  { text: 'Servir a los que sufren con amor es encontrarse con Cristo mismo.', author: 'Beata Rosalía Rendu' },
  { text: '¡Jóvenes, no tengan miedo de abrir de par en par sus corazones a Cristo!', author: 'San Juan Pablo II' },
  { text: 'La alegría del Evangelio llena el corazón y la vida entera de quienes siguen a Jesús.', author: 'Papa Francisco' },
  { text: 'Quien camina tomado de la mano de María jamás se sentirá solo en la dificultad.', author: 'Espiritualidad Vicenciana' },
  { text: 'El Señor es mi fuerza y mi escudo; en Él confía mi corazón.', author: 'Salmo 28, 7' },
  { text: 'Hagamos el bien con alegría humilde, sabiendo que Dios todo lo ve.', author: 'San Vicente de Paúl' },
  { text: 'Nadie tiene mayor amor que este: dar la vida con generosidad por sus amigos.', author: 'San Juan 15, 13' },
  { text: 'Que tu humildad sea tan sincera como tu deseo ardiente de servir.', author: 'Santa Luisa de Marillac' },
  { text: 'Todo lo puedo en Aquel que me reconforta y me da fuerza.', author: 'Filipenses 4, 13' },
  { text: 'Donde hay caridad, alegría y perdón, allí habita Dios.', author: 'Tradición Vicenciana' },
  { text: 'La sencillez es la virtud que más me agrada; es la que llamo mi evangelio.', author: 'San Vicente de Paúl' },
  { text: 'La Virgen de la Medalla Milagrosa extiende sus manos para derramar gracias sobre los jóvenes.', author: 'Tradición Mariana' },
  { text: 'Sean la luz del mundo y la sal de la tierra con su fe alegre y contagiante.', author: 'San Mateo 5, 14' },
  { text: 'Quisiera abrazar al mundo entero en una red inmensa de caridad fraterna.', author: 'Beato Federico Ozanam' },
  { text: 'La paciencia, la mansedumbre y la sonrisa abren los corazones más cerrados.', author: 'San Vicente de Paúl' },
  { text: 'Pidan con fe y se les dará; busquen y encontrarán; llamen y se les abrirá.', author: 'San Mateo 7, 7' },
  { text: 'No amemos solamente de palabra, sino con obras concretas y de verdad.', author: '1 Juan 3, 18' },
  { text: 'La Virgen María nos acompaña maternalmente en cada paso de nuestro apostolado.', author: 'San Vicente de Paúl' },
  { text: 'Si Dios está de nuestra parte, ¿quién podrá arrebatarnos la esperanza?', author: 'Romanos 8, 31' },
  { text: 'Demos gracias al Señor en todo momento, porque para siempre es su amor.', author: 'Salmo 136, 1' },
];

/**
 * Obtiene la frase asignada automáticamente para el día de hoy según la fecha
 */
export const getDailyQuote = (quotes = MOTIVATIONAL_QUOTES): { quote: { text: string; author: string }; index: number; dayString: string } => {
  const now = new Date();
  const startOfYear = new Date(now.getFullYear(), 0, 0);
  const diff = now.getTime() - startOfYear.getTime();
  const oneDay = 1000 * 60 * 60 * 24;
  const dayOfYear = Math.floor(diff / oneDay);
  const index = Math.abs(dayOfYear) % quotes.length;
  const dayString = now.toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' });
  return { quote: quotes[index], index, dayString };
};

// Motor de persistencia en LocalStorage con aislamiento por Grupo
export class StorageService {
  static get<T>(key: string, defaultValue: T): T {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : defaultValue;
    } catch {
      return defaultValue;
    }
  }

  static set<T>(key: string, value: T): boolean {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (e) {
      console.warn('LocalStorage save error:', e);
      return false;
    }
  }

  static getLegacyGroupKey(): string {
    try {
      const existing = localStorage.getItem(GLOBAL_KEYS.LEGACY_GROUP_KEY);
      if (existing) return existing;
      const rawSettings = this.get<Partial<GroupSettings> | null>(STORAGE_KEYS.GROUP_SETTINGS, null);
      const computed = rawSettings?.groupKey || normalizeGroupKey(rawSettings?.groupName || DEFAULT_SETTINGS.groupName);
      localStorage.setItem(GLOBAL_KEYS.LEGACY_GROUP_KEY, computed);
      return computed;
    } catch {
      return normalizeGroupKey(DEFAULT_SETTINGS.groupName);
    }
  }

  static getActiveGroupKey(): string {
    try {
      const saved = localStorage.getItem(GLOBAL_KEYS.ACTIVE_GROUP_KEY);
      if (saved && saved.trim()) return saved.trim();
    } catch {
      // Ignorar
    }
    return this.getLegacyGroupKey();
  }

  static setActiveGroupKey(groupKey: string): string {
    const cleanKey = normalizeGroupKey(groupKey);
    try {
      localStorage.setItem(GLOBAL_KEYS.ACTIVE_GROUP_KEY, cleanKey);
    } catch (e) {
      console.warn('LocalStorage setActiveGroupKey error:', e);
    }
    return cleanKey;
  }

  static resolveGroupKey(groupKey?: string): string {
    return groupKey ? normalizeGroupKey(groupKey) : this.getActiveGroupKey();
  }

  static isLegacyGroup(groupKey?: string): boolean {
    return this.resolveGroupKey(groupKey) === this.getLegacyGroupKey();
  }

  static scopedKey(baseKey: string, groupKey?: string): string {
    const resolved = this.resolveGroupKey(groupKey);
    const legacy = this.getLegacyGroupKey();
    return resolved === legacy ? baseKey : `${baseKey}::${resolved}`;
  }

  static getGroupsRegistry(): GroupSummary[] {
    const legacyKey = this.getLegacyGroupKey();
    const raw = this.get<GroupSummary[]>(GLOBAL_KEYS.GROUPS_REGISTRY, []);
    const list = Array.isArray(raw) ? raw.filter((g) => g && g.groupKey && g.groupName) : [];

    // Garantizar que el grupo principal/legacy siempre aparezca en el registro
    if (!list.some((g) => g.groupKey === legacyKey)) {
      const legacySettings = this.get<Partial<GroupSettings>>(STORAGE_KEYS.GROUP_SETTINGS, DEFAULT_SETTINGS);
      list.unshift({
        groupKey: legacyKey,
        groupName: legacySettings.groupName || DEFAULT_SETTINGS.groupName,
        parishName: legacySettings.parishName || DEFAULT_SETTINGS.parishName,
        logoUrl: legacySettings.logoUrl || DEFAULT_SETTINGS.logoUrl,
        updatedAt: new Date().toISOString(),
      });
      this.set(GLOBAL_KEYS.GROUPS_REGISTRY, list);
    }
    return list;
  }

  static upsertGroupRegistry(summary: GroupSummary): GroupSummary[] {
    const cleanKey = normalizeGroupKey(summary.groupKey || summary.groupName);
    const list = this.getGroupsRegistry();
    const nextItem: GroupSummary = {
      groupKey: cleanKey,
      groupName: summary.groupName.trim() || DEFAULT_SETTINGS.groupName,
      parishName: summary.parishName?.trim() || '',
      logoUrl: summary.logoUrl,
      updatedAt: summary.updatedAt || new Date().toISOString(),
    };
    const idx = list.findIndex((g) => g.groupKey === cleanKey);
    const updated = idx >= 0 ? list.map((g, i) => (i === idx ? { ...g, ...nextItem } : g)) : [...list, nextItem];
    this.set(GLOBAL_KEYS.GROUPS_REGISTRY, updated);
    return updated;
  }

  // Inicialización y recuperación de integrantes aislada por grupo
  static getUsers(groupKey?: string): UserProfile[] {
    const resolvedKey = this.resolveGroupKey(groupKey);
    const isLegacy = this.isLegacyGroup(resolvedKey);
    const key = this.scopedKey(STORAGE_KEYS.USERS, resolvedKey);
    const raw = this.get<UserProfile[] | null>(key, null);

    let list: UserProfile[];
    if (Array.isArray(raw) && raw.length > 0) {
      list = raw;
    } else if (isLegacy && raw === null) {
      list = INITIAL_USERS;
    } else if (isLegacy && Array.isArray(raw) && raw.length === 0) {
      list = INITIAL_USERS;
    } else {
      return [];
    }

    const groupSettings = this.getSettings(resolvedKey);
    const normalized: UserProfile[] = list.map((u, i) => {
      const cleanEmail = (u.email || `${u.name.toLowerCase().replace(/[\s\.]+/g, '')}@gmail.com`).trim().toLowerCase();
      const cleanCedula = (u.cedula || `172000000${i + 1}`).trim();
      const cleanPass = (u.password || cleanCedula || '123456').trim();
      return {
        ...u,
        email: cleanEmail,
        cedula: cleanCedula,
        password: cleanPass,
        groupKey: u.groupKey || resolvedKey,
        groupName: u.groupName || groupSettings.groupName,
        status: u.status || 'aprobado',
      };
    });

    // Garantizar al menos un admin en el grupo legacy para evitar bloqueo inicial
    if (isLegacy && !normalized.some((u) => u.role === 'admin')) {
      const withAdmin = [
        { ...EXAMPLE_ADMIN, groupKey: resolvedKey, groupName: groupSettings.groupName },
        ...normalized.filter((u) => u.id !== EXAMPLE_ADMIN.id),
      ];
      this.saveUsers(withAdmin, resolvedKey);
      return withAdmin;
    }

    return normalized;
  }

  static saveUsers(users: UserProfile[], groupKey?: string): boolean {
    const resolvedKey = this.resolveGroupKey(groupKey);
    const key = this.scopedKey(STORAGE_KEYS.USERS, resolvedKey);
    if (this.set(key, users)) {
      return true;
    }
    // Si el almacenamiento local está lleno por imágenes muy pesadas, compactar solo avatares mayores a 150 KB
    const compactUsers = users.map((u) => {
      if (u.avatarUrl && u.avatarUrl.startsWith('data:') && u.avatarUrl.length > 150000) {
        return {
          ...u,
          avatarUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(u.name)}`,
        };
      }
      return u;
    });
    return this.set(key, compactUsers);
  }

  static getCurrentUserId(groupKey?: string): string {
    return this.get<string>(this.scopedKey(STORAGE_KEYS.CURRENT_USER_ID, groupKey), '');
  }

  static setCurrentUserId(id: string, groupKey?: string): void {
    this.set(this.scopedKey(STORAGE_KEYS.CURRENT_USER_ID, groupKey), id);
  }

  static clearCurrentUserId(groupKey?: string): void {
    try {
      localStorage.removeItem(this.scopedKey(STORAGE_KEYS.CURRENT_USER_ID, groupKey));
    } catch (e) {
      console.warn('LocalStorage clear error:', e);
    }
  }

  static getChallenges(groupKey?: string): WeeklyChallenge[] {
    return this.get(
      this.scopedKey(STORAGE_KEYS.CHALLENGES, groupKey),
      this.isLegacyGroup(groupKey) ? INITIAL_CHALLENGES : []
    );
  }

  static saveChallenges(challenges: WeeklyChallenge[], groupKey?: string): void {
    this.set(this.scopedKey(STORAGE_KEYS.CHALLENGES, groupKey), challenges);
  }

  static getSubmissions(groupKey?: string): ChallengeSubmission[] {
    return this.get(
      this.scopedKey(STORAGE_KEYS.SUBMISSIONS, groupKey),
      this.isLegacyGroup(groupKey) ? INITIAL_SUBMISSIONS : []
    );
  }

  static saveSubmissions(submissions: ChallengeSubmission[], groupKey?: string): void {
    this.set(this.scopedKey(STORAGE_KEYS.SUBMISSIONS, groupKey), submissions);
  }

  static getFeeWeeks(groupKey?: string): FeeWeek[] {
    const defaultWeeks: FeeWeek[] = this.isLegacyGroup(groupKey)
      ? INITIAL_FEE_WEEKS
      : [
          {
            id: 'week-1',
            weekNumber: 1,
            title: 'Semana 1',
            date: new Date().toISOString().split('T')[0],
            amount: 1.0,
          },
        ];
    return this.get(this.scopedKey(STORAGE_KEYS.FEE_WEEKS, groupKey), defaultWeeks);
  }

  static saveFeeWeeks(weeks: FeeWeek[], groupKey?: string): void {
    this.set(this.scopedKey(STORAGE_KEYS.FEE_WEEKS, groupKey), weeks);
  }

  static getFeePayments(groupKey?: string): FeePayment[] {
    return this.get(
      this.scopedKey(STORAGE_KEYS.FEE_PAYMENTS, groupKey),
      this.isLegacyGroup(groupKey) ? generateInitialPayments() : []
    );
  }

  static saveFeePayments(payments: FeePayment[], groupKey?: string): void {
    this.set(this.scopedKey(STORAGE_KEYS.FEE_PAYMENTS, groupKey), payments);
  }

  static getFeeCampaigns(groupKey?: string): FeeCampaign[] {
    return this.get(
      this.scopedKey(STORAGE_KEYS.FEE_CAMPAIGNS, groupKey),
      this.isLegacyGroup(groupKey) ? INITIAL_FEE_CAMPAIGNS : []
    );
  }

  static saveFeeCampaigns(campaigns: FeeCampaign[], groupKey?: string): void {
    this.set(this.scopedKey(STORAGE_KEYS.FEE_CAMPAIGNS, groupKey), campaigns);
  }

  static getActivityExpenses(groupKey?: string): ActivityExpense[] {
    return this.get(
      this.scopedKey(STORAGE_KEYS.ACTIVITY_EXPENSES, groupKey),
      this.isLegacyGroup(groupKey) ? INITIAL_ACTIVITY_EXPENSES : []
    );
  }

  static saveActivityExpenses(expenses: ActivityExpense[], groupKey?: string): void {
    this.set(this.scopedKey(STORAGE_KEYS.ACTIVITY_EXPENSES, groupKey), expenses);
  }

  static getChatMessages(groupKey?: string): ChatMessage[] {
    return this.get(
      this.scopedKey(STORAGE_KEYS.CHAT_MESSAGES, groupKey),
      this.isLegacyGroup(groupKey) ? INITIAL_CHAT_MESSAGES : []
    );
  }

  static saveChatMessages(messages: ChatMessage[], groupKey?: string): void {
    this.set(this.scopedKey(STORAGE_KEYS.CHAT_MESSAGES, groupKey), messages);
  }

  static getActivities(groupKey?: string): ActivityEvent[] {
    return this.get(
      this.scopedKey(STORAGE_KEYS.ACTIVITIES, groupKey),
      this.isLegacyGroup(groupKey) ? INITIAL_ACTIVITIES : []
    );
  }

  static saveActivities(activities: ActivityEvent[], groupKey?: string): void {
    this.set(this.scopedKey(STORAGE_KEYS.ACTIVITIES, groupKey), activities);
  }

  static getServiceExperiences(groupKey?: string): ServiceExperience[] {
    return this.get(
      this.scopedKey(STORAGE_KEYS.SERVICE_EXPERIENCES, groupKey),
      this.isLegacyGroup(groupKey) ? INITIAL_SERVICE_EXPERIENCES : []
    );
  }

  static saveServiceExperiences(items: ServiceExperience[], groupKey?: string): void {
    this.set(this.scopedKey(STORAGE_KEYS.SERVICE_EXPERIENCES, groupKey), items);
  }

  static getPhotoAlbums(groupKey?: string): PhotoAlbum[] {
    return this.get(
      this.scopedKey(STORAGE_KEYS.PHOTO_ALBUMS, groupKey),
      this.isLegacyGroup(groupKey) ? INITIAL_ALBUMS : []
    );
  }

  static savePhotoAlbums(albums: PhotoAlbum[], groupKey?: string): void {
    this.set(this.scopedKey(STORAGE_KEYS.PHOTO_ALBUMS, groupKey), albums);
  }

  static getPhotoItems(groupKey?: string): PhotoItem[] {
    return this.get(
      this.scopedKey(STORAGE_KEYS.PHOTO_ITEMS, groupKey),
      this.isLegacyGroup(groupKey) ? INITIAL_PHOTOS : []
    );
  }

  static savePhotoItems(photos: PhotoItem[], groupKey?: string): void {
    this.set(this.scopedKey(STORAGE_KEYS.PHOTO_ITEMS, groupKey), photos);
  }

  static getSecretFriendRound(groupKey?: string): SecretFriendRound {
    const emptyRound: SecretFriendRound = {
      id: `round-${this.resolveGroupKey(groupKey)}`,
      title: 'Ronda de Amigo Secreto',
      startDate: new Date().toISOString().split('T')[0],
      revealDate: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
      status: 'active',
      assignments: [],
    };
    return this.get(
      this.scopedKey(STORAGE_KEYS.SECRET_FRIEND_ROUNDS, groupKey),
      this.isLegacyGroup(groupKey) ? INITIAL_SECRET_ROUND : emptyRound
    );
  }

  static saveSecretFriendRound(round: SecretFriendRound, groupKey?: string): void {
    this.set(this.scopedKey(STORAGE_KEYS.SECRET_FRIEND_ROUNDS, groupKey), round);
  }

  static getSecretMessages(groupKey?: string): SecretMessage[] {
    return this.get(
      this.scopedKey(STORAGE_KEYS.SECRET_MESSAGES, groupKey),
      this.isLegacyGroup(groupKey) ? INITIAL_SECRET_MESSAGES : []
    );
  }

  static saveSecretMessages(messages: SecretMessage[], groupKey?: string): void {
    this.set(this.scopedKey(STORAGE_KEYS.SECRET_MESSAGES, groupKey), messages);
  }

  static getPrayers(groupKey?: string): PrayerRequest[] {
    return this.get(
      this.scopedKey(STORAGE_KEYS.PRAYERS, groupKey),
      this.isLegacyGroup(groupKey) ? INITIAL_PRAYERS : []
    );
  }

  static savePrayers(prayers: PrayerRequest[], groupKey?: string): void {
    this.set(this.scopedKey(STORAGE_KEYS.PRAYERS, groupKey), prayers);
  }

  static getReminders(groupKey?: string): MeetingReminder[] {
    return this.get(
      this.scopedKey(STORAGE_KEYS.REMINDERS, groupKey),
      this.isLegacyGroup(groupKey) ? INITIAL_REMINDERS : []
    );
  }

  static saveReminders(reminders: MeetingReminder[], groupKey?: string): void {
    this.set(this.scopedKey(STORAGE_KEYS.REMINDERS, groupKey), reminders);
  }

  static getAttendance(groupKey?: string): AttendanceSession[] {
    return this.get(
      this.scopedKey(STORAGE_KEYS.ATTENDANCE, groupKey),
      this.isLegacyGroup(groupKey) ? INITIAL_ATTENDANCE : []
    );
  }

  static saveAttendance(sessions: AttendanceSession[], groupKey?: string): void {
    this.set(this.scopedKey(STORAGE_KEYS.ATTENDANCE, groupKey), sessions);
  }

  static getPolls(groupKey?: string): Poll[] {
    return this.get(
      this.scopedKey(STORAGE_KEYS.POLLS, groupKey),
      this.isLegacyGroup(groupKey) ? INITIAL_POLLS : []
    );
  }

  static savePolls(polls: Poll[], groupKey?: string): void {
    this.set(this.scopedKey(STORAGE_KEYS.POLLS, groupKey), polls);
  }

  static getReflection(groupKey?: string): AdvisorReflection {
    const resolvedKey = this.resolveGroupKey(groupKey);
    const defaultReflection: AdvisorReflection = this.isLegacyGroup(resolvedKey)
      ? INITIAL_REFLECTION
      : {
          id: `ref-${resolvedKey}`,
          advisorName: 'Asesor Espiritual JMV',
          advisorTitle: 'Asesor Espiritual',
          title: 'Bienvenidos a nuestra comunidad JMV',
          content: 'Que María Santísima guíe nuestro caminar, servicio y fraternidad en este nuevo espacio de grupo.',
          date: new Date().toISOString().split('T')[0],
          imageUrl: marianMedalImg,
        };
    return this.get(this.scopedKey(STORAGE_KEYS.REFLECTIONS, resolvedKey), defaultReflection);
  }

  static saveReflection(reflection: AdvisorReflection, groupKey?: string): void {
    this.set(this.scopedKey(STORAGE_KEYS.REFLECTIONS, groupKey), reflection);
  }

  static getSettings(groupKey?: string): GroupSettings {
    const resolvedKey = this.resolveGroupKey(groupKey);
    const key = this.scopedKey(STORAGE_KEYS.GROUP_SETTINGS, resolvedKey);
    const saved = this.get<Partial<GroupSettings> | null>(key, null);
    if (saved) {
      return {
        ...DEFAULT_SETTINGS,
        ...saved,
        groupKey: saved.groupKey || resolvedKey,
      };
    }

    if (this.isLegacyGroup(resolvedKey)) {
      return { ...DEFAULT_SETTINGS, groupKey: resolvedKey };
    }

    // Buscar nombre registrado del grupo si existe en el catálogo
    const reg = this.get<GroupSummary[]>(GLOBAL_KEYS.GROUPS_REGISTRY, []).find(
      (g) => g.groupKey === resolvedKey
    );
    return {
      ...DEFAULT_SETTINGS,
      groupKey: resolvedKey,
      groupName: reg?.groupName || DEFAULT_SETTINGS.groupName,
      parishName: reg?.parishName || 'Comunidad JMV',
      logoUrl: reg?.logoUrl || DEFAULT_SETTINGS.logoUrl,
      invitationCode: '',
    };
  }

  static saveSettings(settings: GroupSettings, groupKey?: string): void {
    const resolvedKey = this.resolveGroupKey(groupKey || settings.groupKey);
    const payload: GroupSettings = { ...settings, groupKey: resolvedKey };
    this.set(this.scopedKey(STORAGE_KEYS.GROUP_SETTINGS, resolvedKey), payload);
    this.upsertGroupRegistry({
      groupKey: resolvedKey,
      groupName: payload.groupName,
      parishName: payload.parishName,
      logoUrl: payload.logoUrl,
      updatedAt: new Date().toISOString(),
    });
  }

  static getPasswordRequests(groupKey?: string): PasswordRecoveryRequest[] {
    const raw = this.get<PasswordRecoveryRequest[]>(this.scopedKey(STORAGE_KEYS.PASSWORD_REQUESTS, groupKey), []);
    return Array.isArray(raw) ? raw : [];
  }

  static savePasswordRequests(requests: PasswordRecoveryRequest[], groupKey?: string): void {
    this.set(this.scopedKey(STORAGE_KEYS.PASSWORD_REQUESTS, groupKey), requests);
  }

  static initializeGroupWorkspace(params: {
    groupKey: string;
    groupName: string;
    parishName?: string;
    logoUrl?: string;
    invitationCode: string;
    coordinator: UserProfile;
  }): void {
    const key = normalizeGroupKey(params.groupKey || params.groupName);
    const groupSettings: GroupSettings = {
      ...DEFAULT_SETTINGS,
      groupKey: key,
      groupName: params.groupName.trim(),
      parishName: params.parishName?.trim() || 'Comunidad Parroquial JMV',
      logoUrl: params.logoUrl || marianMedalImg,
      invitationCode: params.invitationCode,
      advisorName: 'Asesor Espiritual JMV',
      meetingLocation: params.parishName?.trim() || 'Salón Parroquial',
      bannerImageUrl: heroYouthImg,
    };

    this.saveSettings(groupSettings, key);
    this.saveUsers([{ ...params.coordinator, groupKey: key, groupName: groupSettings.groupName }], key);
    this.saveChallenges([], key);
    this.saveSubmissions([], key);
    this.saveFeeWeeks(
      [
        {
          id: 'week-1',
          weekNumber: 1,
          title: 'Semana 1',
          date: new Date().toISOString().split('T')[0],
          amount: 1.0,
        },
      ],
      key
    );
    this.saveFeePayments([], key);
    this.saveFeeCampaigns([], key);
    this.saveActivityExpenses([], key);
    this.saveChatMessages([], key);
    this.saveActivities([], key);
    this.saveServiceExperiences([], key);
    this.savePhotoAlbums([], key);
    this.savePhotoItems([], key);
    this.saveSecretFriendRound(
      {
        id: `round-${key}`,
        title: `Amigo Secreto · ${groupSettings.groupName}`,
        startDate: new Date().toISOString().split('T')[0],
        revealDate: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
        status: 'active',
        assignments: [],
      },
      key
    );
    this.saveSecretMessages([], key);
    this.savePrayers([], key);
    this.saveReminders([], key);
    this.saveAttendance([], key);
    this.savePolls([], key);
    this.saveReflection(
      {
        id: `ref-${key}`,
        advisorName: 'Asesor Espiritual JMV',
        advisorTitle: `Asesor · ${groupSettings.groupName}`,
        title: `Bienvenidos a ${groupSettings.groupName}`,
        content:
          'Este es el espacio propio de su grupo JMV. Aquí los integrantes, aportes, actividades, fotos y datos personales se administran de manera independiente.',
        date: new Date().toISOString().split('T')[0],
        imageUrl: groupSettings.logoUrl || marianMedalImg,
      },
      key
    );
    this.savePasswordRequests([], key);
  }

  // Reiniciar a datos por defecto si el usuario lo desea
  static resetAll(): void {
    Object.values(STORAGE_KEYS).forEach((k) => localStorage.removeItem(k));
    Object.values(GLOBAL_KEYS).forEach((k) => localStorage.removeItem(k));
    window.location.reload();
  }
}
