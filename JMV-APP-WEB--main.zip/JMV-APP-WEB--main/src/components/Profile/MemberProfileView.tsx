import React, { useState, useEffect } from 'react';
import {
  User,
  ShieldCheck,
  Award,
  DollarSign,
  Calendar,
  Phone,
  Cake,
  Heart,
  Sparkles,
  Camera,
  Save,
  Check,
  CheckCircle2,
  Clock,
  AlertCircle,
  Lock,
  UserCheck,
  Sparkle,
  Upload,
  ArrowRight,
  ShieldAlert,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { compressAvatarImage } from '../../services/imageCompression';
import marianMedalImg from '../../assets/images/jmv_marian_medal_1794117311829.jpg';

export const MemberProfileView: React.FC<{
  onNavigateTab: (tab: string) => void;
  onOpenRegister: () => void;
}> = ({ onNavigateTab, onOpenRegister }) => {
  const {
    currentUser,
    updateProfile,
    isAdmin,
    isTreasurer,
    settings,
    feePayments,
    feeWeeks,
    feeCampaigns,
    attendanceSessions,
    submissions,
    challenges,
  } = useApp();

  // Estados locales para editar los datos personales
  const [nameDraft, setNameDraft] = useState(currentUser.name);
  const [birthdayDraft, setBirthdayDraft] = useState(currentUser.birthday || '2005-01-01');
  const [phoneDraft, setPhoneDraft] = useState(currentUser.phone || '');
  const [tutorNameDraft, setTutorNameDraft] = useState(currentUser.tutorName || '');
  const [tutorPhoneDraft, setTutorPhoneDraft] = useState(currentUser.tutorPhone || '');
  const [serviceAreaDraft, setServiceAreaDraft] = useState(currentUser.serviceArea || 'Misión y Visitas');
  const [spiritualQuoteDraft, setSpiritualQuoteDraft] = useState(
    currentUser.spiritualQuote || 'Con María, todo por amor y en espíritu de servicio vicenciano.'
  );
  const [avatarDraft, setAvatarDraft] = useState(currentUser.avatarUrl);
  const [isCompressingAvatar, setIsCompressingAvatar] = useState(false);
  const [avatarError, setAvatarError] = useState('');
  const [savedSuccess, setSavedSuccess] = useState(false);

  const isPendingApproval = currentUser.status === 'pendiente_aprobacion' && !isAdmin && !isTreasurer;

  useEffect(() => {
    setNameDraft(currentUser.name);
    setBirthdayDraft(currentUser.birthday || '2005-01-01');
    setPhoneDraft(currentUser.phone || '');
    setTutorNameDraft(currentUser.tutorName || '');
    setTutorPhoneDraft(currentUser.tutorPhone || '');
    setServiceAreaDraft(currentUser.serviceArea || 'Misión y Visitas');
    setSpiritualQuoteDraft(
      currentUser.spiritualQuote || 'Con María, todo por amor y en espíritu de servicio vicenciano.'
    );
    setAvatarDraft(currentUser.avatarUrl);
  }, [
    currentUser.id,
    currentUser.name,
    currentUser.avatarUrl,
    currentUser.birthday,
    currentUser.phone,
    currentUser.tutorName,
    currentUser.tutorPhone,
    currentUser.serviceArea,
    currentUser.spiritualQuote,
  ]);

  // Cálculos financieros personales
  const myWeeklyPayments = feePayments.filter(
    (p) => p.userId === currentUser.id && (p.paymentType === 'cuota_semanal' || !p.paymentType)
  );
  const myPaidWeeksCount = myWeeklyPayments.filter((p) => p.status === 'pagado').length;
  const myPendingWeeksCount = feeWeeks.length - myPaidWeeksCount;
  const myTotalWeeklyContributed = myPaidWeeksCount * 1.0;

  // Cálculos de ventas y aportes en actividades pro-fondos
  const myCampaignPayments = feePayments.filter(
    (p) => p.userId === currentUser.id && (p.paymentType === 'venta' || p.paymentType === 'inversion')
  );
  const myInvestmentPaid = myCampaignPayments.some((p) => p.paymentType === 'inversion' && p.status === 'pagado');
  const myUnitsSold = myCampaignPayments
    .filter((p) => p.paymentType === 'venta')
    .reduce((sum, p) => sum + (p.quantity || 0), 0);
  const mySalesTotal = myCampaignPayments
    .filter((p) => p.paymentType === 'venta')
    .reduce((sum, p) => sum + p.amount, 0);

  // Asistencia personal
  let myPresences = 0;
  let mySessionsCount = 0;
  attendanceSessions.forEach((session) => {
    const record = session.records.find((r) => r.userId === currentUser.id);
    if (record) {
      mySessionsCount++;
      if (record.status === 'presente' || record.status === 'justificado') {
        myPresences++;
      }
    }
  });
  const myAttendancePercentage =
    mySessionsCount > 0 ? Math.round((myPresences / mySessionsCount) * 100) : 100;

  // Retos personales cumplidos
  const myApprovedSubmissions = submissions.filter(
    (s) => s.userId === currentUser.id && s.status === 'approved'
  );

  const handleAvatarFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setAvatarError('');
    try {
      setIsCompressingAvatar(true);
      const compressedDataUrl = await compressAvatarImage(file);
      setAvatarDraft(compressedDataUrl);
      updateProfile({ avatarUrl: compressedDataUrl });
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    } catch (err) {
      console.error('Error al actualizar foto:', err);
      setAvatarError(
        'No pudimos procesar esta imagen. Intenta con una foto JPG o PNG desde tu galería.'
      );
    } finally {
      setIsCompressingAvatar(false);
      e.target.value = '';
    }
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({
      name: nameDraft.trim(),
      birthday: birthdayDraft,
      phone: phoneDraft.trim() || undefined,
      tutorName: currentUser.isMinor ? tutorNameDraft.trim() : undefined,
      tutorPhone: currentUser.isMinor ? tutorPhoneDraft.trim() : undefined,
      serviceArea: serviceAreaDraft,
      spiritualQuote: spiritualQuoteDraft.trim(),
      avatarUrl: avatarDraft,
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="space-y-6 pb-20 animate-in fade-in">
      {/* Encabezado Principal de la Ficha Individual */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-blue-900 text-amber-400">
              <User className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
              Mi Panel y Ficha Individual
            </h1>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Tu registro personal, tus datos privados y tu historial en {settings.groupName}.
          </p>
        </div>

        {isAdmin ? (
          <button
            onClick={() => onNavigateTab('admin')}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-2xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow transition active:scale-95 shrink-0"
          >
            <ShieldCheck className="w-4 h-4 text-amber-400" />
            <span>Ir al Panel General de Coordinador</span>
          </button>
        ) : (
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-semibold">
            <Lock className="w-3.5 h-3.5 text-blue-600" />
            <span>Vista Personal y Privada</span>
          </div>
        )}
      </div>

      {/* Aclaración sobre Privacidad y Datos Generales */}
      <div className="p-4 rounded-3xl bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200/80 dark:border-blue-900/50 flex items-start gap-3">
        <div className="p-2 rounded-2xl bg-blue-100 dark:bg-blue-900/60 text-blue-900 dark:text-blue-200 shrink-0 mt-0.5">
          <Lock className="w-4 h-4" />
        </div>
        <div className="text-xs space-y-1">
          <h4 className="font-bold text-blue-950 dark:text-blue-100">
            Privacidad Garantizada: Este panel es exclusivamente tuyo
          </h4>
          <p className="text-blue-900/80 dark:text-blue-200/80 leading-relaxed">
            Aquí gestionas tus datos individuales, tus cuotas personales y tu progreso. Los datos
            generales de todos los miembros, teléfonos familiares y la administración global solo son
            visibles para la Coordinación parroquial en el Panel de Administrador.
          </p>
        </div>
      </div>

      {/* Tarjeta de Identidad de Integrante */}
      <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-950 text-white shadow-xl relative overflow-hidden">
        <div className="absolute right-0 bottom-0 translate-x-8 translate-y-8 opacity-15 pointer-events-none">
          <img
            src={settings.logoUrl || marianMedalImg}
            alt={settings.groupName}
            className="w-56 h-56 object-contain"
          />
        </div>

        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 sm:gap-6 relative z-10 text-center sm:text-left">
          <div className="relative group shrink-0">
            <img
              src={avatarDraft}
              alt={currentUser.name}
              className="w-24 h-24 sm:w-28 sm:h-28 rounded-full object-cover ring-4 ring-amber-400 bg-white shadow-md"
              referrerPolicy="no-referrer"
            />
            <label
              title="Cambiar foto de perfil"
              className="absolute inset-0 rounded-full bg-black/45 opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center cursor-pointer transition text-white text-[10px] font-bold"
            >
              <Camera className="w-5 h-5 mb-1" />
              <span>{isCompressingAvatar ? 'Subiendo...' : 'Cambiar Foto'}</span>
              <input type="file" accept="image/*" onChange={handleAvatarFile} className="hidden" />
            </label>
            <label
              title="Subir nueva foto"
              className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-amber-400 hover:bg-amber-300 text-slate-950 flex items-center justify-center cursor-pointer shadow-lg ring-2 ring-blue-900 transition active:scale-95"
            >
              <Camera className="w-4 h-4" />
              <input type="file" accept="image/*" onChange={handleAvatarFile} className="hidden" />
            </label>
          </div>

          <div className="space-y-2 flex-1 min-w-0">
            <div className="flex flex-col sm:flex-row sm:items-center gap-2">
              <h2 className="text-xl sm:text-2xl font-black tracking-tight">{currentUser.name}</h2>
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-400 text-slate-950 self-center sm:self-auto shadow-sm">
                {isAdmin
                  ? '🛡️ Coordinador/a'
                  : isTreasurer
                  ? '💰 Tesorero/a'
                  : `👤 Integrante`}
              </span>
            </div>

            <div className="text-xs text-blue-200 flex items-center justify-center sm:justify-start gap-2 flex-wrap">
              <span className="w-6 h-6 rounded-lg bg-white p-0.5 inline-flex items-center justify-center shrink-0 overflow-hidden">
                <img
                  src={settings.logoUrl || marianMedalImg}
                  alt={settings.groupName}
                  className="w-full h-full object-contain rounded"
                />
              </span>
              <span className="font-bold text-white">{settings.groupName}</span>
              <span>•</span>
              <span className="text-amber-300 font-semibold">{settings.parishName}</span>
            </div>

            <blockquote className="text-xs italic text-blue-100 bg-white/10 p-2.5 rounded-2xl max-w-xl">
              "{spiritualQuoteDraft}"
            </blockquote>

            <div className="flex items-center justify-center sm:justify-start gap-3 pt-1 text-xs font-semibold text-blue-200 flex-wrap">
              <span className="flex items-center gap-1">
                <Sparkle className="w-3.5 h-3.5 text-amber-300 fill-current" />
                {currentUser.points} Puntos Vicencianos
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Cake className="w-3.5 h-3.5 text-rose-300" />
                Cumpleaños: {currentUser.birthday || 'No registrado'}
              </span>
            </div>

            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2.5 pt-2">
              <label className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-extrabold text-xs cursor-pointer shadow-md transition active:scale-95">
                <Camera className="w-3.5 h-3.5" />
                <span>{isCompressingAvatar ? 'Procesando foto...' : 'Cambiar mi Foto'}</span>
                <input type="file" accept="image/*" onChange={handleAvatarFile} className="hidden" />
              </label>
              {savedSuccess && (
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-emerald-500/25 border border-emerald-300/40 text-emerald-100 text-[11px] font-bold">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" />
                  Foto y ficha actualizadas en toda la app
                </span>
              )}
              {avatarError && (
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-rose-500/30 border border-rose-300/40 text-rose-100 text-[11px] font-bold">
                  <AlertCircle className="w-3.5 h-3.5 text-rose-200" />
                  {avatarError}
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Grid de 2 Columnas: Mis Finanzas Personales vs Mi Compromiso y Asistencia */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Columna A: Mi Estado Financiero Personal */}
        <div className="p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-emerald-600" /> Mi Resumen Financiero Personal
            </h3>
            <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
              {isPendingApproval ? 'Pendiente de aprobación' : 'Solo tus registros'}
            </span>
          </div>

          {isPendingApproval ? (
            <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/50 text-xs text-amber-900 dark:text-amber-200 space-y-1.5">
              <div className="flex items-center gap-2 font-bold">
                <Clock className="w-4 h-4 text-amber-600 shrink-0" />
                <span>Cuenta pendiente de aprobación del Administrador</span>
              </div>
              <p className="text-[11px] leading-relaxed opacity-90">
                Tu registro fue recibido. Una vez que el Coordinador/a apruebe tu ingreso desde el Panel de Administración, podrás consultar aquí tu historial privado de aportes de $1 y actividades.
              </p>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 gap-3 text-center">
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">
                    Cuotas $1 Aportadas
                  </span>
                  <span className="text-xl font-black text-emerald-600 dark:text-emerald-400">
                    ${myTotalWeeklyContributed}.00
                  </span>
                  <span className="text-[10px] text-slate-500 block mt-0.5">
                    {myPaidWeeksCount} de {feeWeeks.length} semanas
                  </span>
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">
                    Cuotas Pendientes
                  </span>
                  <span className="text-xl font-black text-amber-600 dark:text-amber-400">
                    {myPendingWeeksCount > 0 ? `${myPendingWeeksCount} sem.` : 'Al día ✓'}
                  </span>
                  <span className="text-[10px] text-slate-500 block mt-0.5">
                    {myPendingWeeksCount > 0 ? `$${myPendingWeeksCount}.00 por cancelar` : '¡Sin deuda!'}
                  </span>
                </div>
              </div>

              {/* Actividades de Ventas (ej. Empanadas) */}
              <div className="p-3.5 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200/60 dark:border-emerald-900/40 space-y-1.5 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-emerald-950 dark:text-emerald-200">
                    Ventas Pro-Fondos (Empanadas / Actividades)
                  </span>
                  <span className="font-bold text-emerald-700 dark:text-emerald-300">
                    {myUnitsSold} vendidas (${mySalesTotal}.00)
                  </span>
                </div>
                <p className="text-[11px] text-emerald-800/80 dark:text-emerald-300/80">
                  Inversión inicial personal: {myInvestmentPaid ? '✓ Pagada ($2.00)' : '⏳ Pendiente'}
                </p>
              </div>

              <button
                onClick={() => onNavigateTab('cuotas')}
                className="w-full py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold text-xs flex items-center justify-center gap-1.5 transition"
              >
                <span>Ver detalle completo de cuotas</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </>
          )}
        </div>

        {/* Columna B: Mi Participación y Fidelidad Comunitaria */}
        <div className="p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-500" /> Mi Vida Comunitaria y Méritos
            </h3>
            <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300">
              Puntos e Insignias
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3 text-center">
            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">
                Asistencia a Reuniones
              </span>
              <span className="text-xl font-black text-blue-900 dark:text-blue-400">
                {myAttendancePercentage}%
              </span>
              <span className="text-[10px] text-slate-500 block mt-0.5">
                {myPresences} de {mySessionsCount || attendanceSessions.length} reuniones
              </span>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">
                Retos Cumplidos
              </span>
              <span className="text-xl font-black text-amber-600 dark:text-amber-400">
                {myApprovedSubmissions.length}
              </span>
              <span className="text-[10px] text-slate-500 block mt-0.5">
                retos aprobados por asesor
              </span>
            </div>
          </div>

          {/* Insignias Obtenidas */}
          <div className="space-y-1.5">
            <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block">
              Mis Insignias Marianas Obtenidas:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {currentUser.badges.map((badge, idx) => (
                <span
                  key={idx}
                  className="px-2.5 py-1 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/50 text-amber-900 dark:text-amber-300 text-xs font-bold capitalize flex items-center gap-1"
                >
                  🏅 {badge}
                </span>
              ))}
            </div>
          </div>

          <button
            onClick={() => onNavigateTab('retos')}
            className="w-full py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold text-xs flex items-center justify-center gap-1.5 transition"
          >
            <span>Ver reto semanal activo</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Formulario de Edición de Ficha Individual */}
      <div className="p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <User className="w-4 h-4 text-blue-600" /> Editar Mi Ficha y Datos Personales
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Mantén tus datos actualizados para contacto interno y felicitaciones.
            </p>
          </div>
          <span className="text-[10px] text-slate-400 italic">Autogestionable</span>
        </div>

        <form onSubmit={handleSaveProfile} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                Mi Nombre y Apellidos *
              </label>
              <input
                type="text"
                required
                value={nameDraft}
                onChange={(e) => setNameDraft(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-bold"
              />
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                Mi Fecha de Cumpleaños *
              </label>
              <input
                type="date"
                required
                value={birthdayDraft}
                onChange={(e) => setBirthdayDraft(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-semibold"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                Mi Teléfono / WhatsApp Personal
              </label>
              <input
                type="tel"
                value={phoneDraft}
                onChange={(e) => setPhoneDraft(e.target.value)}
                placeholder="+593 99..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-semibold"
              />
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                Área de Servicio o Apostolado Preferido en JMV
              </label>
              <select
                value={serviceAreaDraft}
                onChange={(e) => setServiceAreaDraft(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-semibold"
              >
                <option value="Misión y Visitas">🕊️ Misión y Visitas a Comunidades</option>
                <option value="Coro y Animación">🎵 Coro y Animación Musical</option>
                <option value="Liturgia y Oración">✝️ Liturgia y Oración Comunitaria</option>
                <option value="Caridad y Comedor">🍲 Caridad y Comedor Vicenciano</option>
                <option value="Deportes y Convivencia">⚽ Deportes y Dinámicas Juveniles</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
              Mi Frase o Lema Vicenciano Inspirador
            </label>
            <input
              type="text"
              value={spiritualQuoteDraft}
              onChange={(e) => setSpiritualQuoteDraft(e.target.value)}
              placeholder="Ej: A Jesús por María • Servir con alegría"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-semibold"
            />
          </div>

          {/* Datos de apoderado / tutor si es menor de edad */}
          {currentUser.isMinor && (
            <div className="p-4 rounded-2xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/50 space-y-3">
              <span className="font-bold text-amber-950 dark:text-amber-200 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-amber-600" />
                Contacto de Tutor / Apoderado (Menor de Edad)
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-600 dark:text-slate-400 mb-0.5">
                    Nombre del Padre / Madre / Tutor
                  </label>
                  <input
                    type="text"
                    value={tutorNameDraft}
                    onChange={(e) => setTutorNameDraft(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-600 dark:text-slate-400 mb-0.5">
                    Teléfono de Emergencia del Tutor
                  </label>
                  <input
                    type="tel"
                    value={tutorPhoneDraft}
                    onChange={(e) => setTutorPhoneDraft(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
              </div>
            </div>
          )}

          <button
            type="submit"
            className="w-full py-3 rounded-2xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow flex items-center justify-center gap-2 transition active:scale-98"
          >
            <Save className="w-4 h-4" />
            <span>{savedSuccess ? '¡Cambios guardados en tu ficha!' : 'Guardar Mis Datos Personales'}</span>
          </button>
        </form>
      </div>
    </div>
  );
};
