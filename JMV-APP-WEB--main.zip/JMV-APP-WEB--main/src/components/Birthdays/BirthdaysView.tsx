import React, { useState } from 'react';
import {
  Cake,
  Sparkles,
  Heart,
  Copy,
  Check,
  MessageCircle,
  Calendar,
  Share2,
  Printer,
  ChevronRight,
  Gift,
  Send,
  X,
  Smile,
  Flame,
  Award,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { UserProfile } from '../../types';
import marianMedalImg from '../../assets/images/jmv_marian_medal_1794117311829.jpg';

const MONTH_NAMES = [
  'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
  'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
];

interface CardTemplate {
  id: string;
  title: string;
  subtitle: string;
  bgGradient: string;
  borderColor: string;
  textColor: string;
  getText: (name: string, groupName: string) => string;
}

const CARD_TEMPLATES: CardTemplate[] = [
  {
    id: 'mariano',
    title: 'Manto de María',
    subtitle: 'Espiritualidad y Medalla Milagrosa',
    bgGradient: 'from-blue-900 via-indigo-900 to-blue-950',
    borderColor: 'border-amber-400/60',
    textColor: 'text-amber-300',
    getText: (name, group) =>
      `🎂✨ ¡Feliz y bendecido cumpleaños, ${name}! La comunidad de ${group} da infinitas gracias a Dios por el don de tu vida. Que la Santísima Virgen de la Medalla Milagrosa extienda sus manos sobre ti, colmándote de gracia, salud, paz y fidelidad a Cristo. ¡A Jesús por María! 🎉🕊️`,
  },
  {
    id: 'vicenciano',
    title: 'Caridad Vicenciana',
    subtitle: 'San Vicente de Paúl y el Servicio',
    bgGradient: 'from-emerald-950 via-teal-900 to-blue-950',
    borderColor: 'border-emerald-400/60',
    textColor: 'text-emerald-300',
    getText: (name, group) =>
      `🌿💫 ¡Feliz Cumpleaños, ${name}! Tu presencia en ${group} es un verdadero regalo. Que San Vicente de Paúl y Santa Luisa de Marillac inspiren cada uno de tus pasos para seguir sirviendo con alegría, humildad y un corazón generoso hacia los más necesitados. ¡Celebramos tu vida! 🎂❤️`,
  },
  {
    id: 'juvenil',
    title: 'Alegría Juvenil',
    subtitle: 'Fiesta y Amistad Fraterna',
    bgGradient: 'from-purple-950 via-pink-900 to-indigo-950',
    borderColor: 'border-pink-400/60',
    textColor: 'text-pink-300',
    getText: (name, group) =>
      `🎉🎈 ¡Felicidades en tu día especial, ${name}! Gracias por contagiar a ${group} con tu alegría, tus risas y tu constancia. Que este nuevo año de vida esté repleto de metas cumplidas, amigos leales y la bendición de Dios en tus proyectos. ¡Te queremos mucho! 🥳✨`,
  },
  {
    id: 'salmo',
    title: 'Salmo de Gratitud',
    subtitle: 'Oración y Esperanza',
    bgGradient: 'from-amber-950 via-slate-900 to-blue-950',
    borderColor: 'border-amber-500/60',
    textColor: 'text-amber-400',
    getText: (name, group) =>
      `📖🕯️ "El Señor te bendiga y te proteja; haga resplandecer su rostro sobre ti y te conceda la paz" (Números 6:24-26). Feliz Cumpleaños, querido/a ${name}. Desde ${group} elevamos una plegaria por tu bienestar y tu vocación. ¡Un abrazo fraterno gigante! 🎂🌟`,
  },
];

export const BirthdaysView: React.FC<{ onNavigateToChat: () => void }> = ({ onNavigateToChat }) => {
  const { users, sendMessage, settings, currentUser } = useApp();

  const today = new Date();
  const [selectedMonth, setSelectedMonth] = useState<number>(today.getMonth());
  const [activeTab, setActiveTab] = useState<'proximos' | 'meses'>('proximos');
  const [selectedUserForCard, setSelectedUserForCard] = useState<UserProfile | null>(() => {
    // Inicializar con el cumpleañero más cercano o el primero con cumpleaños
    return users.find((u) => Boolean(u.birthday)) || users[0] || null;
  });
  const [activeTemplateId, setActiveTemplateId] = useState<string>('mariano');
  const [customGreetingMessage, setCustomGreetingMessage] = useState<string>('');
  const [copiedMessage, setCopiedMessage] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);

  // Agrupar usuarios por mes
  const usersByMonth: Record<number, UserProfile[]> = {};
  for (let m = 0; m < 12; m++) usersByMonth[m] = [];

  users.forEach((u) => {
    if (u.birthday) {
      const bMonth = new Date(u.birthday).getMonth();
      usersByMonth[bMonth].push(u);
    }
  });

  // Ordenar los del mes seleccionado por día
  const currentMonthBirthdays = [...usersByMonth[selectedMonth]].sort((a, b) => {
    return new Date(a.birthday).getDate() - new Date(b.birthday).getDate();
  });

  // Calcular los próximos cumpleaños con días restantes
  const upcomingList = users
    .filter((u) => Boolean(u.birthday))
    .map((u) => {
      const bDate = new Date(u.birthday);
      const bMonth = bDate.getMonth();
      const bDay = bDate.getDate();

      // Próximo cumpleaños en este año o siguiente
      const nextBday = new Date(today.getFullYear(), bMonth, bDay);
      if (nextBday.getTime() < today.setHours(0, 0, 0, 0)) {
        nextBday.setFullYear(today.getFullYear() + 1);
      }

      const diffMs = nextBday.getTime() - today.getTime();
      const daysRemaining = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

      return {
        user: u,
        day: bDay,
        month: bMonth,
        daysRemaining,
        isToday: daysRemaining === 0,
      };
    })
    .sort((a, b) => a.daysRemaining - b.daysRemaining);

  const activeTemplate =
    CARD_TEMPLATES.find((t) => t.id === activeTemplateId) || CARD_TEMPLATES[0];

  const currentGreeting =
    customGreetingMessage.trim() ||
    (selectedUserForCard
      ? activeTemplate.getText(selectedUserForCard.name.split(' ')[0], settings.groupName)
      : '');

  const triggerCelebrationConfetti = () => {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#3b82f6', '#f59e0b', '#ec4899', '#ffffff'],
    });
  };

  const handleOpenCardGenerator = (user: UserProfile) => {
    setSelectedUserForCard(user);
    setCustomGreetingMessage('');
    setShowShareModal(true);
    triggerCelebrationConfetti();
  };

  const handleSendGreetingToChat = () => {
    if (!selectedUserForCard) return;
    sendMessage(currentGreeting);
    triggerCelebrationConfetti();
    alert(`¡Se publicó la tarjeta de felicitación para ${selectedUserForCard.name} en el chat grupal!`);
    setShowShareModal(false);
    onNavigateToChat();
  };

  const handleCopyGreeting = () => {
    navigator.clipboard.writeText(currentGreeting);
    setCopiedMessage(true);
    setTimeout(() => setCopiedMessage(false), 2000);
  };

  const handleShareWhatsApp = () => {
    if (!selectedUserForCard) return;
    const phone = selectedUserForCard.phone ? selectedUserForCard.phone.replace(/[^0-9]/g, '') : '';
    const encoded = encodeURIComponent(currentGreeting);
    const url = phone ? `https://wa.me/${phone}?text=${encoded}` : `https://api.whatsapp.com/send?text=${encoded}`;
    window.open(url, '_blank');
  };

  const handlePrintCard = () => {
    window.print();
  };

  return (
    <div className="space-y-6 pb-20 animate-in fade-in">
      {/* Encabezado */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-pink-500/10 text-pink-600 dark:text-pink-400">
              <Cake className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
              Cumpleaños y Generador de Tarjetas
            </h1>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Celebrando la vida y vocación mariana de cada integrante de {settings.groupName}.
          </p>
        </div>

        {selectedUserForCard && (
          <button
            onClick={() => {
              setCustomGreetingMessage('');
              setShowShareModal(true);
              triggerCelebrationConfetti();
            }}
            className="flex items-center gap-2 px-4 py-2 rounded-2xl bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white font-bold text-xs shadow-md transition active:scale-95 shrink-0"
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>Crear Tarjeta de Felicitación</span>
          </button>
        )}
      </div>

      {/* Banner Informativo y Destacado del Módulo */}
      <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-br from-pink-500/10 via-purple-500/5 to-blue-500/10 border border-pink-500/20 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-2xl bg-pink-500/20 text-pink-600 dark:text-pink-400 flex items-center justify-center shrink-0">
            <Gift className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-pink-700 dark:text-pink-400">
              Generación Automática de Tarjetas Marianas
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5 leading-relaxed">
              El sistema detecta automáticamente la fecha de nacimiento de cada hermano, calcula los días faltantes y prepara una tarjeta artística personalizada con la Medalla Milagrosa, lista para publicar en el chat o enviar por WhatsApp.
            </p>
          </div>
        </div>

        {/* Pestañas de Navegación */}
        <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shrink-0">
          <button
            onClick={() => setActiveTab('proximos')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
              activeTab === 'proximos'
                ? 'bg-blue-900 text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            🎉 Próximos
          </button>
          <button
            onClick={() => setActiveTab('meses')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
              activeTab === 'meses'
                ? 'bg-blue-900 text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            📅 Por Meses
          </button>
        </div>
      </div>

      {/* VISTA 1: PRÓXIMOS CUMPLEAÑOS (ORDEN CRONOLÓGICO) */}
      {activeTab === 'proximos' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400 px-1">
              Próximos aniversarios de vida en la comunidad
            </h2>
            <span className="text-[11px] text-slate-500 font-medium">
              {upcomingList.length} integrantes registrados
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {upcomingList.map(({ user, day, month, daysRemaining, isToday }) => {
              return (
                <div
                  key={user.id}
                  className={`p-4 rounded-3xl border transition-all shadow-sm flex flex-col justify-between ${
                    isToday
                      ? 'bg-gradient-to-br from-amber-500/15 via-pink-500/10 to-blue-500/15 border-amber-400 dark:border-amber-500/50 ring-2 ring-amber-400/30'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-pink-300 dark:hover:border-pink-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <img
                          src={user.avatarUrl}
                          alt={user.name}
                          className="w-12 h-12 rounded-full object-cover ring-2 ring-pink-300 dark:ring-pink-700 shadow-sm"
                          referrerPolicy="no-referrer"
                        />
                        {isToday && (
                          <span className="absolute -top-1 -right-1 text-sm animate-bounce">
                            👑
                          </span>
                        )}
                      </div>

                      <div>
                        <h3 className="text-sm font-bold text-slate-900 dark:text-white leading-tight">
                          {user.name}
                        </h3>
                        <p className="text-xs text-slate-500 dark:text-slate-400">
                          {day} de {MONTH_NAMES[month]}
                        </p>
                        <span className="inline-block mt-0.5 text-[10px] font-semibold text-slate-400">
                          {user.role === 'admin' ? '🛡️ Coordinación' : '👤 Integrante'}
                        </span>
                      </div>
                    </div>

                    {/* Badge de cuenta regresiva */}
                    <div className="text-right shrink-0">
                      {isToday ? (
                        <span className="px-2.5 py-1 rounded-xl bg-amber-400 text-slate-950 font-black text-[11px] shadow animate-pulse">
                          ¡Hoy! 🎉
                        </span>
                      ) : daysRemaining <= 7 ? (
                        <span className="px-2 py-0.5 rounded-lg bg-pink-100 dark:bg-pink-950 text-pink-700 dark:text-pink-300 font-bold text-[10px]">
                          En {daysRemaining} días
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 text-[10px] font-medium">
                          En {daysRemaining} días
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Acciones de la tarjeta */}
                  <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between gap-2">
                    <span className="text-[11px] text-slate-400 truncate max-w-[120px]">
                      {user.phone ? `📱 ${user.phone}` : 'JMV'}
                    </span>

                    <button
                      onClick={() => handleOpenCardGenerator(user)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-pink-50 dark:bg-pink-950/60 hover:bg-pink-100 dark:hover:bg-pink-900/60 text-pink-700 dark:text-pink-300 border border-pink-200 dark:border-pink-800/60 text-xs font-bold transition active:scale-95"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Generar Tarjeta</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* VISTA 2: EXPLORADOR POR MESES */}
      {activeTab === 'meses' && (
        <div className="space-y-4">
          {/* Selector Horizontal de Meses */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {MONTH_NAMES.map((name, idx) => {
              const count = usersByMonth[idx]?.length || 0;
              const isSelected = selectedMonth === idx;

              return (
                <button
                  key={name}
                  onClick={() => setSelectedMonth(idx)}
                  className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-bold whitespace-nowrap transition active:scale-95 ${
                    isSelected
                      ? 'bg-blue-900 text-white shadow-md'
                      : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50'
                  }`}
                >
                  <span>{name}</span>
                  {count > 0 && (
                    <span
                      className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                        isSelected
                          ? 'bg-amber-400 text-slate-950 font-black'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                      }`}
                    >
                      {count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Lista de Cumpleañeros del Mes Seleccionado */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {currentMonthBirthdays.length > 0 ? (
              currentMonthBirthdays.map((user) => {
                const bDay = new Date(user.birthday).getDate();

                return (
                  <div
                    key={user.id}
                    className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-2xl bg-pink-50 dark:bg-pink-950/40 border border-pink-200 dark:border-pink-900/40 flex flex-col items-center justify-center text-pink-700 dark:text-pink-300 shrink-0 font-bold">
                          <span className="text-[10px] uppercase font-semibold leading-tight">Día</span>
                          <span className="text-base font-extrabold tabular-nums leading-none">{bDay}</span>
                        </div>

                        <div>
                          <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                            {user.name}
                          </h3>
                          <p className="text-xs text-slate-400">
                            {user.role === 'admin' ? '🛡️ Coordinador' : 'Integrante'} · {bDay} de {MONTH_NAMES[selectedMonth]}
                          </p>
                          {user.phone && (
                            <p className="text-[11px] text-slate-500 mt-0.5">
                              WhatsApp: {user.phone}
                            </p>
                          )}
                        </div>
                      </div>

                      <img
                        src={user.avatarUrl}
                        alt={user.name}
                        className="w-10 h-10 rounded-full object-cover ring-2 ring-pink-300"
                        referrerPolicy="no-referrer"
                      />
                    </div>

                    {/* Previa de texto de felicitación automática */}
                    <div className="mt-4 p-3 rounded-2xl bg-amber-50/60 dark:bg-slate-800/60 border border-amber-200/50 dark:border-slate-700 text-xs text-slate-700 dark:text-slate-300 leading-relaxed italic">
                      "{CARD_TEMPLATES[0].getText(user.name.split(' ')[0], settings.groupName)}"
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2">
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(
                            CARD_TEMPLATES[0].getText(user.name.split(' ')[0], settings.groupName)
                          );
                          setCopiedMessage(true);
                          setTimeout(() => setCopiedMessage(false), 2000);
                        }}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 text-xs font-semibold"
                      >
                        {copiedMessage ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>Copiar</span>
                      </button>

                      <button
                        onClick={() => handleOpenCardGenerator(user)}
                        className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-pink-600 hover:bg-pink-700 text-white font-bold text-xs shadow-md transition active:scale-95"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Ver Tarjeta Artística</span>
                      </button>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="md:col-span-2 p-12 text-center rounded-3xl bg-white dark:bg-slate-900 border border-dashed border-slate-200 dark:border-slate-800 text-slate-400">
                <Cake className="w-10 h-10 mx-auto mb-2 opacity-50 text-pink-400" />
                <p className="text-sm font-bold text-slate-700 dark:text-slate-300">
                  No hay cumpleaños registrados en {MONTH_NAMES[selectedMonth]}.
                </p>
                <p className="text-xs mt-1">Selecciona otro mes o revisa la pestaña de Próximos.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* MODAL / VISOR INTERACTIVO DE LA TARJETA AUTOMÁTICA */}
      {showShareModal && selectedUserForCard && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-lg w-full overflow-hidden flex flex-col max-h-[92vh]">
            {/* Cabecera del Modal */}
            <div className="px-5 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-xl bg-pink-500/10 text-pink-600">
                  <Sparkles className="w-4 h-4" />
                </span>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Tarjeta Automática de Cumpleaños
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Para {selectedUserForCard.name} ({settings.groupName})
                  </p>
                </div>
              </div>

              <button
                onClick={() => setShowShareModal(false)}
                className="p-1 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Cuerpo con Scroll */}
            <div className="p-5 overflow-y-auto space-y-4">
              {/* Selector de Destinatario Rápido */}
              <div>
                <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                  Cumpleañero / Hermano a Celebrar:
                </label>
                <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
                  {users.map((u) => {
                    const isSelected = u.id === selectedUserForCard.id;
                    return (
                      <button
                        key={u.id}
                        onClick={() => {
                          setSelectedUserForCard(u);
                          setCustomGreetingMessage('');
                        }}
                        className={`flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-semibold whitespace-nowrap border transition ${
                          isSelected
                            ? 'bg-pink-600 text-white border-pink-600 shadow-sm'
                            : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        <img
                          src={u.avatarUrl}
                          alt={u.name}
                          className="w-4 h-4 rounded-full object-cover"
                        />
                        <span>{u.name.split(' ')[0]}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Selector de Estilo / Temas Espirituales */}
              <div>
                <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                  Estilo de Bendición:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {CARD_TEMPLATES.map((tmpl) => {
                    const isSelected = activeTemplateId === tmpl.id;
                    return (
                      <button
                        key={tmpl.id}
                        type="button"
                        onClick={() => {
                          setActiveTemplateId(tmpl.id);
                          setCustomGreetingMessage('');
                        }}
                        className={`p-2.5 rounded-2xl text-left border transition ${
                          isSelected
                            ? 'border-blue-600 bg-blue-50/70 dark:bg-blue-950/40 ring-1 ring-blue-600'
                            : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/40 hover:bg-slate-50'
                        }`}
                      >
                        <div className="font-bold text-xs text-slate-900 dark:text-white">
                          {tmpl.title}
                        </div>
                        <div className="text-[10px] text-slate-400 truncate">
                          {tmpl.subtitle}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* PREVIEW VISUAL DE LA TARJETA MARIANA DECORADA */}
              <div
                id="birthday-card-printable"
                className={`relative rounded-3xl p-6 bg-gradient-to-br ${activeTemplate.bgGradient} text-white shadow-xl border-2 ${activeTemplate.borderColor} overflow-hidden`}
              >
                {/* Elementos decorativos de fondo */}
                <div className="absolute -right-6 -bottom-6 w-32 h-32 rounded-full bg-white/5 blur-2xl pointer-events-none" />
                <div className="absolute top-3 right-4 flex items-center gap-1.5">
                  <span className="text-[10px] font-extrabold uppercase tracking-wider text-amber-200 max-w-[120px] truncate">
                    {settings.groupName}
                  </span>
                  <div className="w-7 h-7 rounded-xl bg-white p-0.5 ring-1 ring-amber-400 shadow-sm flex items-center justify-center overflow-hidden">
                    <img
                      src={settings.logoUrl || marianMedalImg}
                      alt={settings.groupName}
                      className="w-full h-full object-contain rounded-lg"
                    />
                  </div>
                </div>

                {/* Encabezado de la tarjeta */}
                <div className="flex items-center gap-3.5 mb-4">
                  <div className="relative">
                    <img
                      src={selectedUserForCard.avatarUrl}
                      alt={selectedUserForCard.name}
                      className="w-14 h-14 rounded-2xl object-cover ring-2 ring-amber-400/80 shadow-md"
                    />
                    <span className="absolute -bottom-1 -right-1 text-sm bg-amber-400 text-slate-950 rounded-full w-5 h-5 flex items-center justify-center font-bold shadow">
                      🎂
                    </span>
                  </div>

                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-amber-300 block">
                      ¡Feliz Cumpleaños!
                    </span>
                    <h4 className="text-lg font-black tracking-tight text-white leading-tight">
                      {selectedUserForCard.name}
                    </h4>
                    <span className="text-[11px] text-blue-200 block">
                      {settings.groupName}{settings.parishName ? ` · ${settings.parishName}` : ''}
                    </span>
                  </div>
                </div>

                {/* Texto de la felicitación */}
                <p className="text-xs sm:text-sm text-blue-100 leading-relaxed italic bg-white/10 p-3.5 rounded-2xl border border-white/10 backdrop-blur-sm">
                  "{currentGreeting}"
                </p>

                {/* Pie de la tarjeta */}
                <div className="mt-4 pt-3 border-t border-white/15 flex items-center justify-between text-[10px] text-blue-200/80">
                  <span>"A Jesús por María"</span>
                  <span>{new Date().toLocaleDateString('es-ES', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
                </div>
              </div>

              {/* Editor de mensaje opcional */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Personalizar mensaje o agregar palabras tuyas:
                </label>
                <textarea
                  rows={2}
                  value={customGreetingMessage}
                  onChange={(e) => setCustomGreetingMessage(e.target.value)}
                  placeholder="Puedes escribir una dedicatoria personal aquí si lo deseas..."
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white resize-none"
                />
              </div>
            </div>

            {/* Botones de Acción del Modal */}
            <div className="px-5 py-3.5 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={handleCopyGreeting}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-700 text-xs font-semibold"
                  title="Copiar texto al portapapeles"
                >
                  {copiedMessage ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedMessage ? 'Copiado' : 'Copiar'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleShareWhatsApp}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-sm transition active:scale-95"
                  title="Enviar felicitación por WhatsApp"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>WhatsApp</span>
                </button>

                <button
                  type="button"
                  onClick={handlePrintCard}
                  className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-700 text-xs"
                  title="Imprimir o guardar como PDF"
                >
                  <Printer className="w-4 h-4" />
                </button>
              </div>

              <button
                type="button"
                onClick={handleSendGreetingToChat}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow-md transition active:scale-95 ml-auto"
              >
                <MessageCircle className="w-4 h-4 text-amber-300" />
                <span>Publicar en el Chat de JMV</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
