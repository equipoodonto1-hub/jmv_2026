-- ========================================================================
-- SCRIPT SQL COMPLETO E IDEMPOTENTE DE SUPABASE PARA JMV CON SEGURIDAD RLS
-- (Juventud Mariana Vicenciana — Row Level Security + Aislamiento por Grupo)
-- ========================================================================
-- Este script es seguro para ejecutar tanto en un proyecto NUEVO como en una
-- base de datos EXISTENTE (agrega columnas, cifrado y políticas RLS sin borrar datos).
--
-- SEGURIDAD INCLUIDA (RLS REAL):
-- 1. Cero políticas abiertas (NO usa USING(true) en datos de usuarios/grupos).
-- 2. Contraseñas cifradas con bcrypt (pgcrypto) en esquema privado (private).
-- 3. Códigos privados de invitación protegidos en esquema privado (private).
-- 4. Sesiones con token aleatorio SHA-256 validado en cada consulta RLS.
-- 5. Aislamiento estricto por group_key en TODAS las 21 tablas.
-- 6. Control por roles (admin, tesorero, integrante) y bloqueo de auto-escalado.
--
-- INSTRUCCIONES:
-- 1. Ve a tu panel de Supabase (https://supabase.com/dashboard)
-- 2. Entra en tu proyecto -> SQL Editor -> '+ New query'
-- 3. Pega todo este script y presiona RUN (Ejecutar)
-- ========================================================================

-- 1. Extensiones requeridas
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 2. Esquema privado inaccesible vía API REST pública (PostgREST)
CREATE SCHEMA IF NOT EXISTS private;
GRANT USAGE ON SCHEMA private TO anon, authenticated;
REVOKE ALL ON ALL TABLES IN SCHEMA private FROM PUBLIC, anon, authenticated;
ALTER DEFAULT PRIVILEGES IN SCHEMA private REVOKE ALL ON TABLES FROM PUBLIC, anon, authenticated;

-- 3. CONFIGURACIÓN GENERAL DEL GRUPO, PARROQUIA Y LOGO (jmv_group_settings)
CREATE TABLE IF NOT EXISTS public.jmv_group_settings (
  id TEXT PRIMARY KEY DEFAULT 'default',
  group_key TEXT NOT NULL DEFAULT 'default',
  group_name TEXT NOT NULL DEFAULT 'JMV',
  parish_name TEXT DEFAULT 'Parroquia Nuestra Señora de la Esperanza',
  logo_url TEXT,
  invitation_code TEXT NOT NULL DEFAULT '***',
  hoodie_goal_amount NUMERIC(10,2) NOT NULL DEFAULT 300.00,
  hoodie_cost_per_person NUMERIC(8,2) NOT NULL DEFAULT 25.00,
  advisor_name TEXT,
  next_meeting_date TIMESTAMPTZ,
  meeting_location TEXT,
  banner_palette TEXT DEFAULT 'azul-mariano',
  banner_image_url TEXT,
  banner_image_opacity INTEGER DEFAULT 30,
  emailjs_service_id TEXT,
  emailjs_template_id TEXT,
  emailjs_public_key TEXT,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.jmv_group_settings ADD COLUMN IF NOT EXISTS group_key TEXT NOT NULL DEFAULT 'default';
CREATE INDEX IF NOT EXISTS idx_jmv_group_settings_group_key ON public.jmv_group_settings (group_key);

-- 4. PERFILES DE INTEGRANTES (jmv_profiles)
CREATE TABLE IF NOT EXISTS public.jmv_profiles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  group_key TEXT NOT NULL DEFAULT 'default',
  group_name TEXT,
  name TEXT NOT NULL,
  email TEXT,
  cedula TEXT,
  password TEXT,
  status TEXT NOT NULL DEFAULT 'aprobado' CHECK (status IN ('aprobado', 'pendiente_aprobacion')),
  role TEXT NOT NULL DEFAULT 'integrante' CHECK (role IN ('admin', 'tesorero', 'integrante')),
  is_treasurer BOOLEAN NOT NULL DEFAULT false,
  avatar_url TEXT,
  birthday DATE NOT NULL DEFAULT '2005-01-01',
  phone TEXT,
  joined_at DATE NOT NULL DEFAULT CURRENT_DATE,
  points INTEGER NOT NULL DEFAULT 50,
  badges TEXT[] DEFAULT ARRAY['alegria'],
  service_area TEXT DEFAULT 'Misión y Visitas',
  spiritual_quote TEXT,
  emergency_contact TEXT,
  image_consent_accepted BOOLEAN NOT NULL DEFAULT true,
  is_minor BOOLEAN DEFAULT false,
  tutor_name TEXT,
  tutor_phone TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Migraciones seguras si jmv_profiles ya existía de una versión anterior
ALTER TABLE public.jmv_profiles ADD COLUMN IF NOT EXISTS group_key TEXT NOT NULL DEFAULT 'default';
ALTER TABLE public.jmv_profiles ADD COLUMN IF NOT EXISTS group_name TEXT;
ALTER TABLE public.jmv_profiles ADD COLUMN IF NOT EXISTS cedula TEXT;
ALTER TABLE public.jmv_profiles ADD COLUMN IF NOT EXISTS password TEXT;
ALTER TABLE public.jmv_profiles ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'aprobado';
ALTER TABLE public.jmv_profiles ADD COLUMN IF NOT EXISTS is_treasurer BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE public.jmv_profiles ADD COLUMN IF NOT EXISTS service_area TEXT DEFAULT 'Misión y Visitas';
ALTER TABLE public.jmv_profiles ADD COLUMN IF NOT EXISTS spiritual_quote TEXT;
ALTER TABLE public.jmv_profiles ADD COLUMN IF NOT EXISTS emergency_contact TEXT;
ALTER TABLE public.jmv_profiles ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

ALTER TABLE public.jmv_profiles DROP CONSTRAINT IF EXISTS jmv_profiles_role_check;
ALTER TABLE public.jmv_profiles ADD CONSTRAINT jmv_profiles_role_check
  CHECK (role IN ('admin', 'tesorero', 'integrante'));

ALTER TABLE public.jmv_profiles DROP CONSTRAINT IF EXISTS jmv_profiles_status_check;
ALTER TABLE public.jmv_profiles ADD CONSTRAINT jmv_profiles_status_check
  CHECK (status IN ('aprobado', 'pendiente_aprobacion'));

CREATE INDEX IF NOT EXISTS idx_jmv_profiles_email ON public.jmv_profiles (LOWER(email));
CREATE INDEX IF NOT EXISTS idx_jmv_profiles_cedula ON public.jmv_profiles (cedula);
CREATE INDEX IF NOT EXISTS idx_jmv_profiles_status ON public.jmv_profiles (status);
CREATE INDEX IF NOT EXISTS idx_jmv_profiles_group_key ON public.jmv_profiles (group_key);

-- 5. TABLAS PRIVADAS DE SECRETOS, CREDENCIALES Y SESIONES (SOLO ESQUEMA PRIVATE)
CREATE TABLE IF NOT EXISTS private.jmv_group_secrets (
  group_key TEXT PRIMARY KEY,
  invitation_code TEXT NOT NULL DEFAULT 'JMV2026',
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS private.jmv_profile_credentials (
  profile_id UUID PRIMARY KEY,
  password_hash TEXT NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS private.jmv_sessions (
  token_hash TEXT PRIMARY KEY,
  profile_id UUID NOT NULL REFERENCES public.jmv_profiles(id) ON DELETE CASCADE,
  group_key TEXT NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '30 days'),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_private_jmv_sessions_profile ON private.jmv_sessions (profile_id);
CREATE INDEX IF NOT EXISTS idx_private_jmv_sessions_expires ON private.jmv_sessions (expires_at);

ALTER TABLE private.jmv_group_secrets ENABLE ROW LEVEL SECURITY;
ALTER TABLE private.jmv_profile_credentials ENABLE ROW LEVEL SECURITY;
ALTER TABLE private.jmv_sessions ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON public.jmv_group_settings FROM PUBLIC;
REVOKE ALL ON private.jmv_group_secrets FROM PUBLIC, anon, authenticated;
REVOKE ALL ON private.jmv_profile_credentials FROM PUBLIC, anon, authenticated;
REVOKE ALL ON private.jmv_sessions FROM PUBLIC, anon, authenticated;

-- Migrar credenciales y códigos existentes hacia el esquema privado sin exponer texto plano
DO $$
BEGIN
  INSERT INTO private.jmv_group_secrets (group_key, invitation_code, updated_at)
  SELECT
    COALESCE(NULLIF(btrim(group_key), ''), CASE WHEN id = 'default' THEN 'default' ELSE id END),
    UPPER(regexp_replace(COALESCE(NULLIF(btrim(invitation_code), ''), 'JMV2026'), '\s+', '', 'g')),
    NOW()
  FROM public.jmv_group_settings
  WHERE COALESCE(btrim(invitation_code), '') NOT IN ('', '***')
  ON CONFLICT (group_key) DO UPDATE
    SET invitation_code = EXCLUDED.invitation_code,
        updated_at = NOW();

  UPDATE public.jmv_group_settings
  SET invitation_code = '***'
  WHERE invitation_code IS DISTINCT FROM '***';

  INSERT INTO private.jmv_profile_credentials (profile_id, password_hash, updated_at)
  SELECT
    id,
    crypt(COALESCE(NULLIF(btrim(password), ''), NULLIF(btrim(cedula), ''), id::text), gen_salt('bf')),
    NOW()
  FROM public.jmv_profiles
  WHERE COALESCE(btrim(password), btrim(cedula), '') <> ''
  ON CONFLICT (profile_id) DO NOTHING;

  UPDATE public.jmv_profiles
  SET password = NULL
  WHERE password IS NOT NULL;
END $$;

-- 6. RETOS SEMANALES Y ENTREGAS (jmv_challenges & jmv_challenge_submissions)
CREATE TABLE IF NOT EXISTS public.jmv_challenges (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_key TEXT NOT NULL DEFAULT 'default',
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  points INTEGER NOT NULL DEFAULT 50,
  reward TEXT NOT NULL,
  start_date DATE NOT NULL DEFAULT CURRENT_DATE,
  end_date DATE NOT NULL DEFAULT (CURRENT_DATE + INTERVAL '7 days'),
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_by TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.jmv_challenges ADD COLUMN IF NOT EXISTS group_key TEXT NOT NULL DEFAULT 'default';
CREATE INDEX IF NOT EXISTS idx_jmv_challenges_group_key ON public.jmv_challenges (group_key);

CREATE TABLE IF NOT EXISTS public.jmv_challenge_submissions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_key TEXT NOT NULL DEFAULT 'default',
  challenge_id UUID REFERENCES public.jmv_challenges(id) ON DELETE CASCADE,
  user_id UUID REFERENCES public.jmv_profiles(id) ON DELETE CASCADE,
  user_name TEXT NOT NULL,
  user_avatar TEXT,
  submitted_at TIMESTAMPTZ DEFAULT NOW(),
  comment TEXT,
  image_url TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  approved_by TEXT,
  approved_at TIMESTAMPTZ
);
ALTER TABLE public.jmv_challenge_submissions ADD COLUMN IF NOT EXISTS group_key TEXT NOT NULL DEFAULT 'default';
CREATE INDEX IF NOT EXISTS idx_jmv_challenge_submissions_group_key ON public.jmv_challenge_submissions (group_key);

-- 7. CAMPAÑAS DE VENTAS Y CUOTAS PRO-FONDOS (jmv_fee_campaigns)
CREATE TABLE IF NOT EXISTS public.jmv_fee_campaigns (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_key TEXT NOT NULL DEFAULT 'default',
  title TEXT NOT NULL,
  description TEXT,
  type TEXT NOT NULL DEFAULT 'venta' CHECK (type IN ('venta', 'extraordinaria', 'semanal')),
  unit_label TEXT NOT NULL DEFAULT 'plato',
  unit_price NUMERIC(10,2) NOT NULL DEFAULT 1.00,
  target_goal NUMERIC(10,2) NOT NULL DEFAULT 100.00,
  investment_per_person NUMERIC(10,2) NOT NULL DEFAULT 2.00,
  total_units_sold INTEGER DEFAULT 0,
  gross_revenue NUMERIC(10,2) DEFAULT 0.00,
  ingredient_costs NUMERIC(10,2) NOT NULL DEFAULT 0.00,
  deadline DATE,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_by TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.jmv_fee_campaigns ADD COLUMN IF NOT EXISTS group_key TEXT NOT NULL DEFAULT 'default';
ALTER TABLE public.jmv_fee_campaigns ADD COLUMN IF NOT EXISTS investment_per_person NUMERIC(10,2) NOT NULL DEFAULT 2.00;
ALTER TABLE public.jmv_fee_campaigns ADD COLUMN IF NOT EXISTS total_units_sold INTEGER DEFAULT 0;
ALTER TABLE public.jmv_fee_campaigns ADD COLUMN IF NOT EXISTS gross_revenue NUMERIC(10,2) DEFAULT 0.00;
ALTER TABLE public.jmv_fee_campaigns ADD COLUMN IF NOT EXISTS ingredient_costs NUMERIC(10,2) NOT NULL DEFAULT 0.00;
CREATE INDEX IF NOT EXISTS idx_jmv_fee_campaigns_group_key ON public.jmv_fee_campaigns (group_key);

-- 8. CUOTAS SEMANALES Y REGISTRO DE PAGOS / VENTAS ACUMULATIVAS
CREATE TABLE IF NOT EXISTS public.jmv_fee_weeks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_key TEXT NOT NULL DEFAULT 'default',
  week_number INTEGER NOT NULL,
  title TEXT NOT NULL,
  amount NUMERIC(8,2) NOT NULL DEFAULT 1.00,
  date DATE NOT NULL DEFAULT CURRENT_DATE
);
ALTER TABLE public.jmv_fee_weeks ADD COLUMN IF NOT EXISTS group_key TEXT NOT NULL DEFAULT 'default';
ALTER TABLE public.jmv_fee_weeks DROP CONSTRAINT IF EXISTS jmv_fee_weeks_week_number_key;
CREATE UNIQUE INDEX IF NOT EXISTS idx_jmv_fee_weeks_group_week ON public.jmv_fee_weeks (group_key, week_number);

CREATE TABLE IF NOT EXISTS public.jmv_fee_payments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_key TEXT NOT NULL DEFAULT 'default',
  user_id UUID REFERENCES public.jmv_profiles(id) ON DELETE CASCADE,
  user_name TEXT NOT NULL,
  week_id UUID REFERENCES public.jmv_fee_weeks(id) ON DELETE CASCADE,
  week_number INTEGER,
  campaign_id UUID REFERENCES public.jmv_fee_campaigns(id) ON DELETE CASCADE,
  payment_type TEXT NOT NULL DEFAULT 'cuota_semanal',
  quantity INTEGER DEFAULT 1,
  amount NUMERIC(10,2) NOT NULL DEFAULT 1.00,
  status TEXT NOT NULL DEFAULT 'pendiente' CHECK (status IN ('pagado', 'pendiente')),
  paid_at TIMESTAMPTZ,
  registered_by TEXT,
  note TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.jmv_fee_payments ADD COLUMN IF NOT EXISTS group_key TEXT NOT NULL DEFAULT 'default';
ALTER TABLE public.jmv_fee_payments ADD COLUMN IF NOT EXISTS campaign_id UUID REFERENCES public.jmv_fee_campaigns(id) ON DELETE CASCADE;
ALTER TABLE public.jmv_fee_payments ADD COLUMN IF NOT EXISTS payment_type TEXT NOT NULL DEFAULT 'cuota_semanal';
ALTER TABLE public.jmv_fee_payments ADD COLUMN IF NOT EXISTS quantity INTEGER DEFAULT 1;
ALTER TABLE public.jmv_fee_payments ALTER COLUMN week_number DROP NOT NULL;

ALTER TABLE public.jmv_fee_payments DROP CONSTRAINT IF EXISTS jmv_fee_payments_payment_type_check;
ALTER TABLE public.jmv_fee_payments ADD CONSTRAINT jmv_fee_payments_payment_type_check
  CHECK (payment_type IN ('cuota_semanal', 'semanal', 'inversion', 'venta'));
CREATE INDEX IF NOT EXISTS idx_jmv_fee_payments_group_key ON public.jmv_fee_payments (group_key);

-- 9. CHAT GRUPAL EN TIEMPO REAL (jmv_chat_messages)
CREATE TABLE IF NOT EXISTS public.jmv_chat_messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_key TEXT NOT NULL DEFAULT 'default',
  user_id UUID REFERENCES public.jmv_profiles(id) ON DELETE SET NULL,
  user_name TEXT NOT NULL,
  user_avatar TEXT,
  user_role TEXT NOT NULL DEFAULT 'integrante',
  text TEXT NOT NULL,
  image_url TEXT,
  is_pinned BOOLEAN NOT NULL DEFAULT false,
  pinned_by TEXT,
  reactions JSONB DEFAULT '{}'::jsonb,
  is_reported BOOLEAN NOT NULL DEFAULT false,
  report_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.jmv_chat_messages ADD COLUMN IF NOT EXISTS group_key TEXT NOT NULL DEFAULT 'default';
CREATE INDEX IF NOT EXISTS idx_jmv_chat_messages_group_key ON public.jmv_chat_messages (group_key);

-- 10. CALENDARIO Y ACTIVIDADES (jmv_activities)
CREATE TABLE IF NOT EXISTS public.jmv_activities (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_key TEXT NOT NULL DEFAULT 'default',
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('reunion', 'retiro', 'servicio', 'evento')),
  date DATE NOT NULL,
  time TEXT NOT NULL,
  location TEXT NOT NULL,
  attendees JSONB DEFAULT '[]'::jsonb,
  created_by TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.jmv_activities ADD COLUMN IF NOT EXISTS group_key TEXT NOT NULL DEFAULT 'default';
CREATE INDEX IF NOT EXISTS idx_jmv_activities_group_key ON public.jmv_activities (group_key);

-- 11. GASTOS EN ACTIVIDADES Y EGRESOS (jmv_activity_expenses)
CREATE TABLE IF NOT EXISTS public.jmv_activity_expenses (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_key TEXT NOT NULL DEFAULT 'default',
  title TEXT NOT NULL,
  description TEXT,
  activity_id UUID REFERENCES public.jmv_activities(id) ON DELETE SET NULL,
  activity_title TEXT,
  amount NUMERIC(10,2) NOT NULL,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  category TEXT NOT NULL DEFAULT 'refrigerio',
  receipt_url TEXT,
  registered_by TEXT NOT NULL,
  registered_by_id TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.jmv_activity_expenses ADD COLUMN IF NOT EXISTS group_key TEXT NOT NULL DEFAULT 'default';
ALTER TABLE public.jmv_activity_expenses ADD COLUMN IF NOT EXISTS registered_by_id TEXT;
CREATE INDEX IF NOT EXISTS idx_jmv_activity_expenses_group_key ON public.jmv_activity_expenses (group_key);

-- 12. MURO DE EXPERIENCIAS DE SERVICIO (jmv_service_experiences)
CREATE TABLE IF NOT EXISTS public.jmv_service_experiences (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_key TEXT NOT NULL DEFAULT 'default',
  user_id UUID REFERENCES public.jmv_profiles(id) ON DELETE CASCADE,
  user_name TEXT NOT NULL,
  user_avatar TEXT,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  location TEXT,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  image_url TEXT,
  likes TEXT[] DEFAULT ARRAY[]::TEXT[],
  reactions JSONB DEFAULT '{"oracion":0, "amor":0, "inspirador":0}'::jsonb,
  comments JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.jmv_service_experiences ADD COLUMN IF NOT EXISTS group_key TEXT NOT NULL DEFAULT 'default';
CREATE INDEX IF NOT EXISTS idx_jmv_service_experiences_group_key ON public.jmv_service_experiences (group_key);

-- 13. GALERÍA DE FOTOS (jmv_photo_albums & jmv_photos)
CREATE TABLE IF NOT EXISTS public.jmv_photo_albums (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_key TEXT NOT NULL DEFAULT 'default',
  title TEXT NOT NULL,
  description TEXT,
  cover_url TEXT NOT NULL,
  date TEXT NOT NULL,
  photo_count INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.jmv_photo_albums ADD COLUMN IF NOT EXISTS group_key TEXT NOT NULL DEFAULT 'default';
CREATE INDEX IF NOT EXISTS idx_jmv_photo_albums_group_key ON public.jmv_photo_albums (group_key);

CREATE TABLE IF NOT EXISTS public.jmv_photos (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_key TEXT NOT NULL DEFAULT 'default',
  album_id UUID REFERENCES public.jmv_photo_albums(id) ON DELETE CASCADE,
  url TEXT NOT NULL,
  caption TEXT,
  uploaded_by UUID REFERENCES public.jmv_profiles(id) ON DELETE SET NULL,
  uploaded_by_name TEXT NOT NULL,
  likes TEXT[] DEFAULT ARRAY[]::TEXT[],
  comments JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.jmv_photos ADD COLUMN IF NOT EXISTS group_key TEXT NOT NULL DEFAULT 'default';
CREATE INDEX IF NOT EXISTS idx_jmv_photos_group_key ON public.jmv_photos (group_key);

-- 14. AMIGO SECRETO SEMANAL (jmv_secret_rounds & jmv_secret_messages)
CREATE TABLE IF NOT EXISTS public.jmv_secret_rounds (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_key TEXT NOT NULL DEFAULT 'default',
  title TEXT NOT NULL,
  start_date DATE NOT NULL DEFAULT CURRENT_DATE,
  reveal_date DATE NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'revealed')),
  assignments JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.jmv_secret_rounds ADD COLUMN IF NOT EXISTS group_key TEXT NOT NULL DEFAULT 'default';
CREATE INDEX IF NOT EXISTS idx_jmv_secret_rounds_group_key ON public.jmv_secret_rounds (group_key);

CREATE TABLE IF NOT EXISTS public.jmv_secret_messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_key TEXT NOT NULL DEFAULT 'default',
  round_id UUID REFERENCES public.jmv_secret_rounds(id) ON DELETE CASCADE,
  giver_id UUID REFERENCES public.jmv_profiles(id) ON DELETE CASCADE,
  receiver_id UUID REFERENCES public.jmv_profiles(id) ON DELETE CASCADE,
  day_number INTEGER NOT NULL,
  text TEXT NOT NULL,
  sent_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.jmv_secret_messages ADD COLUMN IF NOT EXISTS group_key TEXT NOT NULL DEFAULT 'default';
CREATE INDEX IF NOT EXISTS idx_jmv_secret_messages_group_key ON public.jmv_secret_messages (group_key);

-- 15. MURO DE ORACIÓN (jmv_prayers)
CREATE TABLE IF NOT EXISTS public.jmv_prayers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_key TEXT NOT NULL DEFAULT 'default',
  user_id UUID REFERENCES public.jmv_profiles(id) ON DELETE SET NULL,
  user_name TEXT NOT NULL,
  is_anonymous BOOLEAN NOT NULL DEFAULT false,
  type TEXT NOT NULL CHECK (type IN ('peticion', 'agradecimiento')),
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  prayer_count INTEGER NOT NULL DEFAULT 1,
  prayed_by TEXT[] DEFAULT ARRAY[]::TEXT[],
  created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.jmv_prayers ADD COLUMN IF NOT EXISTS group_key TEXT NOT NULL DEFAULT 'default';
CREATE INDEX IF NOT EXISTS idx_jmv_prayers_group_key ON public.jmv_prayers (group_key);

-- 16. RECORDATORIOS, ASISTENCIA, ENCUESTAS, REFLEXIONES Y RECUPERACIÓN DE CLAVE
CREATE TABLE IF NOT EXISTS public.jmv_reminders (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_key TEXT NOT NULL DEFAULT 'default',
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  scheduled_for TIMESTAMPTZ NOT NULL,
  is_sent BOOLEAN NOT NULL DEFAULT false,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.jmv_reminders ADD COLUMN IF NOT EXISTS group_key TEXT NOT NULL DEFAULT 'default';
CREATE INDEX IF NOT EXISTS idx_jmv_reminders_group_key ON public.jmv_reminders (group_key);

CREATE TABLE IF NOT EXISTS public.jmv_attendance_sessions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_key TEXT NOT NULL DEFAULT 'default',
  title TEXT NOT NULL,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  records JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.jmv_attendance_sessions ADD COLUMN IF NOT EXISTS group_key TEXT NOT NULL DEFAULT 'default';
CREATE INDEX IF NOT EXISTS idx_jmv_attendance_sessions_group_key ON public.jmv_attendance_sessions (group_key);

CREATE TABLE IF NOT EXISTS public.jmv_polls (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_key TEXT NOT NULL DEFAULT 'default',
  question TEXT NOT NULL,
  options JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_by TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  expires_at TIMESTAMPTZ,
  is_closed BOOLEAN NOT NULL DEFAULT false
);
ALTER TABLE public.jmv_polls ADD COLUMN IF NOT EXISTS group_key TEXT NOT NULL DEFAULT 'default';
CREATE INDEX IF NOT EXISTS idx_jmv_polls_group_key ON public.jmv_polls (group_key);

CREATE TABLE IF NOT EXISTS public.jmv_advisor_reflections (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_key TEXT NOT NULL DEFAULT 'default',
  advisor_name TEXT NOT NULL,
  advisor_title TEXT NOT NULL,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  image_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.jmv_advisor_reflections ADD COLUMN IF NOT EXISTS group_key TEXT NOT NULL DEFAULT 'default';
CREATE INDEX IF NOT EXISTS idx_jmv_advisor_reflections_group_key ON public.jmv_advisor_reflections (group_key);

CREATE TABLE IF NOT EXISTS public.jmv_password_requests (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_key TEXT NOT NULL DEFAULT 'default',
  user_id UUID REFERENCES public.jmv_profiles(id) ON DELETE CASCADE,
  user_name TEXT NOT NULL,
  user_email TEXT NOT NULL,
  requested_at TIMESTAMPTZ DEFAULT NOW(),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'resolved'))
);
ALTER TABLE public.jmv_password_requests ADD COLUMN IF NOT EXISTS group_key TEXT NOT NULL DEFAULT 'default';
CREATE INDEX IF NOT EXISTS idx_jmv_password_requests_group_key ON public.jmv_password_requests (group_key);

-- ========================================================================
-- 17. FUNCIONES AUXILIARES DE SEGURIDAD RLS (SCHEMAS PRIVADOS + SECURITY DEFINER)
-- ========================================================================
CREATE OR REPLACE FUNCTION private.normalize_group_key(p_val TEXT)
RETURNS TEXT
LANGUAGE sql
IMMUTABLE
SET search_path = public, extensions, private
AS $$
  SELECT COALESCE(
    NULLIF(
      regexp_replace(
        regexp_replace(lower(btrim(COALESCE(p_val, ''))), '[^a-z0-9]+', '-', 'g'),
        '^-+|-+$', '', 'g'
      ),
      ''
    ),
    'default'
  );
$$;

CREATE OR REPLACE FUNCTION private.normalize_invite_code(p_val TEXT)
RETURNS TEXT
LANGUAGE sql
IMMUTABLE
SET search_path = public, extensions, private
AS $$
  SELECT UPPER(regexp_replace(COALESCE(p_val, ''), '[\s\u200B-\u200D\uFEFF]+', '', 'g'));
$$;

CREATE OR REPLACE FUNCTION private.request_session_token()
RETURNS TEXT
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, extensions, private
AS $$
DECLARE
  v_headers_raw TEXT;
  v_headers JSONB;
  v_client_info TEXT;
  v_token TEXT;
BEGIN
  v_headers_raw := current_setting('request.headers', true);
  IF v_headers_raw IS NULL OR btrim(v_headers_raw) = '' THEN
    RETURN NULL;
  END IF;
  v_headers := v_headers_raw::jsonb;
  v_client_info := COALESCE(v_headers ->> 'x-client-info', '');
  v_token := substring(v_client_info FROM 'jmv-session=([a-f0-9]{64})');
  IF v_token IS NULL THEN
    v_token := NULLIF(btrim(COALESCE(v_headers ->> 'x-jmv-session', '')), '');
  END IF;
  RETURN v_token;
EXCEPTION
  WHEN OTHERS THEN
    RETURN NULL;
END;
$$;

CREATE OR REPLACE FUNCTION private.current_session_user_id()
RETURNS UUID
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, extensions, private
AS $$
DECLARE
  v_raw_token TEXT;
  v_hash TEXT;
  v_profile_id UUID;
BEGIN
  IF auth.uid() IS NOT NULL THEN
    SELECT p.id INTO v_profile_id
    FROM public.jmv_profiles p
    WHERE p.user_id = auth.uid()
      AND (p.status = 'aprobado' OR p.role = 'admin')
    LIMIT 1;
    IF v_profile_id IS NOT NULL THEN
      RETURN v_profile_id;
    END IF;
  END IF;

  v_raw_token := private.request_session_token();
  IF v_raw_token IS NULL THEN
    RETURN NULL;
  END IF;

  v_hash := encode(digest(v_raw_token, 'sha256'), 'hex');
  SELECT s.profile_id INTO v_profile_id
  FROM private.jmv_sessions s
  JOIN public.jmv_profiles p ON p.id = s.profile_id
  WHERE s.token_hash = v_hash
    AND s.expires_at > NOW()
    AND (p.status = 'aprobado' OR p.role = 'admin')
  LIMIT 1;

  RETURN v_profile_id;
END;
$$;

CREATE OR REPLACE FUNCTION private.current_session_group_key()
RETURNS TEXT
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, extensions, private
AS $$
DECLARE
  v_uid UUID;
  v_group TEXT;
BEGIN
  v_uid := private.current_session_user_id();
  IF v_uid IS NULL THEN
    RETURN NULL;
  END IF;
  SELECT p.group_key INTO v_group
  FROM public.jmv_profiles p
  WHERE p.id = v_uid
  LIMIT 1;
  RETURN v_group;
END;
$$;

CREATE OR REPLACE FUNCTION private.is_group_member(p_group_key TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, extensions, private
AS $$
DECLARE
  v_uid UUID;
  v_user_group TEXT;
  v_target TEXT;
BEGIN
  v_uid := private.current_session_user_id();
  IF v_uid IS NULL THEN
    RETURN FALSE;
  END IF;
  SELECT p.group_key INTO v_user_group
  FROM public.jmv_profiles p
  WHERE p.id = v_uid
    AND (p.status = 'aprobado' OR p.role = 'admin')
  LIMIT 1;
  IF v_user_group IS NULL THEN
    RETURN FALSE;
  END IF;
  v_target := COALESCE(NULLIF(btrim(p_group_key), ''), 'default');
  RETURN v_user_group = v_target;
END;
$$;

CREATE OR REPLACE FUNCTION private.is_group_admin(p_group_key TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, extensions, private
AS $$
DECLARE
  v_uid UUID;
  v_target TEXT;
  v_ok BOOLEAN;
BEGIN
  v_uid := private.current_session_user_id();
  IF v_uid IS NULL THEN
    RETURN FALSE;
  END IF;
  v_target := COALESCE(NULLIF(btrim(p_group_key), ''), 'default');
  SELECT EXISTS (
    SELECT 1
    FROM public.jmv_profiles p
    WHERE p.id = v_uid
      AND p.group_key = v_target
      AND p.role = 'admin'
  ) INTO v_ok;
  RETURN COALESCE(v_ok, FALSE);
END;
$$;

CREATE OR REPLACE FUNCTION private.is_group_treasurer_or_admin(p_group_key TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, extensions, private
AS $$
DECLARE
  v_uid UUID;
  v_target TEXT;
  v_ok BOOLEAN;
BEGIN
  v_uid := private.current_session_user_id();
  IF v_uid IS NULL THEN
    RETURN FALSE;
  END IF;
  v_target := COALESCE(NULLIF(btrim(p_group_key), ''), 'default');
  SELECT EXISTS (
    SELECT 1
    FROM public.jmv_profiles p
    WHERE p.id = v_uid
      AND p.group_key = v_target
      AND (p.status = 'aprobado' OR p.role = 'admin')
      AND (p.role IN ('admin', 'tesorero') OR p.is_treasurer IS TRUE)
  ) INTO v_ok;
  RETURN COALESCE(v_ok, FALSE);
END;
$$;

GRANT EXECUTE ON FUNCTION private.normalize_group_key(TEXT) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION private.normalize_invite_code(TEXT) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION private.request_session_token() TO anon, authenticated;
GRANT EXECUTE ON FUNCTION private.current_session_user_id() TO anon, authenticated;
GRANT EXECUTE ON FUNCTION private.current_session_group_key() TO anon, authenticated;
GRANT EXECUTE ON FUNCTION private.is_group_member(TEXT) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION private.is_group_admin(TEXT) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION private.is_group_treasurer_or_admin(TEXT) TO anon, authenticated;

-- ========================================================================
-- 18. TRIGGERS DE PROTECCIÓN DE CONTRASEÑAS, CÓDIGOS Y ROLES
-- ========================================================================
CREATE OR REPLACE FUNCTION private.trg_protect_profile_write()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions, private
AS $$
DECLARE
  v_actor_id UUID;
  v_is_admin BOOLEAN;
BEGIN
  IF NEW.id IS NULL THEN
    NEW.id := uuid_generate_v4();
  END IF;
  NEW.group_key := COALESCE(NULLIF(btrim(NEW.group_key), ''), 'default');
  NEW.email := CASE WHEN NEW.email IS NOT NULL THEN lower(btrim(NEW.email)) ELSE NULL END;
  NEW.cedula := CASE WHEN NEW.cedula IS NOT NULL THEN btrim(NEW.cedula) ELSE NULL END;

  -- Evitar auto-escalado de privilegios por usuarios no administradores
  IF TG_OP = 'UPDATE' AND current_user NOT IN ('postgres', 'service_role', 'supabase_admin') THEN
    v_actor_id := private.current_session_user_id();
    v_is_admin := private.is_group_admin(OLD.group_key);
    IF v_actor_id IS NOT NULL AND NOT v_is_admin THEN
      NEW.role := OLD.role;
      NEW.is_treasurer := OLD.is_treasurer;
      NEW.status := OLD.status;
      NEW.group_key := OLD.group_key;
    END IF;
  END IF;

  -- Si llega una contraseña en texto plano, cifrarla en private.jmv_profile_credentials y limpiar columna pública
  IF NEW.password IS NOT NULL AND btrim(NEW.password) <> '' THEN
    INSERT INTO private.jmv_profile_credentials (profile_id, password_hash, updated_at)
    VALUES (NEW.id, crypt(btrim(NEW.password), gen_salt('bf')), NOW())
    ON CONFLICT (profile_id) DO UPDATE
      SET password_hash = EXCLUDED.password_hash,
          updated_at = NOW();
    NEW.password := NULL;
  ELSIF TG_OP = 'INSERT' AND NEW.cedula IS NOT NULL AND btrim(NEW.cedula) <> '' THEN
    INSERT INTO private.jmv_profile_credentials (profile_id, password_hash, updated_at)
    VALUES (NEW.id, crypt(btrim(NEW.cedula), gen_salt('bf')), NOW())
    ON CONFLICT (profile_id) DO NOTHING;
  END IF;

  NEW.updated_at := NOW();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_jmv_profiles_protect ON public.jmv_profiles;
CREATE TRIGGER trg_jmv_profiles_protect
  BEFORE INSERT OR UPDATE ON public.jmv_profiles
  FOR EACH ROW EXECUTE FUNCTION private.trg_protect_profile_write();

CREATE OR REPLACE FUNCTION private.trg_cleanup_profile_credentials()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions, private
AS $$
BEGIN
  DELETE FROM private.jmv_profile_credentials WHERE profile_id = OLD.id;
  RETURN OLD;
END;
$$;

DROP TRIGGER IF EXISTS trg_jmv_profiles_cleanup ON public.jmv_profiles;
CREATE TRIGGER trg_jmv_profiles_cleanup
  AFTER DELETE ON public.jmv_profiles
  FOR EACH ROW EXECUTE FUNCTION private.trg_cleanup_profile_credentials();

CREATE OR REPLACE FUNCTION private.trg_protect_group_settings()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions, private
AS $$
DECLARE
  v_key TEXT;
  v_clean_code TEXT;
BEGIN
  v_key := COALESCE(NULLIF(btrim(NEW.group_key), ''), CASE WHEN NEW.id = 'default' THEN 'default' ELSE NEW.id END);
  NEW.group_key := v_key;
  v_clean_code := private.normalize_invite_code(NEW.invitation_code);
  IF v_clean_code <> '' AND v_clean_code <> '***' THEN
    INSERT INTO private.jmv_group_secrets (group_key, invitation_code, updated_at)
    VALUES (v_key, v_clean_code, NOW())
    ON CONFLICT (group_key) DO UPDATE
      SET invitation_code = EXCLUDED.invitation_code,
          updated_at = NOW();
  END IF;
  NEW.invitation_code := '***';
  NEW.updated_at := NOW();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_jmv_group_settings_protect ON public.jmv_group_settings;
CREATE TRIGGER trg_jmv_group_settings_protect
  BEFORE INSERT OR UPDATE ON public.jmv_group_settings
  FOR EACH ROW EXECUTE FUNCTION private.trg_protect_group_settings();

-- ========================================================================
-- 19. FUNCIONES RPC SEGURAS PARA AUTENTICACIÓN, REGISTRO Y GRUPOS
-- ========================================================================
CREATE OR REPLACE FUNCTION public.jmv_health_check()
RETURNS JSONB
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, extensions, private
AS $$
  SELECT jsonb_build_object('ok', true, 'rls_enabled', true, 'version', '2026.2');
$$;

CREATE OR REPLACE FUNCTION public.jmv_list_public_groups()
RETURNS TABLE (
  group_key TEXT,
  group_name TEXT,
  parish_name TEXT,
  logo_url TEXT,
  banner_palette TEXT,
  banner_image_url TEXT,
  banner_image_opacity INTEGER,
  updated_at TIMESTAMPTZ
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, extensions, private
AS $$
  SELECT
    s.group_key,
    s.group_name,
    s.parish_name,
    s.logo_url,
    s.banner_palette,
    s.banner_image_url,
    s.banner_image_opacity,
    s.updated_at
  FROM public.jmv_group_settings s
  ORDER BY s.updated_at DESC NULLS LAST;
$$;

CREATE OR REPLACE FUNCTION public.jmv_get_group_settings(p_group_key TEXT)
RETURNS JSONB
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, extensions, private
AS $$
DECLARE
  v_key TEXT;
  v_row public.jmv_group_settings%ROWTYPE;
  v_is_admin BOOLEAN;
  v_code TEXT;
BEGIN
  v_key := COALESCE(NULLIF(btrim(p_group_key), ''), 'default');
  IF NOT private.is_group_member(v_key) THEN
    RETURN NULL;
  END IF;

  SELECT * INTO v_row
  FROM public.jmv_group_settings
  WHERE group_key = v_key OR id = v_key
  LIMIT 1;

  IF NOT FOUND THEN
    RETURN NULL;
  END IF;

  v_is_admin := private.is_group_admin(v_key);
  IF v_is_admin THEN
    SELECT gs.invitation_code INTO v_code
    FROM private.jmv_group_secrets gs
    WHERE gs.group_key = v_row.group_key
    LIMIT 1;
  END IF;

  RETURN jsonb_build_object(
    'id', v_row.id,
    'group_key', v_row.group_key,
    'group_name', v_row.group_name,
    'parish_name', v_row.parish_name,
    'logo_url', v_row.logo_url,
    'invitation_code', CASE WHEN v_is_admin THEN COALESCE(v_code, 'JMV2026') ELSE NULL END,
    'hoodie_goal_amount', v_row.hoodie_goal_amount,
    'hoodie_cost_per_person', v_row.hoodie_cost_per_person,
    'advisor_name', v_row.advisor_name,
    'next_meeting_date', v_row.next_meeting_date,
    'meeting_location', v_row.meeting_location,
    'banner_palette', v_row.banner_palette,
    'banner_image_url', v_row.banner_image_url,
    'banner_image_opacity', v_row.banner_image_opacity,
    'emailjs_service_id', CASE WHEN v_is_admin THEN v_row.emailjs_service_id ELSE NULL END,
    'emailjs_template_id', CASE WHEN v_is_admin THEN v_row.emailjs_template_id ELSE NULL END,
    'emailjs_public_key', CASE WHEN v_is_admin THEN v_row.emailjs_public_key ELSE NULL END,
    'updated_at', v_row.updated_at
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.jmv_verify_invitation_code(p_group_key TEXT, p_code TEXT)
RETURNS JSONB
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, extensions, private
AS $$
DECLARE
  v_key TEXT;
  v_entered TEXT;
  v_secret TEXT;
  v_group_name TEXT;
BEGIN
  v_key := COALESCE(NULLIF(btrim(p_group_key), ''), 'default');
  v_entered := private.normalize_invite_code(p_code);

  SELECT gs.invitation_code, s.group_name
  INTO v_secret, v_group_name
  FROM private.jmv_group_secrets gs
  LEFT JOIN public.jmv_group_settings s ON s.group_key = gs.group_key
  WHERE gs.group_key = v_key
  LIMIT 1;

  IF v_secret IS NULL THEN
    RETURN jsonb_build_object('configured', false, 'valid', false, 'group_key', v_key);
  END IF;

  RETURN jsonb_build_object(
    'configured', true,
    'valid', (v_entered <> '' AND v_entered = private.normalize_invite_code(v_secret)),
    'group_key', v_key,
    'group_name', v_group_name
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.jmv_register_member(
  p_group_key TEXT,
  p_group_name TEXT,
  p_name TEXT,
  p_email TEXT,
  p_cedula TEXT,
  p_password TEXT,
  p_birthday DATE DEFAULT '2005-01-01',
  p_phone TEXT DEFAULT NULL,
  p_invitation_code TEXT DEFAULT '',
  p_avatar_url TEXT DEFAULT NULL,
  p_image_consent_accepted BOOLEAN DEFAULT true,
  p_is_minor BOOLEAN DEFAULT false,
  p_tutor_name TEXT DEFAULT NULL,
  p_tutor_phone TEXT DEFAULT NULL,
  p_service_area TEXT DEFAULT 'Misión y Visitas',
  p_spiritual_quote TEXT DEFAULT NULL,
  p_emergency_contact TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions, private
AS $$
DECLARE
  v_key TEXT;
  v_email TEXT;
  v_cedula TEXT;
  v_secret TEXT;
  v_entered TEXT;
  v_new_id UUID;
BEGIN
  v_key := COALESCE(NULLIF(btrim(p_group_key), ''), 'default');
  v_email := lower(btrim(COALESCE(p_email, '')));
  v_cedula := btrim(COALESCE(p_cedula, ''));
  v_entered := private.normalize_invite_code(p_invitation_code);

  IF NOT COALESCE(p_image_consent_accepted, false) THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Debes aceptar la autorización de uso interno de imagen.');
  END IF;

  IF btrim(COALESCE(p_name, '')) = '' OR v_email = '' OR position('@' IN v_email) = 0 OR v_cedula = '' THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Completa nombre, correo electrónico válido y cédula.');
  END IF;

  SELECT gs.invitation_code INTO v_secret
  FROM private.jmv_group_secrets gs
  WHERE gs.group_key = v_key
  LIMIT 1;

  IF v_secret IS NOT NULL AND v_entered <> private.normalize_invite_code(v_secret) THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'INVALID_INVITATION_CODE', 'error', 'Código de invitación incorrecto para el grupo seleccionado.');
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.jmv_profiles
    WHERE group_key = v_key AND lower(email) = v_email
  ) THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Ya existe un integrante registrado con este correo en este grupo.');
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.jmv_profiles
    WHERE group_key = v_key AND btrim(cedula) = v_cedula
  ) THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Ya existe un integrante registrado con esta cédula en este grupo.');
  END IF;

  v_new_id := uuid_generate_v4();
  INSERT INTO public.jmv_profiles (
    id, group_key, group_name, name, email, cedula, password,
    status, role, is_treasurer, avatar_url, birthday, phone,
    joined_at, points, badges, service_area, spiritual_quote,
    emergency_contact, image_consent_accepted, is_minor, tutor_name, tutor_phone
  ) VALUES (
    v_new_id,
    v_key,
    NULLIF(btrim(COALESCE(p_group_name, '')), ''),
    btrim(p_name),
    v_email,
    v_cedula,
    COALESCE(NULLIF(btrim(COALESCE(p_password, '')), ''), v_cedula),
    'pendiente_aprobacion',
    'integrante',
    false,
    p_avatar_url,
    COALESCE(p_birthday, '2005-01-01'::date),
    NULLIF(btrim(COALESCE(p_phone, '')), ''),
    CURRENT_DATE,
    50,
    ARRAY['alegria'],
    COALESCE(NULLIF(btrim(COALESCE(p_service_area, '')), ''), 'Misión y Visitas'),
    NULLIF(btrim(COALESCE(p_spiritual_quote, '')), ''),
    NULLIF(btrim(COALESCE(p_emergency_contact, '')), ''),
    true,
    COALESCE(p_is_minor, false),
    NULLIF(btrim(COALESCE(p_tutor_name, '')), ''),
    NULLIF(btrim(COALESCE(p_tutor_phone, '')), '')
  );

  RETURN jsonb_build_object(
    'ok', true,
    'id', v_new_id,
    'status', 'pendiente_aprobacion',
    'group_key', v_key
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.jmv_create_group_workspace(
  p_group_key TEXT,
  p_group_name TEXT,
  p_parish_name TEXT DEFAULT '',
  p_invitation_code TEXT DEFAULT 'JMV2026',
  p_logo_url TEXT DEFAULT NULL,
  p_coord_name TEXT DEFAULT 'Coordinador JMV',
  p_coord_email TEXT DEFAULT '',
  p_coord_cedula TEXT DEFAULT '',
  p_coord_password TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions, private
AS $$
DECLARE
  v_key TEXT;
  v_code TEXT;
  v_email TEXT;
  v_cedula TEXT;
  v_coord_id UUID;
  v_raw_token TEXT;
  v_token_hash TEXT;
  v_profile public.jmv_profiles%ROWTYPE;
BEGIN
  v_key := private.normalize_group_key(COALESCE(NULLIF(btrim(p_group_key), ''), p_group_name));
  v_code := private.normalize_invite_code(p_invitation_code);
  v_email := lower(btrim(COALESCE(p_coord_email, '')));
  v_cedula := btrim(COALESCE(p_coord_cedula, ''));

  IF btrim(COALESCE(p_group_name, '')) = '' OR length(v_code) < 3 OR v_email = '' OR v_cedula = '' THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Completa el nombre del grupo, código privado y datos del coordinador.');
  END IF;

  IF EXISTS (SELECT 1 FROM public.jmv_group_settings WHERE group_key = v_key OR id = v_key) THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Ya existe un grupo registrado con ese nombre en la base de datos.');
  END IF;

  INSERT INTO public.jmv_group_settings (
    id, group_key, group_name, parish_name, logo_url, invitation_code, updated_at
  ) VALUES (
    v_key, v_key, btrim(p_group_name), NULLIF(btrim(COALESCE(p_parish_name, '')), ''), p_logo_url, v_code, NOW()
  );

  v_coord_id := uuid_generate_v4();
  INSERT INTO public.jmv_profiles (
    id, group_key, group_name, name, email, cedula, password,
    status, role, is_treasurer, points, badges, image_consent_accepted, is_minor
  ) VALUES (
    v_coord_id,
    v_key,
    btrim(p_group_name),
    btrim(p_coord_name),
    v_email,
    v_cedula,
    COALESCE(NULLIF(btrim(COALESCE(p_coord_password, '')), ''), v_cedula),
    'aprobado',
    'admin',
    true,
    100,
    ARRAY['constancia', 'servicio'],
    true,
    false
  )
  RETURNING * INTO v_profile;

  v_raw_token := encode(gen_random_bytes(32), 'hex');
  v_token_hash := encode(digest(v_raw_token, 'sha256'), 'hex');
  INSERT INTO private.jmv_sessions (token_hash, profile_id, group_key, expires_at)
  VALUES (v_token_hash, v_coord_id, v_key, NOW() + INTERVAL '30 days');

  RETURN jsonb_build_object(
    'ok', true,
    'group_key', v_key,
    'session_token', v_raw_token,
    'profile', to_jsonb(v_profile) - 'password'
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.jmv_login(
  p_identifier TEXT,
  p_password TEXT,
  p_group_key TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions, private
AS $$
DECLARE
  v_ident TEXT;
  v_ident_digits TEXT;
  v_pass TEXT;
  v_group TEXT;
  v_profile public.jmv_profiles%ROWTYPE;
  v_hash TEXT;
  v_raw_token TEXT;
  v_token_hash TEXT;
  v_settings public.jmv_group_settings%ROWTYPE;
  v_code TEXT;
BEGIN
  v_ident := lower(btrim(COALESCE(p_identifier, '')));
  v_ident_digits := regexp_replace(v_ident, '\D', '', 'g');
  v_pass := btrim(COALESCE(p_password, ''));
  v_group := NULLIF(btrim(COALESCE(p_group_key, '')), '');

  IF v_ident = '' OR v_pass = '' THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'MISSING_FIELDS');
  END IF;

  SELECT p.* INTO v_profile
  FROM public.jmv_profiles p
  WHERE (v_group IS NULL OR p.group_key = v_group)
    AND (
      lower(btrim(COALESCE(p.email, ''))) = v_ident
      OR lower(btrim(COALESCE(p.cedula, ''))) = v_ident
      OR (length(v_ident_digits) >= 6 AND regexp_replace(COALESCE(p.cedula, ''), '\D', '', 'g') = v_ident_digits)
    )
  ORDER BY (p.role = 'admin') DESC, p.created_at ASC
  LIMIT 1;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'NOT_FOUND');
  END IF;

  SELECT c.password_hash INTO v_hash
  FROM private.jmv_profile_credentials c
  WHERE c.profile_id = v_profile.id;

  IF v_hash IS NULL OR v_hash <> crypt(v_pass, v_hash) THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'INVALID_PASSWORD');
  END IF;

  IF v_profile.status = 'pendiente_aprobacion' AND v_profile.role <> 'admin' THEN
    RETURN jsonb_build_object(
      'ok', false,
      'reason', 'PENDING_APPROVAL',
      'group_key', v_profile.group_key,
      'group_name', v_profile.group_name
    );
  END IF;

  DELETE FROM private.jmv_sessions WHERE expires_at < NOW();

  v_raw_token := encode(gen_random_bytes(32), 'hex');
  v_token_hash := encode(digest(v_raw_token, 'sha256'), 'hex');
  INSERT INTO private.jmv_sessions (token_hash, profile_id, group_key, expires_at)
  VALUES (v_token_hash, v_profile.id, v_profile.group_key, NOW() + INTERVAL '30 days');

  SELECT * INTO v_settings
  FROM public.jmv_group_settings s
  WHERE s.group_key = v_profile.group_key OR s.id = v_profile.group_key
  LIMIT 1;

  IF v_profile.role = 'admin' THEN
    SELECT gs.invitation_code INTO v_code
    FROM private.jmv_group_secrets gs
    WHERE gs.group_key = v_profile.group_key
    LIMIT 1;
  END IF;

  RETURN jsonb_build_object(
    'ok', true,
    'session_token', v_raw_token,
    'profile', to_jsonb(v_profile) - 'password',
    'group_settings', CASE
      WHEN v_settings.id IS NOT NULL THEN jsonb_build_object(
        'group_key', v_settings.group_key,
        'group_name', v_settings.group_name,
        'parish_name', v_settings.parish_name,
        'logo_url', v_settings.logo_url,
        'invitation_code', CASE WHEN v_profile.role = 'admin' THEN COALESCE(v_code, 'JMV2026') ELSE NULL END,
        'hoodie_goal_amount', v_settings.hoodie_goal_amount,
        'hoodie_cost_per_person', v_settings.hoodie_cost_per_person,
        'advisor_name', v_settings.advisor_name,
        'next_meeting_date', v_settings.next_meeting_date,
        'meeting_location', v_settings.meeting_location,
        'banner_palette', v_settings.banner_palette,
        'banner_image_url', v_settings.banner_image_url,
        'banner_image_opacity', v_settings.banner_image_opacity
      )
      ELSE NULL
    END
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.jmv_logout()
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions, private
AS $$
DECLARE
  v_raw_token TEXT;
  v_hash TEXT;
BEGIN
  v_raw_token := private.request_session_token();
  IF v_raw_token IS NOT NULL THEN
    v_hash := encode(digest(v_raw_token, 'sha256'), 'hex');
    DELETE FROM private.jmv_sessions WHERE token_hash = v_hash;
  END IF;
  RETURN jsonb_build_object('ok', true);
END;
$$;

CREATE OR REPLACE FUNCTION public.jmv_request_password_recovery(
  p_identifier TEXT,
  p_group_key TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions, private
AS $$
DECLARE
  v_ident TEXT;
  v_ident_digits TEXT;
  v_group TEXT;
  v_profile public.jmv_profiles%ROWTYPE;
BEGIN
  v_ident := lower(btrim(COALESCE(p_identifier, '')));
  v_ident_digits := regexp_replace(v_ident, '\D', '', 'g');
  v_group := NULLIF(btrim(COALESCE(p_group_key, '')), '');

  IF v_ident = '' THEN
    RETURN jsonb_build_object('found', false);
  END IF;

  SELECT p.* INTO v_profile
  FROM public.jmv_profiles p
  WHERE (v_group IS NULL OR p.group_key = v_group)
    AND (
      lower(btrim(COALESCE(p.email, ''))) = v_ident
      OR lower(btrim(COALESCE(p.cedula, ''))) = v_ident
      OR (length(v_ident_digits) >= 6 AND regexp_replace(COALESCE(p.cedula, ''), '\D', '', 'g') = v_ident_digits)
    )
  LIMIT 1;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('found', false);
  END IF;

  DELETE FROM public.jmv_password_requests
  WHERE user_id = v_profile.id AND status = 'pending';

  INSERT INTO public.jmv_password_requests (group_key, user_id, user_name, user_email, status)
  VALUES (v_profile.group_key, v_profile.id, v_profile.name, COALESCE(v_profile.email, ''), 'pending');

  RETURN jsonb_build_object(
    'found', true,
    'user_name', v_profile.name,
    'user_email', v_profile.email,
    'group_key', v_profile.group_key
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.jmv_reset_password_with_cedula(
  p_identifier TEXT,
  p_cedula TEXT,
  p_new_password TEXT DEFAULT NULL,
  p_group_key TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions, private
AS $$
DECLARE
  v_ident TEXT;
  v_ident_digits TEXT;
  v_ced TEXT;
  v_ced_digits TEXT;
  v_group TEXT;
  v_profile public.jmv_profiles%ROWTYPE;
  v_prof_ced TEXT;
  v_prof_ced_digits TEXT;
  v_new_pass TEXT;
BEGIN
  v_ident := lower(btrim(COALESCE(p_identifier, '')));
  v_ident_digits := regexp_replace(v_ident, '\D', '', 'g');
  v_ced := lower(btrim(COALESCE(p_cedula, '')));
  v_ced_digits := regexp_replace(v_ced, '\D', '', 'g');
  v_group := NULLIF(btrim(COALESCE(p_group_key, '')), '');
  v_new_pass := btrim(COALESCE(p_new_password, ''));

  SELECT p.* INTO v_profile
  FROM public.jmv_profiles p
  WHERE (v_group IS NULL OR p.group_key = v_group)
    AND (
      lower(btrim(COALESCE(p.email, ''))) = v_ident
      OR lower(btrim(COALESCE(p.cedula, ''))) = v_ident
      OR (length(v_ident_digits) >= 6 AND regexp_replace(COALESCE(p.cedula, ''), '\D', '', 'g') = v_ident_digits)
    )
  LIMIT 1;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'NOT_FOUND');
  END IF;

  v_prof_ced := lower(btrim(COALESCE(v_profile.cedula, '')));
  v_prof_ced_digits := regexp_replace(v_prof_ced, '\D', '', 'g');

  IF NOT (
    v_prof_ced = v_ced
    OR (length(v_ced_digits) >= 6 AND v_ced_digits = v_prof_ced_digits)
  ) THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'CEDULA_MISMATCH');
  END IF;

  IF v_new_pass <> '' THEN
    INSERT INTO private.jmv_profile_credentials (profile_id, password_hash, updated_at)
    VALUES (v_profile.id, crypt(v_new_pass, gen_salt('bf')), NOW())
    ON CONFLICT (profile_id) DO UPDATE
      SET password_hash = EXCLUDED.password_hash,
          updated_at = NOW();

    UPDATE public.jmv_password_requests
    SET status = 'resolved'
    WHERE user_id = v_profile.id AND status = 'pending';
  END IF;

  RETURN jsonb_build_object(
    'ok', true,
    'password_updated', (v_new_pass <> ''),
    'user_name', v_profile.name,
    'user_email', v_profile.email
  );
END;
$$;

GRANT EXECUTE ON FUNCTION public.jmv_health_check() TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.jmv_list_public_groups() TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.jmv_get_group_settings(TEXT) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.jmv_verify_invitation_code(TEXT, TEXT) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.jmv_register_member(TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, DATE, TEXT, TEXT, TEXT, BOOLEAN, BOOLEAN, TEXT, TEXT, TEXT, TEXT, TEXT) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.jmv_create_group_workspace(TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.jmv_login(TEXT, TEXT, TEXT) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.jmv_logout() TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.jmv_request_password_recovery(TEXT, TEXT) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.jmv_reset_password_with_cedula(TEXT, TEXT, TEXT, TEXT) TO anon, authenticated;

-- ========================================================================
-- 20. HABILITAR RLS ESTRICTO EN TODAS LAS TABLAS (SIN USING(true))
-- ========================================================================
ALTER TABLE public.jmv_group_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.jmv_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.jmv_challenges ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.jmv_challenge_submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.jmv_fee_campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.jmv_fee_weeks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.jmv_fee_payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.jmv_chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.jmv_activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.jmv_activity_expenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.jmv_service_experiences ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.jmv_photo_albums ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.jmv_photos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.jmv_secret_rounds ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.jmv_secret_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.jmv_prayers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.jmv_reminders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.jmv_attendance_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.jmv_polls ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.jmv_advisor_reflections ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.jmv_password_requests ENABLE ROW LEVEL SECURITY;

-- Limpiar cualquier política permisiva heredada de versiones previas
DO $$
DECLARE
  rec RECORD;
BEGIN
  FOR rec IN
    SELECT schemaname, tablename, policyname
    FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename LIKE 'jmv_%'
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON %I.%I', rec.policyname, rec.schemaname, rec.tablename);
  END LOOP;
END $$;

-- 20.1 jmv_group_settings: solo el Admin del grupo puede consultar/editar directo la tabla
CREATE POLICY "rls_settings_admin_select" ON public.jmv_group_settings
  FOR SELECT USING (private.is_group_admin(group_key));
CREATE POLICY "rls_settings_admin_insert" ON public.jmv_group_settings
  FOR INSERT WITH CHECK (private.is_group_admin(group_key));
CREATE POLICY "rls_settings_admin_update" ON public.jmv_group_settings
  FOR UPDATE USING (private.is_group_admin(group_key))
  WITH CHECK (private.is_group_admin(group_key));
CREATE POLICY "rls_settings_admin_delete" ON public.jmv_group_settings
  FOR DELETE USING (private.is_group_admin(group_key));

-- 20.2 jmv_profiles: miembros aprobados ven su grupo; usuario edita su perfil (sin escalar rol); admin gestiona su grupo
CREATE POLICY "rls_profiles_member_select" ON public.jmv_profiles
  FOR SELECT USING (private.is_group_member(group_key));
CREATE POLICY "rls_profiles_admin_insert" ON public.jmv_profiles
  FOR INSERT WITH CHECK (private.is_group_admin(group_key));
CREATE POLICY "rls_profiles_self_or_admin_update" ON public.jmv_profiles
  FOR UPDATE USING (
    private.is_group_admin(group_key)
    OR (private.is_group_member(group_key) AND id = private.current_session_user_id())
  )
  WITH CHECK (
    private.is_group_admin(group_key)
    OR (private.is_group_member(group_key) AND id = private.current_session_user_id())
  );
CREATE POLICY "rls_profiles_admin_delete" ON public.jmv_profiles
  FOR DELETE USING (private.is_group_admin(group_key));

-- 20.3 jmv_challenges: lectura miembros del grupo, gestión solo admin del grupo
CREATE POLICY "rls_challenges_member_select" ON public.jmv_challenges
  FOR SELECT USING (private.is_group_member(group_key));
CREATE POLICY "rls_challenges_admin_all" ON public.jmv_challenges
  FOR ALL USING (private.is_group_admin(group_key))
  WITH CHECK (private.is_group_admin(group_key));

-- 20.4 jmv_challenge_submissions: lectura miembros, envío propio o admin, edición/borrado dueño o admin
CREATE POLICY "rls_submissions_member_select" ON public.jmv_challenge_submissions
  FOR SELECT USING (private.is_group_member(group_key));
CREATE POLICY "rls_submissions_member_insert" ON public.jmv_challenge_submissions
  FOR INSERT WITH CHECK (
    private.is_group_member(group_key)
    AND (user_id = private.current_session_user_id() OR private.is_group_admin(group_key))
  );
CREATE POLICY "rls_submissions_owner_or_admin_update" ON public.jmv_challenge_submissions
  FOR UPDATE USING (
    private.is_group_admin(group_key)
    OR (private.is_group_member(group_key) AND user_id = private.current_session_user_id())
  )
  WITH CHECK (
    private.is_group_admin(group_key)
    OR (private.is_group_member(group_key) AND user_id = private.current_session_user_id())
  );
CREATE POLICY "rls_submissions_owner_or_admin_delete" ON public.jmv_challenge_submissions
  FOR DELETE USING (
    private.is_group_admin(group_key)
    OR (private.is_group_member(group_key) AND user_id = private.current_session_user_id())
  );

-- 20.5 jmv_fee_campaigns & jmv_fee_weeks: lectura miembros, gestión solo tesorero o admin del grupo
CREATE POLICY "rls_fee_campaigns_member_select" ON public.jmv_fee_campaigns
  FOR SELECT USING (private.is_group_member(group_key));
CREATE POLICY "rls_fee_campaigns_treasurer_all" ON public.jmv_fee_campaigns
  FOR ALL USING (private.is_group_treasurer_or_admin(group_key))
  WITH CHECK (private.is_group_treasurer_or_admin(group_key));

CREATE POLICY "rls_fee_weeks_member_select" ON public.jmv_fee_weeks
  FOR SELECT USING (private.is_group_member(group_key));
CREATE POLICY "rls_fee_weeks_treasurer_all" ON public.jmv_fee_weeks
  FOR ALL USING (private.is_group_treasurer_or_admin(group_key))
  WITH CHECK (private.is_group_treasurer_or_admin(group_key));

-- 20.6 jmv_fee_payments: cada integrante ve SOLO sus pagos; tesorero/admin ve y gestiona los de su grupo
CREATE POLICY "rls_fee_payments_owner_or_treasurer_select" ON public.jmv_fee_payments
  FOR SELECT USING (
    private.is_group_treasurer_or_admin(group_key)
    OR (private.is_group_member(group_key) AND user_id = private.current_session_user_id())
  );
CREATE POLICY "rls_fee_payments_treasurer_all" ON public.jmv_fee_payments
  FOR ALL USING (private.is_group_treasurer_or_admin(group_key))
  WITH CHECK (private.is_group_treasurer_or_admin(group_key));

-- 20.7 jmv_activity_expenses: lectura miembros del grupo, gestión tesorero o admin
CREATE POLICY "rls_expenses_member_select" ON public.jmv_activity_expenses
  FOR SELECT USING (private.is_group_member(group_key));
CREATE POLICY "rls_expenses_treasurer_all" ON public.jmv_activity_expenses
  FOR ALL USING (private.is_group_treasurer_or_admin(group_key))
  WITH CHECK (private.is_group_treasurer_or_admin(group_key));

-- 20.8 jmv_chat_messages: solo miembros de ese grupo
CREATE POLICY "rls_chat_member_select" ON public.jmv_chat_messages
  FOR SELECT USING (private.is_group_member(group_key));
CREATE POLICY "rls_chat_member_insert" ON public.jmv_chat_messages
  FOR INSERT WITH CHECK (
    private.is_group_member(group_key)
    AND (user_id IS NULL OR user_id = private.current_session_user_id() OR private.is_group_admin(group_key))
  );
CREATE POLICY "rls_chat_member_update" ON public.jmv_chat_messages
  FOR UPDATE USING (private.is_group_member(group_key))
  WITH CHECK (private.is_group_member(group_key));
CREATE POLICY "rls_chat_owner_or_admin_delete" ON public.jmv_chat_messages
  FOR DELETE USING (
    private.is_group_admin(group_key)
    OR (private.is_group_member(group_key) AND user_id = private.current_session_user_id())
  );

-- 20.9 jmv_activities: miembros leen y confirman asistencia; admin crea/elimina
CREATE POLICY "rls_activities_member_select" ON public.jmv_activities
  FOR SELECT USING (private.is_group_member(group_key));
CREATE POLICY "rls_activities_admin_insert" ON public.jmv_activities
  FOR INSERT WITH CHECK (private.is_group_admin(group_key));
CREATE POLICY "rls_activities_member_update" ON public.jmv_activities
  FOR UPDATE USING (private.is_group_member(group_key))
  WITH CHECK (private.is_group_member(group_key));
CREATE POLICY "rls_activities_admin_delete" ON public.jmv_activities
  FOR DELETE USING (private.is_group_admin(group_key));

-- 20.10 jmv_service_experiences: miembros del grupo
CREATE POLICY "rls_experiences_member_select" ON public.jmv_service_experiences
  FOR SELECT USING (private.is_group_member(group_key));
CREATE POLICY "rls_experiences_member_insert" ON public.jmv_service_experiences
  FOR INSERT WITH CHECK (
    private.is_group_member(group_key)
    AND (user_id = private.current_session_user_id() OR private.is_group_admin(group_key))
  );
CREATE POLICY "rls_experiences_member_update" ON public.jmv_service_experiences
  FOR UPDATE USING (private.is_group_member(group_key))
  WITH CHECK (private.is_group_member(group_key));
CREATE POLICY "rls_experiences_owner_or_admin_delete" ON public.jmv_service_experiences
  FOR DELETE USING (
    private.is_group_admin(group_key)
    OR (private.is_group_member(group_key) AND user_id = private.current_session_user_id())
  );

-- 20.11 jmv_photo_albums & jmv_photos
CREATE POLICY "rls_albums_member_select" ON public.jmv_photo_albums
  FOR SELECT USING (private.is_group_member(group_key));
CREATE POLICY "rls_albums_admin_all" ON public.jmv_photo_albums
  FOR ALL USING (private.is_group_admin(group_key))
  WITH CHECK (private.is_group_admin(group_key));

CREATE POLICY "rls_photos_member_select" ON public.jmv_photos
  FOR SELECT USING (private.is_group_member(group_key));
CREATE POLICY "rls_photos_member_insert" ON public.jmv_photos
  FOR INSERT WITH CHECK (
    private.is_group_member(group_key)
    AND (uploaded_by IS NULL OR uploaded_by = private.current_session_user_id() OR private.is_group_admin(group_key))
  );
CREATE POLICY "rls_photos_member_update" ON public.jmv_photos
  FOR UPDATE USING (private.is_group_member(group_key))
  WITH CHECK (private.is_group_member(group_key));
CREATE POLICY "rls_photos_owner_or_admin_delete" ON public.jmv_photos
  FOR DELETE USING (
    private.is_group_admin(group_key)
    OR (private.is_group_member(group_key) AND uploaded_by = private.current_session_user_id())
  );

-- 20.12 Amigo secreto: rondas (admin) y mensajes privados entre dador/receptor
CREATE POLICY "rls_secret_rounds_member_select" ON public.jmv_secret_rounds
  FOR SELECT USING (private.is_group_member(group_key));
CREATE POLICY "rls_secret_rounds_admin_all" ON public.jmv_secret_rounds
  FOR ALL USING (private.is_group_admin(group_key))
  WITH CHECK (private.is_group_admin(group_key));

CREATE POLICY "rls_secret_messages_participant_select" ON public.jmv_secret_messages
  FOR SELECT USING (
    private.is_group_member(group_key)
    AND (
      giver_id = private.current_session_user_id()
      OR receiver_id = private.current_session_user_id()
      OR private.is_group_admin(group_key)
    )
  );
CREATE POLICY "rls_secret_messages_giver_insert" ON public.jmv_secret_messages
  FOR INSERT WITH CHECK (
    private.is_group_member(group_key)
    AND giver_id = private.current_session_user_id()
  );
CREATE POLICY "rls_secret_messages_admin_delete" ON public.jmv_secret_messages
  FOR DELETE USING (private.is_group_admin(group_key));

-- 20.13 Muro de oración
CREATE POLICY "rls_prayers_member_select" ON public.jmv_prayers
  FOR SELECT USING (private.is_group_member(group_key));
CREATE POLICY "rls_prayers_member_insert" ON public.jmv_prayers
  FOR INSERT WITH CHECK (
    private.is_group_member(group_key)
    AND (user_id IS NULL OR user_id = private.current_session_user_id() OR private.is_group_admin(group_key))
  );
CREATE POLICY "rls_prayers_member_update" ON public.jmv_prayers
  FOR UPDATE USING (private.is_group_member(group_key))
  WITH CHECK (private.is_group_member(group_key));
CREATE POLICY "rls_prayers_owner_or_admin_delete" ON public.jmv_prayers
  FOR DELETE USING (
    private.is_group_admin(group_key)
    OR (private.is_group_member(group_key) AND user_id = private.current_session_user_id())
  );

-- 20.14 Recordatorios, asistencias, encuestas, reflexiones y recuperación de clave
CREATE POLICY "rls_reminders_member_select" ON public.jmv_reminders
  FOR SELECT USING (private.is_group_member(group_key));
CREATE POLICY "rls_reminders_admin_all" ON public.jmv_reminders
  FOR ALL USING (private.is_group_admin(group_key))
  WITH CHECK (private.is_group_admin(group_key));

CREATE POLICY "rls_attendance_member_select" ON public.jmv_attendance_sessions
  FOR SELECT USING (private.is_group_member(group_key));
CREATE POLICY "rls_attendance_admin_all" ON public.jmv_attendance_sessions
  FOR ALL USING (private.is_group_admin(group_key))
  WITH CHECK (private.is_group_admin(group_key));

CREATE POLICY "rls_polls_member_select" ON public.jmv_polls
  FOR SELECT USING (private.is_group_member(group_key));
CREATE POLICY "rls_polls_admin_insert" ON public.jmv_polls
  FOR INSERT WITH CHECK (private.is_group_admin(group_key));
CREATE POLICY "rls_polls_member_update" ON public.jmv_polls
  FOR UPDATE USING (private.is_group_member(group_key))
  WITH CHECK (private.is_group_member(group_key));
CREATE POLICY "rls_polls_admin_delete" ON public.jmv_polls
  FOR DELETE USING (private.is_group_admin(group_key));

CREATE POLICY "rls_reflections_member_select" ON public.jmv_advisor_reflections
  FOR SELECT USING (private.is_group_member(group_key));
CREATE POLICY "rls_reflections_admin_all" ON public.jmv_advisor_reflections
  FOR ALL USING (private.is_group_admin(group_key))
  WITH CHECK (private.is_group_admin(group_key));

CREATE POLICY "rls_password_requests_admin_all" ON public.jmv_password_requests
  FOR ALL USING (private.is_group_admin(group_key))
  WITH CHECK (private.is_group_admin(group_key));

-- ========================================================================
-- 21. HABILITAR TIEMPO REAL (Realtime) SIN ERRORES SI YA ESTÁN AÑADIDAS
-- ========================================================================
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime') THEN
    CREATE PUBLICATION supabase_realtime;
  END IF;
END $$;

DO $$
DECLARE
  tbl TEXT;
BEGIN
  FOREACH tbl IN ARRAY ARRAY[
    'jmv_profiles',
    'jmv_group_settings',
    'jmv_chat_messages',
    'jmv_prayers',
    'jmv_fee_campaigns',
    'jmv_fee_payments'
  ]
  LOOP
    BEGIN
      EXECUTE format('ALTER PUBLICATION supabase_realtime ADD TABLE public.%I', tbl);
    EXCEPTION
      WHEN duplicate_object THEN NULL;
    END;
  END LOOP;
END $$;

-- ========================================================================
-- ¡LISTO! Base de datos Supabase JMV protegida con RLS estricto por grupo y rol.
-- ========================================================================
