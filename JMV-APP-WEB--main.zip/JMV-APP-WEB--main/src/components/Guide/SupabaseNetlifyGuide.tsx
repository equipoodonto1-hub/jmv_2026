import React, { useState } from 'react';
import { X, Copy, Check, ExternalLink, Database, Globe, Github, Sparkles, Key, Link as LinkIcon, ShieldCheck } from 'lucide-react';
import { SUPABASE_SQL_SCRIPT } from '../../data/supabase_schema_text';
import { testSupabaseConnection, getSupabaseConfig, setCustomSupabaseConfig } from '../../services/supabaseClient';

export const SupabaseNetlifyGuide: React.FC<{ isOpen: boolean; onClose: () => void }> = ({
  isOpen,
  onClose,
}) => {
  const [copied, setCopied] = useState(false);
  const [testingConnection, setTestingConnection] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [activeTab, setActiveTab] = useState<'pasos' | 'sql'>('pasos');

  const [inputUrl, setInputUrl] = useState(() => getSupabaseConfig().url);
  const [inputKey, setInputKey] = useState(() => getSupabaseConfig().key);

  if (!isOpen) return null;

  const handleCopySql = () => {
    navigator.clipboard.writeText(SUPABASE_SQL_SCRIPT);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleTestConnection = async () => {
    setTestingConnection(true);
    setTestResult(null);
    setCustomSupabaseConfig(inputUrl, inputKey);
    const res = await testSupabaseConnection(inputUrl, inputKey);
    setTestResult(res);
    setTestingConnection(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="w-full max-w-2xl rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 my-8 animate-in fade-in">
        {/* Encabezado */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                Guía de Publicación: Netlify + Supabase
              </h2>
              <p className="text-xs text-slate-500">
                Paso a paso sencillo para desplegar gratis tu PWA de JMV
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Pestañas de la guía */}
        <div className="mt-4 flex items-center gap-2 p-1 bg-slate-100 dark:bg-slate-800/80 rounded-xl">
          <button
            onClick={() => setActiveTab('pasos')}
            className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-semibold transition ${
              activeTab === 'pasos'
                ? 'bg-white dark:bg-slate-900 text-blue-900 dark:text-blue-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            1. Guía Paso a Paso (Netlify + GitHub)
          </button>
          <button
            onClick={() => setActiveTab('sql')}
            className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-semibold transition ${
              activeTab === 'sql'
                ? 'bg-white dark:bg-slate-900 text-blue-900 dark:text-blue-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            2. Script SQL de Supabase (Copiar con 1 click)
          </button>
        </div>

        {activeTab === 'pasos' ? (
          <div className="mt-4 space-y-4 max-h-[60vh] overflow-y-auto pr-1 text-xs text-slate-700 dark:text-slate-300">
            {/* Paso 1 */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/60">
              <div className="flex items-center gap-2 text-slate-900 dark:text-white font-bold text-xs">
                <span className="w-5 h-5 rounded-full bg-blue-900 text-white flex items-center justify-center text-[10px]">
                  1
                </span>
                <Github className="w-4 h-4 text-slate-800 dark:text-slate-200" />
                <span>Subir el código a tu GitHub</span>
              </div>
              <p className="mt-1.5 text-slate-600 dark:text-slate-400">
                Descarga el repositorio o conéctalo con tu cuenta de GitHub en un nuevo repositorio (ej: <code className="bg-slate-200 dark:bg-slate-700 px-1 py-0.5 rounded">jmv-comunidad</code>).
              </p>
            </div>

            {/* Paso 2 */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/60">
              <div className="flex items-center gap-2 text-slate-900 dark:text-white font-bold text-xs">
                <span className="w-5 h-5 rounded-full bg-blue-900 text-white flex items-center justify-center text-[10px]">
                  2
                </span>
                <Database className="w-4 h-4 text-emerald-600" />
                <span>Crear tu base de datos gratuita en Supabase</span>
              </div>
              <ol className="mt-2 list-decimal list-inside space-y-1 text-slate-600 dark:text-slate-400">
                <li>
                  Ingresa a <a href="https://supabase.com" target="_blank" rel="noreferrer" className="text-blue-600 font-semibold underline inline-flex items-center gap-0.5">supabase.com <ExternalLink className="w-3 h-3" /></a> y crea una cuenta gratuita.
                </li>
                <li>Crea un <strong>"New Project"</strong> (ej: nombre "JMV Grupo", elige tu región más cercana).</li>
                <li>En el menú lateral izquierdo, haz click en <strong>"SQL Editor"</strong>.</li>
                <li>Pega el script de la pestaña <strong>"2. Script SQL de Supabase"</strong> y presiona <strong>RUN</strong>. ¡Creará todas las tablas y políticas de seguridad automáticamente!</li>
                <li>
                  Ve a <strong>Project Settings</strong> (icono de engranaje) &gt; <strong>API</strong> y copia:
                  <ul className="list-disc list-inside pl-4 mt-1 space-y-0.5 font-mono text-[11px]">
                    <li><strong>Project URL</strong> (ej: <code className="text-slate-800 dark:text-slate-200">https://xyzcompany.supabase.co</code>)</li>
                    <li><strong>anon public key</strong> (clave pública que empieza por <code className="text-slate-800 dark:text-slate-200">eyJhbG...</code>)</li>
                  </ul>
                </li>
              </ol>
            </div>

            {/* Paso 3 */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/60">
              <div className="flex items-center gap-2 text-slate-900 dark:text-white font-bold text-xs">
                <span className="w-5 h-5 rounded-full bg-blue-900 text-white flex items-center justify-center text-[10px]">
                  3
                </span>
                <Globe className="w-4 h-4 text-teal-600" />
                <span>Publicar en Netlify con 1 solo click</span>
              </div>
              <ol className="mt-2 list-decimal list-inside space-y-1 text-slate-600 dark:text-slate-400">
                <li>
                  Ingresa a <a href="https://netlify.com" target="_blank" rel="noreferrer" className="text-blue-600 font-semibold underline inline-flex items-center gap-0.5">netlify.com <ExternalLink className="w-3 h-3" /></a> y haz click en <strong>"Add new site" &gt; "Import an existing project"</strong>.
                </li>
                <li>Conecta con tu GitHub y selecciona el repositorio de JMV.</li>
                <li>
                  La configuración de compilación se detectará automáticamente gracias a nuestro <code className="bg-slate-200 dark:bg-slate-700 px-1 py-0.5 rounded font-mono">netlify.toml</code>:
                  <ul className="list-disc list-inside pl-4 mt-1 font-mono text-[11px]">
                    <li>Build command: <code className="text-blue-700 dark:text-blue-300">npm run build</code></li>
                    <li>Publish directory: <code className="text-blue-700 dark:text-blue-300">dist</code></li>
                  </ul>
                </li>
                <li>
                  En la sección <strong>"Environment variables"</strong> (o después en Site settings &gt; Environment variables), agrega:
                  <div className="mt-1.5 p-2 rounded-xl bg-slate-900 text-slate-100 font-mono text-[11px] space-y-1">
                    <p><span className="text-amber-400">VITE_SUPABASE_URL</span> = tu_project_url</p>
                    <p><span className="text-amber-400">VITE_SUPABASE_ANON_KEY</span> = tu_anon_public_key</p>
                  </div>
                </li>
                <li>Haz click en <strong>"Deploy Site"</strong>. ¡En 60 segundos tendrás tu app con HTTPS, PWA e instalable!</li>
              </ol>
            </div>

            {/* Conectar y Probar conexión en vivo */}
            <div className="p-4 rounded-2xl bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/40 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-blue-950 dark:text-blue-200 text-xs flex items-center gap-1.5">
                    <Database className="w-4 h-4 text-emerald-600" />
                    Conectar y Probar Supabase en este Navegador
                  </h4>
                  <p className="text-[11px] text-blue-800 dark:text-blue-300">
                    Pega aquí tus claves de Supabase para conectar y verificar la base de datos ahora mismo:
                  </p>
                </div>
              </div>

              <div className="space-y-2 text-xs">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 text-[11px] mb-0.5">
                    Project URL (ej: https://xyzcompany.supabase.co):
                  </label>
                  <input
                    type="url"
                    value={inputUrl}
                    onChange={(e) => setInputUrl(e.target.value)}
                    placeholder="https://xyzcompany.supabase.co"
                    className="w-full px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono text-[11px]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 text-[11px] mb-0.5">
                    anon public key (eyJhbG...):
                  </label>
                  <input
                    type="password"
                    value={inputKey}
                    onChange={(e) => setInputKey(e.target.value)}
                    placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                    className="w-full px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono text-[11px]"
                  />
                </div>

                <div className="flex items-center justify-end pt-1">
                  <button
                    onClick={handleTestConnection}
                    disabled={testingConnection}
                    className="px-3.5 py-2 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow transition active:scale-95 flex items-center gap-1.5"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>{testingConnection ? 'Verificando tablas...' : 'Guardar y Verificar Conexión'}</span>
                  </button>
                </div>
              </div>

              {testResult && (
                <div
                  className={`mt-2.5 p-3 rounded-xl text-xs font-medium border ${
                    testResult.success
                      ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-200 border-emerald-300'
                      : 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-200 border-amber-300'
                  }`}
                >
                  {testResult.message}
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="mt-4 space-y-3">
            <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/50 flex items-start gap-2 text-[11px] text-emerald-900 dark:text-emerald-200">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>
                <strong>Seguridad RLS estricta incluida:</strong> cero políticas <code className="font-mono">USING(true)</code>, contraseñas cifradas con <code className="font-mono">bcrypt</code> en esquema privado, códigos de invitación ocultos, sesiones verificadas y aislamiento por <code className="font-mono">group_key</code> en las 21 tablas.
              </span>
            </div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                Script SQL Completo (tablas, RLS estricto y realtime)
              </span>
              <button
                onClick={handleCopySql}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs transition active:scale-95 shadow"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? '¡Copiado al portapapeles!' : 'Copiar Script SQL'}</span>
              </button>
            </div>
            <pre className="p-4 rounded-2xl bg-slate-900 text-slate-100 font-mono text-[11px] max-h-[50vh] overflow-y-auto overflow-x-auto leading-relaxed border border-slate-800">
              {SUPABASE_SQL_SCRIPT}
            </pre>
          </div>
        )}

        <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
          <span className="text-slate-400 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-amber-500" /> JMV está listo para funcionar offline y con internet lento.
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold hover:bg-slate-200 dark:hover:bg-slate-700 transition"
          >
            Cerrar Guía
          </button>
        </div>
      </div>
    </div>
  );
};
