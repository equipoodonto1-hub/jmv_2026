import React, { useState } from 'react';
import { Heart, Plus, Sparkles, MessageCircle, X, Check, Shield } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const PrayerWallView: React.FC = () => {
  const { prayers, addPrayer, joinPrayer, currentUser } = useApp();

  const [showAddModal, setShowAddModal] = useState(false);
  const [filterType, setFilterType] = useState<'all' | 'peticion' | 'agradecimiento'>('all');

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [type, setType] = useState<'peticion' | 'agradecimiento'>('peticion');
  const [isAnonymous, setIsAnonymous] = useState(false);

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) return;

    addPrayer(title, description, type, isAnonymous);
    setTitle('');
    setDescription('');
    setShowAddModal(false);
  };

  const filteredPrayers = prayers.filter((p) => {
    if (filterType === 'all') return true;
    return p.type === filterType;
  });

  return (
    <div className="space-y-6 pb-20 animate-in fade-in">
      {/* Encabezado */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400">
              <span className="text-base">🕊️</span>
            </span>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
              Muro de Oración Comunitaria
            </h1>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Intenciones, peticiones por enfermos y familias, y acciones de gracias a Dios y a la Virgen.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow-md transition active:scale-95 shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Nueva Intención</span>
        </button>
      </div>

      {/* Filtro Segmented Control */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-800/80 rounded-2xl w-fit">
        <button
          onClick={() => setFilterType('all')}
          className={`px-4 py-1.5 rounded-xl text-xs font-bold transition ${
            filterType === 'all'
              ? 'bg-white dark:bg-slate-900 text-blue-900 dark:text-blue-400 shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          Todas ({prayers.length})
        </button>
        <button
          onClick={() => setFilterType('peticion')}
          className={`px-4 py-1.5 rounded-xl text-xs font-bold transition ${
            filterType === 'peticion'
              ? 'bg-white dark:bg-slate-900 text-blue-900 dark:text-blue-400 shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          Peticiones de Salud y Ayuda
        </button>
        <button
          onClick={() => setFilterType('agradecimiento')}
          className={`px-4 py-1.5 rounded-xl text-xs font-bold transition ${
            filterType === 'agradecimiento'
              ? 'bg-white dark:bg-slate-900 text-blue-900 dark:text-blue-400 shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          Acciones de Gracias
        </button>
      </div>

      {/* Grid de intenciones */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredPrayers.map((prayer) => {
          const hasPrayed = prayer.prayedBy.includes(currentUser.id);

          return (
            <div
              key={prayer.id}
              className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      prayer.type === 'peticion'
                        ? 'bg-blue-100 dark:bg-blue-950/60 text-blue-800 dark:text-blue-300'
                        : 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300'
                    }`}
                  >
                    {prayer.type === 'peticion' ? '🙏 Petición' : '✨ Acción de Gracias'}
                  </span>
                  <span className="text-[10px] text-slate-400">
                    {new Date(prayer.createdAt).toLocaleDateString('es-ES', {
                      day: 'numeric',
                      month: 'short',
                    })}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  {prayer.title}
                </h3>
                <p className="mt-1.5 text-xs text-slate-600 dark:text-slate-300 leading-relaxed whitespace-pre-wrap">
                  {prayer.description}
                </p>

                <div className="mt-3 text-[11px] text-slate-400">
                  Compartido por: <strong className="text-slate-600 dark:text-slate-300">{prayer.userName}</strong>
                </div>
              </div>

              {/* Botón "Me uno en oración" */}
              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <span className="text-xs text-slate-500">
                  <strong className="text-blue-900 dark:text-blue-400 tabular-nums">{prayer.prayerCount}</strong> hermanos orando
                </span>

                <button
                  onClick={() => joinPrayer(prayer.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition active:scale-95 ${
                    hasPrayed
                      ? 'bg-blue-900 text-white shadow-md'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                  }`}
                >
                  <span>🙏</span>
                  <span>{hasPrayed ? 'Orando contigo' : 'Me uno en oración'}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal: Nueva Petición / Agradecimiento */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 animate-in fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                Compartir Intención en el Muro de Oración
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Tipo de intención
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setType('peticion')}
                    className={`py-2 px-3 rounded-xl font-bold border transition ${
                      type === 'peticion'
                        ? 'bg-blue-50 dark:bg-blue-950 border-blue-600 text-blue-900 dark:text-blue-300'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600'
                    }`}
                  >
                    🙏 Petición
                  </button>
                  <button
                    type="button"
                    onClick={() => setType('agradecimiento')}
                    className={`py-2 px-3 rounded-xl font-bold border transition ${
                      type === 'agradecimiento'
                        ? 'bg-emerald-50 dark:bg-emerald-950 border-emerald-600 text-emerald-900 dark:text-emerald-300'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600'
                    }`}
                  >
                    ✨ Acción de Gracias
                  </button>
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Título breve *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Ej: Por la salud de mi abuelita"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Detalle de la oración *
                </label>
                <textarea
                  rows={3}
                  required
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Comparte la intención con tus hermanos vicencianos..."
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white leading-relaxed"
                />
              </div>

              {/* Opción anónima */}
              <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                <label className="flex items-center gap-2 cursor-pointer text-slate-700 dark:text-slate-300 font-medium">
                  <input
                    type="checkbox"
                    checked={isAnonymous}
                    onChange={(e) => setIsAnonymous(e.target.checked)}
                    className="w-4 h-4 rounded text-blue-600"
                  />
                  <span>Publicar como anónimo (ocultar mi nombre)</span>
                </label>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow mt-2"
              >
                Publicar Intención
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
