import React, { useState } from 'react';
import { Download, Share, PlusSquare, X } from 'lucide-react';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { useApp } from '../../context/AppContext';
import marianMedalImg from '../../assets/images/jmv_marian_medal_1794117311829.jpg';

export const PWAInstallButton: React.FC<{ compact?: boolean }> = ({ compact = false }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const { settings } = useApp();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  // Si ya se está ejecutando instalada en pantalla de inicio, no mostrar
  if (isInstalled) {
    return null;
  }

  // Flujo Android / Chrome / Edge
  if (isInstallable) {
    return (
      <button
        onClick={install}
        aria-label="Instalar app en celular"
        className={`flex items-center gap-2 rounded-xl bg-amber-500 hover:bg-amber-600 active:scale-95 text-slate-950 font-semibold shadow-md transition-all whitespace-nowrap shrink-0 ${
          compact ? 'px-2.5 py-1.5 text-xs' : 'px-3.5 py-2 text-xs md:text-sm'
        }`}
      >
        <Download className="w-4 h-4" />
        <span>Instalar App</span>
      </button>
    );
  }

  // Flujo iOS Safari (WebKit no soporta beforeinstallprompt nativo)
  if (isIOS) {
    return (
      <>
        <button
          onClick={() => setShowIOSGuide(true)}
          className={`flex items-center gap-1.5 rounded-xl border border-amber-400/40 bg-amber-500/10 hover:bg-amber-500/20 active:scale-95 text-amber-600 dark:text-amber-400 font-semibold transition-all whitespace-nowrap shrink-0 ${
            compact ? 'px-2.5 py-1.5 text-xs' : 'px-3 py-1.5 text-xs'
          }`}
        >
          <Download className="w-3.5 h-3.5" />
          <span>Instalar en iPhone</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in">
            <div className="w-full max-w-sm rounded-3xl bg-white p-6 shadow-2xl dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-white ring-1 ring-amber-400/70 p-0.5 flex items-center justify-center shadow shrink-0 overflow-hidden">
                    <img
                      src={settings.logoUrl || marianMedalImg}
                      alt={settings.groupName}
                      className="w-full h-full object-contain rounded-lg"
                    />
                  </div>
                  <div className="min-w-0">
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white truncate">Instalar en tu iPhone</h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                      Guarda {settings.groupName} en tu inicio
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setShowIOSGuide(false)}
                  className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="mt-4 space-y-3.5 text-xs text-slate-600 dark:text-slate-300">
                <div className="flex items-start gap-3 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60">
                  <div className="w-7 h-7 rounded-lg bg-blue-600/10 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
                    <Share className="w-4 h-4" />
                  </div>
                  <p>
                    1. En la barra inferior de Safari, toca el botón de <strong>Compartir</strong>.
                  </p>
                </div>
                <div className="flex items-start gap-3 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60">
                  <div className="w-7 h-7 rounded-lg bg-blue-600/10 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
                    <PlusSquare className="w-4 h-4" />
                  </div>
                  <p>
                    2. Desliza hacia abajo y presiona <strong>"Agregar al inicio"</strong>.
                  </p>
                </div>
                <div className="flex items-start gap-3 p-3 rounded-2xl bg-amber-500/10 text-amber-700 dark:text-amber-300">
                  <p>
                    ✨ ¡Listo! Se abrirá como una aplicación nativa rápida, sin barras de navegador y con acceso offline.
                  </p>
                </div>
              </div>

              <button
                onClick={() => setShowIOSGuide(false)}
                className="mt-5 w-full rounded-2xl bg-blue-900 py-3 text-xs font-bold text-white hover:bg-blue-800 transition"
              >
                Entendido
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  // Si no está disponible aún el evento en desktop, ofrecemos botón que explica cómo instalar
  return (
    <button
      onClick={() => {
        alert(`Para instalar "${settings.groupName}" en tu celular o computador, abre el menú de tu navegador (⋮ o icono de instalación en la barra de URL) y selecciona "Instalar aplicación".`);
      }}
      className={`hidden md:flex items-center gap-1.5 rounded-xl border border-blue-200 dark:border-blue-900/60 bg-blue-50/50 dark:bg-blue-950/30 text-blue-700 dark:text-blue-300 font-medium hover:bg-blue-100/50 transition-all ${
        compact ? 'px-2 py-1 text-xs' : 'px-3 py-1.5 text-xs'
      }`}
    >
      <Download className="w-3.5 h-3.5" />
      <span>Instalar App</span>
    </button>
  );
};
