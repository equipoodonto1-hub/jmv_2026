import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Image,
  Pin,
  Smile,
  AlertTriangle,
  BookOpen,
  X,
  Heart,
  ShieldAlert,
  Sparkles,
  Camera,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { compressImage } from '../../services/imageCompression';

const EMOJI_LIST = ['❤️', '🙏', '🙌', '⭐', '👏', '🔥', '🎸', '🕊️', '🎉', '😊'];

export const ChatView: React.FC = () => {
  const {
    currentUser,
    users,
    chatMessages,
    sendMessage,
    togglePinMessage,
    addMessageReaction,
    reportMessage,
    isAdmin,
  } = useApp();

  const [text, setText] = useState('');
  const [selectedImage, setSelectedImage] = useState<string>('');
  const [isCompressing, setIsCompressing] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showRulesModal, setShowRulesModal] = useState(false);
  const [activeReactionMsgId, setActiveReactionMsgId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll al final cuando llegan mensajes
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  const handleImagePick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsCompressing(true);
      const res = await compressImage(file, { maxWidth: 900, maxHeight: 900, quality: 0.8 });
      setSelectedImage(res.dataUrl);
    } catch (err) {
      console.error(err);
    } finally {
      setIsCompressing(false);
    }
  };

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() && !selectedImage) return;

    sendMessage(text, selectedImage || undefined);
    setText('');
    setSelectedImage('');
    setShowEmojiPicker(false);
  };

  const pinnedMessages = chatMessages.filter((m) => m.isPinned);

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] min-h-[500px] rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden animate-in fade-in">
      {/* Cabecera del chat con reglas de convivencia */}
      <div className="px-5 py-3.5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/40">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-2xl bg-blue-900 text-white flex items-center justify-center font-bold text-xs shadow-sm">
            JMV
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <span>Chat Grupal de la Comunidad</span>
              <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" title="En línea" />
            </h2>
            <p className="text-[10px] text-slate-400">
              Comunicación fraterna, caridad y avisos
            </p>
          </div>
        </div>

        <button
          onClick={() => setShowRulesModal(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-blue-200 dark:border-blue-900/60 bg-blue-50 dark:bg-blue-950/30 text-blue-800 dark:text-blue-300 text-xs font-semibold hover:bg-blue-100 transition"
        >
          <BookOpen className="w-3.5 h-3.5" />
          <span>Reglas de Convivencia</span>
        </button>
      </div>

      {/* Banner de mensajes fijados por el admin */}
      {pinnedMessages.length > 0 && (
        <div className="bg-amber-500/10 dark:bg-amber-500/5 border-b border-amber-500/20 px-4 py-2 flex items-center justify-between text-xs text-amber-900 dark:text-amber-200">
          <div className="flex items-center gap-2 overflow-hidden mr-2">
            <Pin className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0" />
            <span className="font-bold text-[11px] shrink-0">Fijado:</span>
            <p className="truncate text-[11px] font-medium text-slate-700 dark:text-slate-300">
              {pinnedMessages[pinnedMessages.length - 1].text}
            </p>
          </div>
          <span className="text-[10px] text-amber-700 dark:text-amber-400 font-semibold shrink-0">
            {(
              users.find((u) => u.id === pinnedMessages[pinnedMessages.length - 1].userId)?.name ||
              pinnedMessages[pinnedMessages.length - 1].userName
            ).split(' ')[0]}
          </span>
        </div>
      )}

      {/* Lista de Mensajes del Chat */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {chatMessages.map((msg) => {
          const isMe = msg.userId === currentUser.id;
          const liveAuthor = users.find((u) => u.id === msg.userId);
          const authorAvatar = liveAuthor?.avatarUrl || msg.userAvatar;
          const authorName = liveAuthor?.name || msg.userName;

          return (
            <div
              key={msg.id}
              className={`flex gap-2.5 max-w-[85%] sm:max-w-[75%] ${
                isMe ? 'ml-auto flex-row-reverse' : ''
              }`}
            >
              {/* Avatar */}
              <img
                src={authorAvatar}
                alt={authorName}
                className="w-8 h-8 rounded-full object-cover shrink-0 mt-1 ring-1 ring-slate-200 dark:ring-slate-700"
              />

              {/* Burbuja del mensaje */}
              <div className="group relative">
                <div className={`flex items-baseline gap-2 mb-1 ${isMe ? 'justify-end' : ''}`}>
                  <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300">
                    {authorName}
                  </span>
                  {msg.userRole === 'admin' && (
                    <span className="text-[9px] font-bold text-blue-700 dark:text-blue-400 bg-blue-100 dark:bg-blue-950 px-1.5 py-0.2 rounded">
                      Coordinador
                    </span>
                  )}
                  <span className="text-[9px] text-slate-400">
                    {new Date(msg.createdAt).toLocaleTimeString('es-ES', {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>

                <div
                  className={`rounded-3xl p-3.5 text-xs shadow-sm ${
                    isMe
                      ? 'bg-blue-900 text-white rounded-tr-none'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 rounded-tl-none'
                  }`}
                >
                  {/* Foto adjunta */}
                  {msg.imageUrl && (
                    <div className="mb-2 rounded-2xl overflow-hidden max-h-56 bg-black/10">
                      <img
                        src={msg.imageUrl}
                        alt="Adjunto"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}

                  {/* Texto */}
                  {msg.text && (
                    <p className="leading-relaxed whitespace-pre-wrap">{msg.text}</p>
                  )}
                </div>

                {/* Reacciones fijadas debajo de la burbuja */}
                {msg.reactions && Object.keys(msg.reactions).length > 0 && (
                  <div className={`flex flex-wrap gap-1 mt-1 ${isMe ? 'justify-end' : ''}`}>
                    {Object.entries(msg.reactions).map(([emoji, userIds]) => {
                      const hasReacted = userIds.includes(currentUser.id);
                      return (
                        <button
                          key={emoji}
                          onClick={() => addMessageReaction(msg.id, emoji)}
                          className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold border transition ${
                            hasReacted
                              ? 'bg-blue-50 dark:bg-blue-950 border-blue-300 text-blue-800 dark:text-blue-300'
                              : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                          }`}
                        >
                          <span>{emoji}</span>
                          <span className="text-[9px]">{userIds.length}</span>
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* Menú de acciones hover (Reaccionar, Fijar, Reportar) */}
                <div
                  className={`opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 mt-1 text-[11px] text-slate-400 ${
                    isMe ? 'justify-end' : ''
                  }`}
                >
                  <button
                    onClick={() =>
                      setActiveReactionMsgId(activeReactionMsgId === msg.id ? null : msg.id)
                    }
                    className="p-1 hover:text-slate-600 dark:hover:text-slate-200 rounded"
                    title="Reaccionar con emoji"
                  >
                    <Smile className="w-3.5 h-3.5" />
                  </button>

                  {isAdmin && (
                    <button
                      onClick={() => togglePinMessage(msg.id)}
                      className={`p-1 rounded ${
                        msg.isPinned ? 'text-amber-500 font-bold' : 'hover:text-slate-600'
                      }`}
                      title={msg.isPinned ? 'Desfijar mensaje' : 'Fijar como anuncio oficial'}
                    >
                      <Pin className="w-3.5 h-3.5" />
                    </button>
                  )}

                  {!isMe && (
                    <button
                      onClick={() => {
                        if (confirm('¿Deseas reportar este mensaje al coordinador para revisión?')) {
                          reportMessage(msg.id);
                          alert('Mensaje reportado. El coordinador lo revisará.');
                        }
                      }}
                      className="p-1 hover:text-red-500 rounded"
                      title="Reportar mensaje"
                    >
                      <AlertTriangle className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* Selector rápido de reacciones para este mensaje */}
                {activeReactionMsgId === msg.id && (
                  <div className="absolute z-20 mt-1 p-1 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xl flex gap-1 animate-in fade-in">
                    {EMOJI_LIST.slice(0, 6).map((emoji) => (
                      <button
                        key={emoji}
                        onClick={() => {
                          addMessageReaction(msg.id, emoji);
                          setActiveReactionMsgId(null);
                        }}
                        className="w-7 h-7 flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-700 rounded-xl text-sm"
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Vista previa de imagen seleccionada antes de enviar */}
      {selectedImage && (
        <div className="px-4 py-2 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-12 h-12 rounded-xl overflow-hidden border">
              <img src={selectedImage} alt="Preview" className="w-full h-full object-cover" />
            </div>
            <span className="text-xs text-slate-500">Foto lista para enviar (comprimida)</span>
          </div>
          <button
            onClick={() => setSelectedImage('')}
            className="p-1 rounded-full text-slate-400 hover:text-red-500"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Barra de entrada de texto */}
      <form
        onSubmit={handleSend}
        className="p-3 border-t border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center gap-2 relative"
      >
        {/* Selector de Emojis */}
        <div className="relative">
          <button
            type="button"
            onClick={() => setShowEmojiPicker(!showEmojiPicker)}
            className="w-9 h-9 rounded-2xl flex items-center justify-center text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <Smile className="w-5 h-5" />
          </button>

          {showEmojiPicker && (
            <div className="absolute bottom-12 left-0 p-2 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xl grid grid-cols-5 gap-1.5 z-30">
              {EMOJI_LIST.map((emoji) => (
                <button
                  type="button"
                  key={emoji}
                  onClick={() => {
                    setText((prev) => prev + emoji);
                    setShowEmojiPicker(false);
                  }}
                  className="w-8 h-8 flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-700 rounded-xl text-lg"
                >
                  {emoji}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Subir foto con compresión automática */}
        <label className="w-9 h-9 rounded-2xl flex items-center justify-center text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer">
          <Camera className="w-5 h-5" />
          <input
            type="file"
            accept="image/*"
            onChange={handleImagePick}
            className="hidden"
          />
        </label>

        {/* Campo de texto */}
        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={isCompressing ? 'Procesando foto...' : 'Escribe un mensaje fraternal...'}
          disabled={isCompressing}
          className="flex-1 px-4 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-blue-600"
        />

        {/* Botón de Enviar */}
        <button
          type="submit"
          disabled={!text.trim() && !selectedImage}
          className="w-10 h-10 rounded-2xl bg-blue-900 hover:bg-blue-800 disabled:opacity-40 text-white flex items-center justify-center shadow-md active:scale-95 transition shrink-0"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>

      {/* Modal: Reglas de Convivencia */}
      {showRulesModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 animate-in fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-blue-600" /> Reglas de Convivencia JMV
              </h3>
              <button onClick={() => setShowRulesModal(false)} className="text-slate-400">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="mt-4 space-y-3 text-xs text-slate-600 dark:text-slate-300">
              <p className="p-3 rounded-2xl bg-blue-50 dark:bg-blue-950/40 text-blue-900 dark:text-blue-300 font-semibold">
                "San Vicente nos enseñaba que el lenguaje cristiano debe ser siempre afable, paciente y caritativo."
              </p>
              <ul className="space-y-2 list-disc list-inside">
                <li><strong>Respeto mutuo:</strong> Tratar a cada compañero con cariño, sin burlas ni lenguaje ofensivo.</li>
                <li><strong>Horarios de descanso:</strong> Evitar enviar mensajes entre las 22:30 y las 07:00, salvo emergencias comunitarias.</li>
                <li><strong>Contenido edificante:</strong> Compartir información del grupo, cantos, oraciones y fraternidad. No enviar spam, cadenas ni contenido ajeno.</li>
                <li><strong>Privacidad de fotos:</strong> Las fotos compartidas aquí son exclusivamente para el grupo y no deben divulgarse sin autorización.</li>
                <li><strong>Reporte de mensajes:</strong> Si algún mensaje vulnera estas reglas, puedes reportarlo discretamente con el icono de alerta.</li>
              </ul>
            </div>

            <button
              onClick={() => setShowRulesModal(false)}
              className="mt-5 w-full py-2.5 rounded-2xl bg-blue-900 text-white font-bold text-xs"
            >
              Comprendido y Aceptado
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
