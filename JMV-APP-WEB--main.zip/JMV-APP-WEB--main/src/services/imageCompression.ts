/**
 * Utilidad de compresión de imágenes en el cliente (Browser Canvas).
 * Reduce dimensiones y comprime a JPEG con calidad configurable para
 * garantizar funcionamiento veloz incluso en conexiones móviles lentas.
 */

export interface CompressionOptions {
  maxWidth?: number;
  maxHeight?: number;
  quality?: number; // 0.1 a 1.0
  preserveTransparency?: boolean;
}

export async function compressImage(
  file: File,
  options: CompressionOptions = {}
): Promise<{ dataUrl: string; originalSize: number; compressedSize: number }> {
  const maxWidth = options.maxWidth || 1280;
  const maxHeight = options.maxHeight || 1280;
  const quality = options.quality || 0.75;
  const preserveTransparency = Boolean(options.preserveTransparency);

  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('No se pudo inicializar el contexto 2D del navegador.'));
          return;
        }

        const usePng =
          preserveTransparency &&
          (file.type === 'image/png' || file.type === 'image/webp' || file.type === 'image/svg+xml');

        if (!usePng) {
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, width, height);
        }

        ctx.drawImage(img, 0, 0, width, height);
        const mime = usePng ? 'image/png' : 'image/jpeg';
        const dataUrl = usePng ? canvas.toDataURL('image/png') : canvas.toDataURL('image/jpeg', quality);

        // Calcular tamaño aproximado en bytes
        const head = `data:${mime};base64,`;
        const compressedSize = Math.round(((dataUrl.length - head.length) * 3) / 4);

        resolve({
          dataUrl,
          originalSize: file.size,
          compressedSize,
        });
      };
      img.onerror = (err) => reject(err);
    };
    reader.onerror = (err) => reject(err);
  });
}

/**
 * Compresión optimizada específicamente para fotos de perfil / avatares.
 * Garantiza un tamaño compacto (< 25 KB en base64) manteniendo nitidez circular,
 * evitando que se pierda por límites de almacenamiento local o sincronización.
 */
export async function compressAvatarImage(file: File): Promise<string> {
  const attempts = [
    { maxWidth: 220, maxHeight: 220, quality: 0.78 },
    { maxWidth: 180, maxHeight: 180, quality: 0.62 },
    { maxWidth: 150, maxHeight: 150, quality: 0.48 },
  ];

  let lastDataUrl = '';
  for (const opts of attempts) {
    const res = await compressImage(file, opts);
    lastDataUrl = res.dataUrl;
    if (res.dataUrl.length <= 28000) {
      return res.dataUrl;
    }
  }
  return lastDataUrl;
}

