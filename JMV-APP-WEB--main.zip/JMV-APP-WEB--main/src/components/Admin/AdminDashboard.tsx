import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Users,
  DollarSign,
  Award,
  Bell,
  Key,
  Database,
  Calendar,
  Send,
  Save,
  Check,
  Sparkles,
  Settings,
  HelpCircle,
  Copy,
  Upload,
  Image as ImageIcon,
  Palette,
  Trash2,
  UserMinus,
  UserPlus,
  Search,
  AlertTriangle,
  CheckCircle2,
  X,
  Phone,
  Cake,
  RefreshCw,
  Lock,
  User,
  Mail,
  CreditCard,
  FileSpreadsheet,
  FileText,
  CheckCircle,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { UserRole, UserProfile } from '../../types';
import { compressImage, compressAvatarImage } from '../../services/imageCompression';
import { BannerCustomizeModal } from '../Home/BannerCustomizeModal';
import { getBannerPalette } from '../../data/bannerPalettes';
import marianMedalImg from '../../assets/images/jmv_marian_medal_1794117311829.jpg';
import heroYouthImg from '../../assets/images/jmv_hero_youth_1794117311900.jpg';

export const AdminDashboard: React.FC<{ onNavigateTab?: (tab: string) => void }> = ({ onNavigateTab }) => {
  const {
    users,
    feePayments,
    challenges,
    submissions,
    settings,
    updateSettings,
    reminders,
    addReminder,
    triggerPushNotification,
    attendanceSessions,
    setShowSupabaseGuide,
    supabaseConnected,
    treasurerUser,
    setTreasurerUser,
    deleteUser,
    cleanExampleUsers,
    updateUser,
    registerMember,
    approveMember,
    rejectMember,
    refreshMembers,
    bulkImportMembers,
    currentUser,
    isAdmin,
    passwordRequests,
    resolvePasswordRequest,
    restoreExampleAdmin,
    activeGroupKey,
    availableGroups,
    switchGroup,
    createGroupWorkspace,
  } = useApp();

  const [groupNameDraft, setGroupNameDraft] = useState(settings.groupName);
  const [parishNameDraft, setParishNameDraft] = useState(settings.parishName || 'Parroquia San Vicente de Paúl');
  const [logoDraft, setLogoDraft] = useState(settings.logoUrl || marianMedalImg);
  const [invitationCodeDraft, setInvitationCodeDraft] = useState(settings.invitationCode);
  const [hoodieGoalDraft, setHoodieGoalDraft] = useState(settings.hoodieGoalAmount);
  const [emailjsServiceDraft, setEmailjsServiceDraft] = useState(settings.emailjsServiceId || '');
  const [emailjsTemplateDraft, setEmailjsTemplateDraft] = useState(settings.emailjsTemplateId || '');
  const [emailjsKeyDraft, setEmailjsKeyDraft] = useState(settings.emailjsPublicKey || '');
  const [showEmailConfig, setShowEmailConfig] = useState(false);
  const [savedSettingsSuccess, setSavedSettingsSuccess] = useState(false);
  const [logoAppliedSuccess, setLogoAppliedSuccess] = useState(false);
  const [isCompressingLogo, setIsCompressingLogo] = useState(false);
  const [showBannerCustomizeModal, setShowBannerCustomizeModal] = useState(false);

  useEffect(() => {
    setGroupNameDraft(settings.groupName);
    setParishNameDraft(settings.parishName || 'Parroquia San Vicente de Paúl');
    setLogoDraft(settings.logoUrl || marianMedalImg);
    setInvitationCodeDraft(settings.invitationCode);
    setHoodieGoalDraft(settings.hoodieGoalAmount);
    setEmailjsServiceDraft(settings.emailjsServiceId || '');
    setEmailjsTemplateDraft(settings.emailjsTemplateId || '');
    setEmailjsKeyDraft(settings.emailjsPublicKey || '');
  }, [
    settings.groupName,
    settings.parishName,
    settings.logoUrl,
    settings.invitationCode,
    settings.hoodieGoalAmount,
    settings.emailjsServiceId,
    settings.emailjsTemplateId,
    settings.emailjsPublicKey,
  ]);

  const [isRefreshingRequests, setIsRefreshingRequests] = useState(false);

  useEffect(() => {
    void refreshMembers();
  }, []);

  const handleRefreshRequests = async () => {
    setIsRefreshingRequests(true);
    try {
      await refreshMembers();
    } finally {
      setIsRefreshingRequests(false);
    }
  };

  // Nuevo recordatorio
  const [reminderTitle, setReminderTitle] = useState('¡Te esperamos este sábado en JMV!');
  const [reminderMessage, setReminderMessage] = useState(
    'Hola vicentino/a, este sábado tenemos reunión a las 17:00 en el salón parroquial. ¡No faltes, tu presencia alegra a la comunidad!'
  );
  const [reminderDate, setReminderDate] = useState('2026-11-14T12:00');
  const [copiedCode, setCopiedCode] = useState(false);

  // Estados para gestión y eliminación de integrantes
  const [memberSearch, setMemberSearch] = useState('');
  const [userToDelete, setUserToDelete] = useState<UserProfile | null>(null);
  const [showCleanExamplesModal, setShowCleanExamplesModal] = useState(false);
  const [feedbackMessage, setFeedbackMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Modal para agregar nuevo integrante individual
  const [showNewMemberModal, setShowNewMemberModal] = useState(false);
  const [newMemberName, setNewMemberName] = useState('');
  const [newMemberEmail, setNewMemberEmail] = useState('');
  const [newMemberCedula, setNewMemberCedula] = useState('');
  const [newMemberPassword, setNewMemberPassword] = useState('');
  const [newMemberBirthday, setNewMemberBirthday] = useState('2005-06-15');
  const [newMemberPhone, setNewMemberPhone] = useState('');
  const [newMemberRole, setNewMemberRole] = useState<UserRole>('integrante');
  const [newMemberAvatar, setNewMemberAvatar] = useState('');
  const [newMemberError, setNewMemberError] = useState('');
  const [isCompressingNewAvatar, setIsCompressingNewAvatar] = useState(false);

  // Modal para editar credenciales y datos de un integrante existente
  const [editingMember, setEditingMember] = useState<UserProfile | null>(null);
  const [editMemberName, setEditMemberName] = useState('');
  const [editMemberEmail, setEditMemberEmail] = useState('');
  const [editMemberCedula, setEditMemberCedula] = useState('');
  const [editMemberPassword, setEditMemberPassword] = useState('');
  const [editMemberAvatar, setEditMemberAvatar] = useState('');
  const [isCompressingEditAvatar, setIsCompressingEditAvatar] = useState(false);
  const [editMemberError, setEditMemberError] = useState('');

  // Modal y lógica de Subida Masiva (Lote / CSV)
  const [showBulkModal, setShowBulkModal] = useState(false);
  const [bulkText, setBulkText] = useState('');
  const [bulkFeedback, setBulkFeedback] = useState<{ success: boolean; count: number; errors: string[] } | null>(null);

  // Modal para crear otro grupo independiente
  const [showNewGroupModal, setShowNewGroupModal] = useState(false);
  const [newGroupNameDraft, setNewGroupNameDraft] = useState('');
  const [newGroupParishDraft, setNewGroupParishDraft] = useState('');
  const [newGroupCodeDraft, setNewGroupCodeDraft] = useState('');
  const [newGroupCoordName, setNewGroupCoordName] = useState('');
  const [newGroupCoordEmail, setNewGroupCoordEmail] = useState('');
  const [newGroupCoordCedula, setNewGroupCoordCedula] = useState('');
  const [newGroupCoordPass, setNewGroupCoordPass] = useState('');
  const [newGroupError, setNewGroupError] = useState('');
  const [isCreatingNewGroup, setIsCreatingNewGroup] = useState(false);

  const handleCreateAnotherGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    setNewGroupError('');
    setIsCreatingNewGroup(true);
    try {
      const res = await createGroupWorkspace({
        groupName: newGroupNameDraft,
        parishName: newGroupParishDraft,
        invitationCode: newGroupCodeDraft.replace(/[\s\u200B-\u200D\uFEFF]/g, '').toUpperCase(),
        coordinatorName: newGroupCoordName,
        coordinatorEmail: newGroupCoordEmail,
        coordinatorCedula: newGroupCoordCedula,
        coordinatorPassword: newGroupCoordPass || newGroupCoordCedula,
      });
      if (!res.success) {
        setNewGroupError(res.error || 'No se pudo crear el nuevo grupo.');
        return;
      }
      setShowNewGroupModal(false);
      setNewGroupNameDraft('');
      setNewGroupParishDraft('');
      setNewGroupCodeDraft('');
      setNewGroupCoordName('');
      setNewGroupCoordEmail('');
      setNewGroupCoordCedula('');
      setNewGroupCoordPass('');
      setFeedbackMessage({
        type: 'success',
        text: `¡Grupo "${newGroupNameDraft.trim()}" creado con espacio e integrantes independientes!`,
      });
      setTimeout(() => setFeedbackMessage(null), 5000);
    } finally {
      setIsCreatingNewGroup(false);
    }
  };

  const handleDeleteMember = (userId: string) => {
    const res = deleteUser(userId);
    if (!res.success) {
      setFeedbackMessage({ type: 'error', text: res.error || 'No se pudo eliminar el integrante.' });
    } else {
      setFeedbackMessage({ type: 'success', text: 'Integrante eliminado exitosamente del grupo.' });
    }
    setUserToDelete(null);
    setTimeout(() => setFeedbackMessage(null), 3000);
  };

  const handleCleanExamples = () => {
    const res = cleanExampleUsers();
    if (!res.success) {
      setFeedbackMessage({ type: 'error', text: res.error || 'No se pudieron limpiar los integrantes de ejemplo.' });
    } else {
      setFeedbackMessage({ type: 'success', text: `¡Se eliminaron ${res.removedCount} integrantes de ejemplo! Ahora el grupo está listo para tus miembros reales.` });
    }
    setShowCleanExamplesModal(false);
    setTimeout(() => setFeedbackMessage(null), 4000);
  };

  const handleCreateNewMember = async (e: React.FormEvent) => {
    e.preventDefault();
    setNewMemberError('');
    if (!newMemberName.trim()) {
      setNewMemberError('Ingresa el nombre completo del integrante.');
      return;
    }

    const email = (newMemberEmail.trim() || `${newMemberName.toLowerCase().replace(/[\s\.]+/g, '')}@gmail.com`).toLowerCase();
    const cedula = newMemberCedula.trim() || `172${Date.now().toString().slice(-7)}`;
    const password = newMemberPassword.trim() || cedula;

    const res = await registerMember({
      name: newMemberName.trim(),
      email,
      cedula,
      password,
      birthday: newMemberBirthday,
      phone: newMemberPhone.trim() || undefined,
      invitationCode: settings.invitationCode,
      avatarUrl: newMemberAvatar || undefined,
      imageConsentAccepted: true,
      isMinor: false,
      role: newMemberRole,
      autoApprove: true,
    });

    if (res.success) {
      setFeedbackMessage({
        type: 'success',
        text: `¡Participante ${newMemberName.trim()} registrado y activado! Acceso: ${email} · Clave/CI: ${password}`,
      });
      setShowNewMemberModal(false);
      setNewMemberName('');
      setNewMemberEmail('');
      setNewMemberCedula('');
      setNewMemberPassword('');
      setNewMemberPhone('');
      setNewMemberAvatar('');
      setNewMemberError('');
      setTimeout(() => setFeedbackMessage(null), 5000);
    } else {
      setNewMemberError(res.error || 'Error al agregar integrante');
    }
  };

  const openEditMemberModal = (member: UserProfile) => {
    setEditingMember(member);
    setEditMemberName(member.name);
    setEditMemberEmail(member.email || '');
    setEditMemberCedula(member.cedula || '');
    setEditMemberPassword(member.password || member.cedula || '');
    setEditMemberAvatar(member.avatarUrl || '');
    setEditMemberError('');
  };

  const handleEditMemberAvatarFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setEditMemberError('');
    try {
      setIsCompressingEditAvatar(true);
      const dataUrl = await compressAvatarImage(file);
      setEditMemberAvatar(dataUrl);
    } catch (err) {
      console.error('Error al comprimir foto de integrante:', err);
      setEditMemberError('No pudimos procesar esta foto. Intenta con una imagen JPG o PNG.');
    } finally {
      setIsCompressingEditAvatar(false);
      e.target.value = '';
    }
  };

  const handleSaveEditMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingMember) return;
    setEditMemberError('');

    const cleanName = editMemberName.trim();
    const cleanEmail = editMemberEmail.trim().toLowerCase();
    const cleanCedula = editMemberCedula.trim();
    const cleanPassword = editMemberPassword.trim() || cleanCedula;

    if (!cleanName || !cleanEmail || !cleanCedula) {
      setEditMemberError('Nombre, correo electrónico y cédula son obligatorios.');
      return;
    }
    if (users.some((u) => u.id !== editingMember.id && u.email.trim().toLowerCase() === cleanEmail)) {
      setEditMemberError('Ya existe otro integrante con este correo electrónico.');
      return;
    }
    if (users.some((u) => u.id !== editingMember.id && u.cedula.trim() === cleanCedula)) {
      setEditMemberError('Ya existe otro integrante con este número de cédula.');
      return;
    }

    updateUser(editingMember.id, {
      name: cleanName,
      email: cleanEmail,
      cedula: cleanCedula,
      password: cleanPassword,
      avatarUrl: editMemberAvatar || editingMember.avatarUrl,
    });
    setFeedbackMessage({
      type: 'success',
      text: `¡Perfil y acceso actualizados para ${cleanName}! Correo: ${cleanEmail} · Clave: ${cleanPassword}`,
    });
    setEditingMember(null);
    setTimeout(() => setFeedbackMessage(null), 4500);
  };

  const handleProcessBulk = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bulkText.trim()) return;

    const lines = bulkText.split('\n').map((l) => l.trim()).filter((l) => l.length > 0);
    const parsedList: Array<{ name: string; email: string; cedula: string; phone?: string; birthday?: string; role?: UserRole }> = [];

    lines.forEach((line) => {
      // Ignorar cabecera si el usuario la incluyó
      if (line.toLowerCase().startsWith('nombre') || line.toLowerCase().startsWith('name')) return;
      const parts = line.split(/[,;\t]/).map((p) => p.trim());
      if (parts.length >= 3) {
        parsedList.push({
          name: parts[0],
          email: parts[1],
          cedula: parts[2],
          phone: parts[3] || undefined,
          birthday: parts[4] || '2005-01-01',
          role: 'integrante',
        });
      }
    });

    if (parsedList.length === 0) {
      setBulkFeedback({
        success: false,
        count: 0,
        errors: ['No se detectaron filas válidas. Usa el formato: Nombre, Correo, Cédula, Teléfono, Fecha'],
      });
      return;
    }

    const res = bulkImportMembers(parsedList);
    setBulkFeedback(res);
    if (res.success) {
      setFeedbackMessage({
        type: 'success',
        text: `¡Se importaron ${res.count} participantes exitosamente con acceso activo!`,
      });
      setTimeout(() => {
        setShowBulkModal(false);
        setBulkText('');
        setBulkFeedback(null);
      }, 2500);
    }
  };

  const handleApproveMember = (userId: string, userName: string) => {
    approveMember(userId);
    setFeedbackMessage({
      type: 'success',
      text: `¡Nuevo integrante ${userName} aceptado y autorizado! Ya puede ingresar con su correo y cédula/contraseña.`,
    });
    setTimeout(() => setFeedbackMessage(null), 4000);
  };

  const handleRejectMember = (userId: string, userName: string) => {
    rejectMember(userId);
    setFeedbackMessage({
      type: 'success',
      text: `Solicitud de ${userName} rechazada y eliminada.`,
    });
    setTimeout(() => setFeedbackMessage(null), 3500);
  };

  const handleRoleChange = (userId: string, newRole: UserRole) => {
    if (newRole === 'tesorero') {
      setTreasurerUser(userId);
    } else {
      updateUser(userId, { role: newRole, isTreasurer: false });
    }
    setFeedbackMessage({ type: 'success', text: 'Rol del integrante actualizado con éxito.' });
    setTimeout(() => setFeedbackMessage(null), 2500);
  };

  const handleNewAvatarFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setNewMemberError('');
    try {
      setIsCompressingNewAvatar(true);
      const dataUrl = await compressAvatarImage(file);
      setNewMemberAvatar(dataUrl);
    } catch (err) {
      console.error(err);
      setNewMemberError('No se pudo procesar la foto seleccionada. Usa una imagen JPG o PNG.');
    } finally {
      setIsCompressingNewAvatar(false);
      e.target.value = '';
    }
  };

  // Cálculos resumen
  const totalCollected = feePayments.filter((p) => p.status === 'pagado').length * 1.0;
  const approvedSubmissions = submissions.filter((s) => s.status === 'approved').length;
  const totalSubmissions = submissions.length;

  const totalSessions = attendanceSessions.length;
  let totalPresences = 0;
  let totalPossible = 0;
  attendanceSessions.forEach((s) => {
    totalPresences += s.records.filter((r) => r.status === 'presente').length;
    totalPossible += s.records.length;
  });
  const avgAttendanceRate = totalPossible > 0 ? Math.round((totalPresences / totalPossible) * 100) : 85;

  const handleLogoFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsCompressingLogo(true);
      const res = await compressImage(file, {
        maxWidth: 360,
        maxHeight: 360,
        quality: 0.88,
        preserveTransparency: true,
      });
      setLogoDraft(res.dataUrl);
      updateSettings({
        groupName: groupNameDraft.trim() || settings.groupName,
        parishName: parishNameDraft.trim() || settings.parishName,
        invitationCode: invitationCodeDraft.replace(/[\s\u200B-\u200D\uFEFF]/g, '').toUpperCase() || settings.invitationCode,
        logoUrl: res.dataUrl,
      });
      setLogoAppliedSuccess(true);
      setTimeout(() => setLogoAppliedSuccess(false), 3000);
    } catch (err) {
      console.error(err);
    } finally {
      setIsCompressingLogo(false);
      e.target.value = '';
    }
  };

  const handleSelectPresetLogo = (presetUrl: string) => {
    setLogoDraft(presetUrl);
    updateSettings({
      groupName: groupNameDraft.trim() || settings.groupName,
      parishName: parishNameDraft.trim() || settings.parishName,
      invitationCode: invitationCodeDraft.replace(/[\s\u200B-\u200D\uFEFF]/g, '').toUpperCase() || settings.invitationCode,
      logoUrl: presetUrl,
    });
    setLogoAppliedSuccess(true);
    setTimeout(() => setLogoAppliedSuccess(false), 3000);
  };

  const handleSaveInvitationCodeOnly = () => {
    const cleanCode = invitationCodeDraft.replace(/[\s\u200B-\u200D\uFEFF]/g, '').toUpperCase();
    if (!cleanCode) return;
    setInvitationCodeDraft(cleanCode);
    updateSettings({ invitationCode: cleanCode });
    setFeedbackMessage({
      type: 'success',
      text: `¡Código privado actualizado a "${cleanCode}"! Ya puedes copiarlo y enviarlo a los nuevos participantes.`,
    });
    setTimeout(() => setFeedbackMessage(null), 4000);
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanCode = invitationCodeDraft.replace(/[\s\u200B-\u200D\uFEFF]/g, '').toUpperCase() || 'JMV2026';
    setInvitationCodeDraft(cleanCode);
    updateSettings({
      groupName: groupNameDraft.trim(),
      parishName: parishNameDraft.trim(),
      logoUrl: logoDraft,
      invitationCode: cleanCode,
      hoodieGoalAmount: Number(hoodieGoalDraft),
      emailjsServiceId: emailjsServiceDraft.trim(),
      emailjsTemplateId: emailjsTemplateDraft.trim(),
      emailjsPublicKey: emailjsKeyDraft.trim(),
    });
    setSavedSettingsSuccess(true);
    setFeedbackMessage({
      type: 'success',
      text: `¡Identidad actualizada! "${groupNameDraft.trim()}", "${parishNameDraft.trim()}" y el logo ya se muestran en toda la aplicación.`,
    });
    setTimeout(() => setSavedSettingsSuccess(false), 3000);
    setTimeout(() => setFeedbackMessage(null), 4000);
  };

  const handleCreateReminder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reminderTitle.trim() || !reminderMessage.trim()) return;

    addReminder(reminderTitle.trim(), reminderMessage.trim(), reminderDate);
    triggerPushNotification(reminderTitle, reminderMessage);
    alert('¡Recordatorio programado y notificación de prueba enviada!');
  };

  const copyInvitationCode = () => {
    navigator.clipboard.writeText(settings.invitationCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const filteredUsers = users.filter((u) => {
    const q = memberSearch.toLowerCase().trim();
    if (!q) return true;
    return (
      u.name.toLowerCase().includes(q) ||
      (u.email && u.email.toLowerCase().includes(q)) ||
      (u.cedula && u.cedula.includes(q)) ||
      (u.phone && u.phone.includes(q))
    );
  });

  // Privacidad: Los datos generales solo los ve el panel de administración
  if (!isAdmin) {
    return (
      <div className="max-w-md mx-auto my-12 p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl text-center space-y-4 animate-in fade-in">
        <div className="w-16 h-16 mx-auto rounded-3xl bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-900/50 flex items-center justify-center text-amber-600 dark:text-amber-400">
          <Lock className="w-8 h-8" />
        </div>

        <div className="space-y-1">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">
            Datos Generales y Panel de Coordinación
          </h2>
          <span className="inline-block text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300">
            Acceso Exclusivo para Coordinador / Asesor
          </span>
        </div>

        <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
          Por privacidad y seguridad de los integrantes (teléfonos de apoderados, datos de tutores y administración global de la parroquia), los datos generales solo están disponibles para el equipo de Coordinación.
        </p>

        <div className="pt-2 flex flex-col gap-2">
          {onNavigateTab && (
            <button
              onClick={() => onNavigateTab('perfil')}
              className="w-full py-2.5 px-4 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow transition flex items-center justify-center gap-2"
            >
              <User className="w-4 h-4" />
              <span>Ir a Mi Panel y Ficha Individual</span>
            </button>
          )}

          <p className="text-[10px] text-slate-400">
            Si eres el coordinador/a del grupo, inicia sesión con tu correo y cédula desde el menú de cuenta.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-20 animate-in fade-in">
      {/* Encabezado */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-blue-900 text-amber-400">
              <ShieldCheck className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
              Panel del Coordinador / Asesor JMV
            </h1>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Resumen general del grupo, configuración del código de ingreso y recordatorios.
          </p>
        </div>

        <button
          onClick={() => setShowSupabaseGuide(true)}
          className="flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow transition active:scale-95 shrink-0"
        >
          <Database className="w-4 h-4" />
          <span>Base de Datos y Netlify</span>
        </button>
      </div>

      {/* ESPACIOS INDEPENDIENTES POR GRUPO */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] uppercase tracking-wider font-extrabold px-2.5 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300">
                Grupo Activo
              </span>
              <h2 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white">
                {settings.groupName}
              </h2>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
              Los integrantes, cédulas, finanzas, fotos y datos personales de este grupo están aislados de cualquier otro grupo registrado.
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              setNewGroupError('');
              setShowNewGroupModal(true);
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow-sm transition active:scale-95 shrink-0"
          >
            <UserPlus className="w-3.5 h-3.5 text-amber-300" />
            <span>+ Crear Otro Grupo Independiente</span>
          </button>
        </div>

        {availableGroups.length > 0 && (
          <div className="flex items-center gap-2 flex-wrap pt-2 border-t border-slate-100 dark:border-slate-800">
            <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
              Grupos registrados ({availableGroups.length}):
            </span>
            {availableGroups.map((g) => {
              const isCurrent = g.groupKey === activeGroupKey;
              return (
                <button
                  key={g.groupKey}
                  type="button"
                  onClick={() => {
                    if (!isCurrent) void switchGroup(g.groupKey);
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                    isCurrent
                      ? 'bg-blue-900 text-white shadow-sm'
                      : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200'
                  }`}
                >
                  <span>{g.groupName}</span>
                  {isCurrent && <Check className="w-3 h-3 text-amber-300" />}
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* PANEL PRINCIPAL: SOLICITUDES DE NUEVOS INTEGRANTES (SIEMPRE VISIBLE) */}
      {(() => {
        const pendingApplicants = users.filter((u) => u.status === 'pendiente_aprobacion');
        return (
          <div
            id="solicitudes-ingreso"
            className={`p-5 sm:p-6 rounded-3xl border-2 shadow-sm space-y-4 scroll-mt-20 ${
              pendingApplicants.length > 0
                ? 'bg-emerald-50/95 dark:bg-emerald-950/35 border-emerald-400 dark:border-emerald-700'
                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
            }`}
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span
                    className={`p-1.5 rounded-xl ${
                      pendingApplicants.length > 0
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    <UserPlus className="w-4 h-4" />
                  </span>
                  <h2 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white">
                    Panel de Solicitudes de Nuevos Integrantes
                  </h2>
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-xs font-extrabold ${
                      pendingApplicants.length > 0
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    {pendingApplicants.length}{' '}
                    {pendingApplicants.length === 1 ? 'pendiente' : 'pendientes'}
                  </span>
                </div>
                <p className="mt-1 text-xs text-slate-600 dark:text-slate-400">
                  Los jóvenes que se registren esperan aquí tu autorización. Solo podrán ingresar cuando presiones{' '}
                  <strong className="text-emerald-700 dark:text-emerald-300">&laquo;Aceptar nuevo integrante&raquo;</strong>.
                </p>
              </div>

              <button
                type="button"
                onClick={handleRefreshRequests}
                disabled={isRefreshingRequests}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs shadow-sm transition active:scale-95 shrink-0 disabled:opacity-60"
              >
                <RefreshCw className={`w-3.5 h-3.5 text-blue-600 ${isRefreshingRequests ? 'animate-spin' : ''}`} />
                <span>{isRefreshingRequests ? 'Actualizando...' : 'Actualizar Solicitudes'}</span>
              </button>
            </div>

            {pendingApplicants.length > 0 ? (
              <div className="space-y-2.5">
                {pendingApplicants.map((pendingUser) => (
                  <div
                    key={pendingUser.id}
                    className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-emerald-200 dark:border-emerald-800/70 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-sm"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <img
                        src={pendingUser.avatarUrl}
                        alt={pendingUser.name}
                        className="w-11 h-11 rounded-full object-cover ring-2 ring-amber-400 shrink-0"
                        referrerPolicy="no-referrer"
                      />
                      <div className="min-w-0 text-xs">
                        <p className="font-extrabold text-slate-900 dark:text-white truncate">
                          {pendingUser.name}
                        </p>
                        <div className="flex items-center gap-2 text-[11px] text-slate-600 dark:text-slate-300 flex-wrap mt-0.5">
                          <span className="font-mono truncate">{pendingUser.email}</span>
                          <span>•</span>
                          <span className="font-mono font-bold">CI: {pendingUser.cedula}</span>
                        </div>
                        <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5 flex-wrap">
                          {pendingUser.phone && <span>WhatsApp: {pendingUser.phone}</span>}
                          {pendingUser.birthday && <span>· Nac: {pendingUser.birthday}</span>}
                          {pendingUser.isMinor && pendingUser.tutorName && (
                            <span className="text-amber-600 font-semibold">
                              · Menor (Tutor: {pendingUser.tutorName})
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleRejectMember(pendingUser.id, pendingUser.name)}
                        className="px-3 py-2 rounded-xl border border-rose-200 dark:border-rose-900/60 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 font-bold text-xs transition"
                      >
                        Rechazar
                      </button>
                      <button
                        type="button"
                        onClick={() => handleApproveMember(pendingUser.id, pendingUser.name)}
                        className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs shadow-md transition active:scale-95 flex items-center gap-1.5"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Aceptar nuevo integrante</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-dashed border-slate-200 dark:border-slate-700 text-xs text-slate-500 dark:text-slate-400 flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
                <span>
                  Al día: no hay solicitudes pendientes en este momento. Cuando alguien se registre con el código del grupo, su solicitud aparecerá aquí automáticamente.
                </span>
              </div>
            )}
          </div>
        );
      })()}

      {/* Tarjetas KPI de Resumen */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <span className="text-[10px] uppercase font-bold text-slate-400 flex items-center gap-1">
            <Users className="w-3.5 h-3.5 text-blue-600" /> Integrantes
          </span>
          <div className="text-2xl font-black text-slate-900 dark:text-white tabular-nums mt-1">
            {users.length}
          </div>
          <span className="text-[10px] text-slate-500">Miembros activos</span>
        </div>

        <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <span className="text-[10px] uppercase font-bold text-slate-400 flex items-center gap-1">
            <DollarSign className="w-3.5 h-3.5 text-emerald-600" /> Recaudación Cuotas
          </span>
          <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400 tabular-nums mt-1">
            ${totalCollected}.00
          </div>
          <span className="text-[10px] text-slate-500">Meta: ${settings.hoodieGoalAmount}</span>
        </div>

        <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <span className="text-[10px] uppercase font-bold text-slate-400 flex items-center gap-1">
            <Award className="w-3.5 h-3.5 text-amber-500" /> Retos Cumplidos
          </span>
          <div className="text-2xl font-black text-amber-600 dark:text-amber-400 tabular-nums mt-1">
            {approvedSubmissions}
          </div>
          <span className="text-[10px] text-slate-500">de {totalSubmissions} entregas</span>
        </div>

        <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <span className="text-[10px] uppercase font-bold text-slate-400 flex items-center gap-1">
            <Calendar className="w-3.5 h-3.5 text-purple-600" /> Asistencia Promedio
          </span>
          <div className="text-2xl font-black text-blue-900 dark:text-blue-400 tabular-nums mt-1">
            {avgAttendanceRate}%
          </div>
          <span className="text-[10px] text-slate-500">en {totalSessions} reuniones</span>
        </div>
      </div>

      {/* Mensaje de retroalimentación dinámico */}
      {feedbackMessage && (
        <div
          className={`p-4 rounded-2xl flex items-center justify-between gap-3 text-xs font-semibold animate-in fade-in shadow-sm ${
            feedbackMessage.type === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
              : 'bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-rose-900 dark:text-rose-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {feedbackMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
            )}
            <span>{feedbackMessage.text}</span>
          </div>
          <button
            onClick={() => setFeedbackMessage(null)}
            className="p-1 rounded-lg hover:bg-black/5 dark:hover:bg-white/10 transition"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* SECCIÓN: GESTIÓN Y ELIMINACIÓN DE INTEGRANTES */}
      <div
        id="integrantes"
        className="p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-5 scroll-mt-20"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-xl bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300">
                <Users className="w-4 h-4" />
              </span>
              <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                Gestión de Integrantes del Grupo ({users.length} miembros)
              </h2>
            </div>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Crea los integrantes reales de tu parroquia y elimina los perfiles de ejemplo con un solo clic.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0 flex-wrap">
            <button
              onClick={() => setShowCleanExamplesModal(true)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/60 dark:hover:bg-amber-900/60 text-amber-900 dark:text-amber-300 font-bold text-xs border border-amber-200 dark:border-amber-800 transition"
              title="Eliminar de una vez los perfiles de ejemplo"
            >
              <Trash2 className="w-3.5 h-3.5 text-amber-600" />
              <span>Limpiar Ejemplos</span>
            </button>

            <button
              onClick={() => {
                setShowBulkModal(true);
                setBulkFeedback(null);
              }}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow transition active:scale-95"
              title="Subida masiva de participantes con correo y cédula"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>📥 Subida Masiva CSV</span>
            </button>

            <button
              onClick={() => {
                const admin = restoreExampleAdmin();
                setFeedbackMessage({
                  type: 'success',
                  text: `Admin de ejemplo activado (${admin.email} · clave: admin). Puedes editarlo o eliminarlo cuando tengas otro Coordinador.`,
                });
                setTimeout(() => setFeedbackMessage(null), 5000);
              }}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs border border-slate-200 dark:border-slate-700 transition"
              title="Activar o restaurar cuenta Admin de ejemplo (solo visible para Admin)"
            >
              <RefreshCw className="w-3.5 h-3.5 text-blue-600" />
              <span>Activar Admin Ejemplo</span>
            </button>

            <button
              onClick={() => setShowNewMemberModal(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow transition active:scale-95"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>+ Nuevo Participante</span>
            </button>
          </div>
        </div>

        {/* (Las solicitudes de nuevos integrantes ahora se muestran en el panel superior #solicitudes-ingreso) */}

        {/* Solicitudes pendientes de recordar contraseña */}
        {passwordRequests.some((r) => r.status === 'pending') && (
          <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 space-y-2.5">
            <div className="flex items-center gap-2 text-xs font-bold text-amber-900 dark:text-amber-200">
              <Key className="w-4 h-4 text-amber-600 shrink-0" />
              <span>Solicitudes pendientes de recordatorio de contraseña</span>
            </div>
            <div className="space-y-2">
              {passwordRequests
                .filter((r) => r.status === 'pending')
                .map((req) => {
                  const targetUser = users.find((u) => u.id === req.userId);
                  const currentPass = targetUser ? targetUser.password || targetUser.cedula : '';
                  const mailSubject = encodeURIComponent(`Recordatorio de acceso · ${settings.groupName}`);
                  const mailBody = encodeURIComponent(
                    `Hola ${req.userName},\n\nTus datos de acceso a ${settings.groupName} son:\nCorreo: ${req.userEmail}\nCédula: ${targetUser?.cedula || ''}\nContraseña actual: ${currentPass}\n\nUn saludo fraterno.`
                  );
                  return (
                    <div
                      key={req.id}
                      className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-amber-200/80 dark:border-amber-800/60 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
                    >
                      <div className="min-w-0">
                        <p className="font-bold text-slate-900 dark:text-white truncate">{req.userName}</p>
                        <p className="text-[11px] text-slate-500 font-mono truncate">{req.userEmail}</p>
                      </div>
                      <div className="flex items-center gap-1.5 flex-wrap shrink-0">
                        {targetUser && (
                          <>
                            <a
                              href={`mailto:${req.userEmail}?subject=${mailSubject}&body=${mailBody}`}
                              onClick={() => resolvePasswordRequest(req.id)}
                              className="px-2.5 py-1.5 rounded-lg bg-blue-900 hover:bg-blue-800 text-white font-bold text-[11px] flex items-center gap-1 transition"
                            >
                              <Mail className="w-3 h-3" />
                              <span>Enviar al correo</span>
                            </a>
                            <button
                              type="button"
                              onClick={() => openEditMemberModal(targetUser)}
                              className="px-2.5 py-1.5 rounded-lg bg-amber-100 hover:bg-amber-200 dark:bg-amber-900/50 text-amber-900 dark:text-amber-200 font-bold text-[11px] flex items-center gap-1 transition"
                            >
                              <Key className="w-3 h-3" />
                              <span>Ver/Editar clave</span>
                            </button>
                          </>
                        )}
                        <button
                          type="button"
                          onClick={() => resolvePasswordRequest(req.id)}
                          className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-semibold text-[11px] hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                        >
                          Atendida
                        </button>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        )}

        {/* Barra de búsqueda de integrantes por nombre, correo o cédula */}
        <div className="flex items-center justify-between gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={memberSearch}
              onChange={(e) => setMemberSearch(e.target.value)}
              placeholder="Buscar por nombre, correo o cédula..."
              className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 text-slate-900 dark:text-white text-xs"
            />
          </div>
          <span className="text-[11px] text-slate-400">
            Mostrando {filteredUsers.length} de {users.length}
          </span>
        </div>

        {/* Lista de integrantes responsiva */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {filteredUsers.map((u) => {
            const isSelf = u.id === currentUser.id;
            const isTreasurerActive = u.role === 'tesorero' || u.isTreasurer;
            const isPending = u.status === 'pendiente_aprobacion';

            return (
              <div
                key={u.id}
                className={`p-3.5 rounded-2xl border transition ${
                  isPending
                    ? 'bg-amber-50/60 dark:bg-amber-950/20 border-amber-300 dark:border-amber-800'
                    : 'bg-slate-50/80 dark:bg-slate-800/50 border-slate-200/80 dark:border-slate-800 hover:border-blue-300 dark:hover:border-blue-700'
                } flex items-center justify-between gap-3`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="relative shrink-0">
                    <img
                      src={u.avatarUrl}
                      alt={u.name}
                      className="w-11 h-11 rounded-full object-cover ring-2 ring-amber-400/60 shadow-sm"
                      referrerPolicy="no-referrer"
                    />
                    {u.role === 'admin' ? (
                      <span
                        className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-blue-900 text-white flex items-center justify-center text-[9px] shadow"
                        title="Coordinador"
                      >
                        🛡️
                      </span>
                    ) : isTreasurerActive ? (
                      <span
                        className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[9px] shadow"
                        title="Tesorero"
                      >
                        💰
                      </span>
                    ) : null}
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <p className="font-bold text-xs text-slate-900 dark:text-white truncate">
                        {u.name}
                      </p>
                      {isSelf && (
                        <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300">
                          Tú
                        </span>
                      )}
                      {isPending ? (
                        <span className="text-[9px] font-extrabold px-1.5 py-0.2 rounded-full bg-amber-100 dark:bg-amber-900 text-amber-800 dark:text-amber-200 border border-amber-300 dark:border-amber-700">
                          ⏳ Pendiente
                        </span>
                      ) : (
                        <span className="text-[9px] font-extrabold px-1.5 py-0.2 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                          ✓ Activo
                        </span>
                      )}
                    </div>

                    {/* Correo y Cédula */}
                    <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-600 dark:text-slate-300 flex-wrap">
                      <span className="flex items-center gap-1 font-mono text-[10px] text-slate-500">
                        <Mail className="w-3 h-3 text-blue-600 shrink-0" />
                        <span className="truncate max-w-[140px]">{u.email}</span>
                      </span>
                      <span>•</span>
                      <span className="flex items-center gap-1 font-mono text-[10px] font-bold text-slate-800 dark:text-slate-200">
                        <CreditCard className="w-3 h-3 text-amber-500 shrink-0" />
                        CI: {u.cedula}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 mt-0.5 text-[11px] text-slate-500 dark:text-slate-400 flex-wrap">
                      {u.phone ? (
                        <span className="flex items-center gap-1">
                          <Phone className="w-3 h-3 text-slate-400" />
                          {u.phone}
                        </span>
                      ) : (
                        <span className="text-slate-400 italic">Sin teléfono</span>
                      )}
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <Cake className="w-3 h-3 text-rose-400" />
                        {u.birthday || 'Sin fecha'}
                      </span>
                    </div>

                    {/* Selector de Rol y Botón de Aprobación */}
                    <div className="mt-1.5 flex items-center gap-2 flex-wrap">
                      <div className="flex items-center gap-1">
                        <span className="text-[10px] text-slate-400 font-semibold">Rol:</span>
                        <select
                          value={u.role === 'admin' ? 'admin' : isTreasurerActive ? 'tesorero' : 'integrante'}
                          onChange={(e) => handleRoleChange(u.id, e.target.value as UserRole)}
                          className="text-[10px] font-bold py-0.5 px-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200"
                        >
                          <option value="integrante">👤 Integrante</option>
                          <option value="tesorero">💰 Tesorero/a</option>
                          <option value="admin">🛡️ Coordinador/a</option>
                        </select>
                      </div>

                      {isPending && (
                        <button
                          onClick={() => handleApproveMember(u.id, u.name)}
                          className="px-2.5 py-0.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px] shadow-sm flex items-center gap-1 transition active:scale-95"
                          title="Autorizar a este nuevo integrante para que pueda ingresar a la app"
                        >
                          <Check className="w-3 h-3" />
                          <span>Aceptar nuevo integrante</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                {/* Botones Editar Acceso y Eliminar Integrante */}
                <div className="flex flex-col gap-1.5 shrink-0">
                  <button
                    onClick={() => openEditMemberModal(u)}
                    className="p-2 rounded-xl border bg-blue-50 hover:bg-blue-600 dark:bg-blue-950/40 dark:hover:bg-blue-600 text-blue-700 dark:text-blue-300 hover:text-white dark:hover:text-white border-blue-200 dark:border-blue-900/50 shadow-sm transition flex items-center justify-center"
                    title={`Ver / editar correo, cédula o clave de ${u.name}`}
                  >
                    <Key className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setUserToDelete(u)}
                    disabled={users.length <= 1}
                    className={`p-2 rounded-xl border transition flex items-center justify-center ${
                      users.length <= 1
                        ? 'opacity-40 cursor-not-allowed bg-slate-100 dark:bg-slate-800 text-slate-400 border-slate-200 dark:border-slate-700'
                        : 'bg-rose-50 hover:bg-rose-600 dark:bg-rose-950/40 dark:hover:bg-rose-600 text-rose-600 dark:text-rose-400 hover:text-white dark:hover:text-white border-rose-200 dark:border-rose-900/50 shadow-sm'
                    }`}
                    title={users.length <= 1 ? 'No puedes eliminar al único integrante' : `Eliminar a ${u.name}`}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Grid de 2 columnas: Configuración de Grupo vs Recordatorios Motivacionales */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Columna 1: Ajustes de Grupo, Parroquia, Logo y Código de Invitación */}
        <div id="group-settings" className="p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4 scroll-mt-20">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Palette className="w-4 h-4 text-blue-600" /> Identidad: Nombre, Parroquia y Logo
            </h3>
            <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300">
              Personalizable
            </span>
          </div>

          {/* Banner con código de invitación actual */}
          <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/50 flex items-center justify-between">
            <div>
              <span className="text-[10px] uppercase font-bold text-amber-700 dark:text-amber-400 block">
                Código de Invitación Oficial
              </span>
              <span className="text-xl font-mono font-black text-slate-900 dark:text-white tracking-widest">
                {settings.invitationCode}
              </span>
            </div>
            <button
              onClick={copyInvitationCode}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition"
            >
              {copiedCode ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedCode ? '¡Copiado!' : 'Copiar'}</span>
            </button>
          </div>

          <form onSubmit={handleSaveSettings} className="space-y-3.5 text-xs">
            {/* Nombre del Grupo */}
            <div>
              <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                Nombre del Grupo Juvenil *
              </label>
              <input
                type="text"
                required
                value={groupNameDraft}
                onChange={(e) => setGroupNameDraft(e.target.value)}
                placeholder="Ej: JMV Santa María de la Esperanza"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-bold"
              />
            </div>

            {/* Parroquia o Comunidad */}
            <div>
              <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                Parroquia o Comunidad Local *
              </label>
              <input
                type="text"
                required
                value={parishNameDraft}
                onChange={(e) => setParishNameDraft(e.target.value)}
                placeholder="Ej: Parroquia San Vicente de Paúl"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>

            {/* Logo o Escudo del Grupo */}
            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <label className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <Palette className="w-3.5 h-3.5 text-blue-600" />
                  Logo o Escudo Oficial del Grupo
                </label>
                {logoAppliedSuccess && (
                  <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
                    ✓ Aplicado en toda la app
                  </span>
                )}
              </div>

              {/* Vista previa en vivo de cómo se verá en la barra superior e inicio */}
              <div className="p-2.5 rounded-2xl bg-gradient-to-r from-blue-950 via-blue-900 to-indigo-900 text-white flex items-center gap-3 shadow-sm">
                <div className="w-14 h-14 rounded-2xl overflow-hidden ring-2 ring-amber-400 bg-white p-1 shrink-0 shadow flex items-center justify-center">
                  <img
                    src={logoDraft}
                    alt="Logo preview"
                    className="w-full h-full object-contain"
                  />
                </div>
                <div className="min-w-0 flex-1">
                  <span className="text-[9px] uppercase tracking-wider font-bold text-amber-300 block">
                    Vista previa en encabezado e inicio
                  </span>
                  <p className="font-extrabold text-sm text-white truncate">
                    {groupNameDraft || settings.groupName}
                  </p>
                  <p className="text-[11px] text-blue-200 truncate">
                    {parishNameDraft || settings.parishName}
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                <label className="cursor-pointer inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs transition shadow-sm">
                  <Upload className="w-3.5 h-3.5" />
                  <span>{isCompressingLogo ? 'Comprimiendo...' : 'Subir Logo Propio'}</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleLogoFile}
                    className="hidden"
                  />
                </label>
                <p className="text-[10px] text-slate-500 dark:text-slate-400 flex-1 min-w-[160px]">
                  Al subirlo se actualiza automáticamente en la barra superior, menú lateral, inicio, perfil, tarjetas y acceso.
                </p>
              </div>

              {/* Presets rápidos */}
              <div className="pt-2 border-t border-slate-200 dark:border-slate-700 flex flex-wrap items-center gap-2">
                <span className="text-[10px] text-slate-400">Emblemas predefinidos:</span>
                <button
                  type="button"
                  onClick={() => handleSelectPresetLogo(marianMedalImg)}
                  className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700 text-[10px] font-semibold hover:bg-white dark:hover:bg-slate-700 transition"
                >
                  Medalla Milagrosa
                </button>
                <button
                  type="button"
                  onClick={() => handleSelectPresetLogo(heroYouthImg)}
                  className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700 text-[10px] font-semibold hover:bg-white dark:hover:bg-slate-700 transition"
                >
                  Comunidad Joven
                </button>
              </div>
            </div>

            {/* Configuración de Portada Principal: Paleta de Colores y Foto de los Jóvenes */}
            <div className="p-3.5 rounded-2xl bg-gradient-to-r from-blue-50/80 to-indigo-50/80 dark:from-blue-950/40 dark:to-indigo-950/40 border border-blue-200/80 dark:border-blue-800/60 space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5 text-xs">
                    <Palette className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                    Portada Principal: Paleta y Foto del Grupo
                  </span>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                    Paleta actual: <strong>{getBannerPalette(settings.bannerPalette).name}</strong>
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setShowBannerCustomizeModal(true)}
                  className="px-3 py-1.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow transition active:scale-95 flex items-center gap-1.5"
                >
                  <Palette className="w-3.5 h-3.5 text-amber-300" />
                  <span>Personalizar Portada</span>
                </button>
              </div>

              {/* Muestra de la foto de portada configurada */}
              <div className="flex items-center gap-3 pt-1">
                <div className="w-16 h-10 rounded-xl overflow-hidden ring-1 ring-slate-300 dark:ring-slate-700 shrink-0 bg-slate-200">
                  <img
                    src={settings.bannerImageUrl || heroYouthImg}
                    alt="Portada jóvenes"
                    className="w-full h-full object-cover"
                  />
                </div>
                <span className="text-[10px] text-slate-500">
                  {settings.bannerImageUrl && settings.bannerImageUrl !== heroYouthImg
                    ? '✓ Foto propia del grupo configurada'
                    : 'Foto de muestra vicenciana oficial'}
                </span>
              </div>
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                Código de invitación oficial para nuevos miembros
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  required
                  value={invitationCodeDraft}
                  onChange={(e) =>
                    setInvitationCodeDraft(e.target.value.replace(/[\s\u200B-\u200D\uFEFF]/g, '').toUpperCase())
                  }
                  className="flex-1 px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono font-bold tracking-wider"
                />
                <button
                  type="button"
                  onClick={handleSaveInvitationCodeOnly}
                  className="px-3.5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs shadow-sm transition active:scale-95 shrink-0"
                >
                  Guardar Código
                </button>
              </div>
              {invitationCodeDraft.replace(/[\s\u200B-\u200D\uFEFF]/g, '').toUpperCase() !==
                settings.invitationCode.replace(/[\s\u200B-\u200D\uFEFF]/g, '').toUpperCase() && (
                <p className="mt-1 text-[11px] font-bold text-amber-700 dark:text-amber-400">
                  Tienes un cambio sin guardar en el código. Presiona &laquo;Guardar Código&raquo; antes de compartirlo.
                </p>
              )}
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                Meta total de recaudación para chompas ($ USD)
              </label>
              <input
                type="number"
                min="50"
                step="10"
                value={hoodieGoalDraft}
                onChange={(e) => setHoodieGoalDraft(Number(e.target.value))}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-bold"
              />
            </div>

            {/* Designación de Tesorero/a */}
            <div className="p-3.5 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200/60 dark:border-emerald-900/40 space-y-2">
              <label className="block font-bold text-emerald-900 dark:text-emerald-300 flex items-center gap-1.5">
                <DollarSign className="w-4 h-4 text-emerald-600" />
                Persona Encargada de la Economía (Tesorero/a)
              </label>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Solo esta persona y la coordinación podrán registrar cuotas, agregar semanas, crear ventas y registrar gastos.
              </p>
              <select
                value={treasurerUser?.id || ''}
                onChange={(e) => setTreasurerUser(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-emerald-300 dark:border-emerald-800 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-semibold text-xs"
              >
                {users.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.name} ({u.role === 'admin' ? 'Coordinador' : u.role === 'tesorero' || u.isTreasurer ? 'Tesorero actual' : 'Integrante'})
                  </option>
                ))}
              </select>
            </div>

            {/* Configuración opcional de EmailJS para envío automático de recordatorios de contraseña */}
            <div className="rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden">
              <button
                type="button"
                onClick={() => setShowEmailConfig((prev) => !prev)}
                className="w-full p-3 bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between text-left"
              >
                <span className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-blue-600" />
                  Envío Automático de Correos (Recordar Clave)
                </span>
                <span className="text-[10px] font-semibold text-blue-700 dark:text-blue-400">
                  {showEmailConfig ? 'Ocultar' : emailjsServiceDraft ? 'Configurado' : 'Opcional'}
                </span>
              </button>
              {showEmailConfig && (
                <div className="p-3.5 space-y-2.5 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-700 text-[11px]">
                  <p className="text-slate-500 dark:text-slate-400 leading-relaxed">
                    Para enviar recordatorios de contraseña automáticamente al correo (incluso en Netlify), ingresa tu cuenta gratuita de <strong>EmailJS</strong> o configura <code className="px-1 rounded bg-slate-100 dark:bg-slate-800">RESEND_API_KEY</code> en el servidor.
                  </p>
                  <input
                    type="text"
                    value={emailjsServiceDraft}
                    onChange={(e) => setEmailjsServiceDraft(e.target.value)}
                    placeholder="EmailJS Service ID (ej: service_xxxx)"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono text-xs"
                  />
                  <input
                    type="text"
                    value={emailjsTemplateDraft}
                    onChange={(e) => setEmailjsTemplateDraft(e.target.value)}
                    placeholder="EmailJS Template ID (ej: template_xxxx)"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono text-xs"
                  />
                  <input
                    type="text"
                    value={emailjsKeyDraft}
                    onChange={(e) => setEmailjsKeyDraft(e.target.value)}
                    placeholder="EmailJS Public Key"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono text-xs"
                  />
                </div>
              )}
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow flex items-center justify-center gap-2"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{savedSettingsSuccess ? '¡Ajustes guardados!' : 'Guardar Cambios de Configuración'}</span>
            </button>
          </form>
        </div>

        {/* Columna 2: Recordatorios Motivacionales Automatizados */}
        <div className="p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Bell className="w-4 h-4 text-blue-600" /> Recordatorios Motivacionales
            </h3>
            <span className="text-xs text-slate-500">Notificaciones</span>
          </div>

          <p className="text-xs text-slate-500">
            Envía mensajes de motivación antes de cada reunión para animar la asistencia y el compromiso.
          </p>

          <form onSubmit={handleCreateReminder} className="space-y-3 text-xs">
            <div>
              <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                Título del recordatorio *
              </label>
              <input
                type="text"
                required
                value={reminderTitle}
                onChange={(e) => setReminderTitle(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                Mensaje motivacional *
              </label>
              <textarea
                rows={3}
                required
                value={reminderMessage}
                onChange={(e) => setReminderMessage(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white leading-relaxed"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow flex items-center justify-center gap-2"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Programar y Probar Notificación Push</span>
            </button>
          </form>

          {/* Lista de recordatorios programados */}
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
              Mensajes Programados ({reminders.length})
            </span>
            {reminders.map((r) => (
              <div key={r.id} className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 text-xs">
                <span className="font-bold text-slate-900 dark:text-white block">{r.title}</span>
                <p className="text-slate-600 dark:text-slate-300 mt-0.5">{r.message}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Modal 1: Confirmación de Eliminación Individual */}
      {userToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-sm rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2 text-rose-600 dark:text-rose-400 font-bold text-sm">
                <AlertTriangle className="w-4 h-4" />
                <span>Eliminar Integrante</span>
              </div>
              <button
                onClick={() => setUserToDelete(null)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex items-center gap-3 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <img
                src={userToDelete.avatarUrl}
                alt={userToDelete.name}
                className="w-12 h-12 rounded-full object-cover ring-2 ring-rose-400 shrink-0"
              />
              <div className="min-w-0">
                <p className="font-bold text-sm text-slate-900 dark:text-white truncate">
                  {userToDelete.name}
                </p>
                <p className="text-xs text-slate-500">
                  {userToDelete.role === 'admin'
                    ? '🛡️ Coordinador'
                    : userToDelete.role === 'tesorero' || userToDelete.isTreasurer
                    ? '💰 Tesorero'
                    : '👤 Integrante'}
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              ¿Estás seguro de que deseas eliminar a <strong>{userToDelete.name}</strong> del grupo JMV?
              Esta acción es permanente y removerá su perfil para que puedas registrar a tus integrantes reales.
            </p>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setUserToDelete(null)}
                className="flex-1 py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-semibold text-xs hover:bg-slate-50 dark:hover:bg-slate-800 transition"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => handleDeleteMember(userToDelete.id)}
                className="flex-1 py-2.5 px-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow transition active:scale-95 flex items-center justify-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Sí, Eliminar</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal 2: Confirmación de Limpieza de Ejemplos */}
      {showCleanExamplesModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-sm rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400 font-bold text-sm">
                <Trash2 className="w-4 h-4" />
                <span>Limpiar Integrantes de Ejemplo</span>
              </div>
              <button
                onClick={() => setShowCleanExamplesModal(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/50 space-y-2">
              <span className="text-xs font-bold text-amber-900 dark:text-amber-300 block">
                ¿Qué sucederá con esta acción?
              </span>
              <ul className="text-xs text-amber-800 dark:text-amber-400 space-y-1 list-disc list-inside">
                <li>Se eliminarán los perfiles muestra: <em>Sofía Martínez, Carlos Paredes, Lucía Fernández, Mateo Ramírez</em>.</li>
                <li>Se mantendrá tu usuario coordinador para que no pierdas acceso.</li>
                <li>Tu grupo quedará listo para ingresar a tus miembros reales.</li>
              </ul>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300">
              ¿Deseas continuar y vaciar los integrantes de prueba ahora?
            </p>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => setShowCleanExamplesModal(false)}
                className="flex-1 py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-semibold text-xs hover:bg-slate-50 dark:hover:bg-slate-800 transition"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleCleanExamples}
                className="flex-1 py-2.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow transition active:scale-95 flex items-center justify-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Limpiar Ejemplos</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal 3: Crear Nuevo Integrante Real Rápido */}
      {showNewMemberModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-5 sm:p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2 text-blue-900 dark:text-blue-300 font-bold text-base">
                <UserPlus className="w-5 h-5 text-blue-600" />
                <span>Registrar Nuevo Integrante Real</span>
              </div>
              <button
                onClick={() => setShowNewMemberModal(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateNewMember} className="space-y-3.5 text-xs">
              {newMemberError && (
                <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900/50 text-rose-700 dark:text-rose-300 font-semibold flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{newMemberError}</span>
                </div>
              )}

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Nombre Completo *
                </label>
                <input
                  type="text"
                  required
                  value={newMemberName}
                  onChange={(e) => setNewMemberName(e.target.value)}
                  placeholder="Ej: David Salazar Gómez"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-semibold"
                />
              </div>

              {/* Correo y Cédula para autenticación individual */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Correo Electrónico *
                  </label>
                  <input
                    type="email"
                    required
                    value={newMemberEmail}
                    onChange={(e) => setNewMemberEmail(e.target.value)}
                    placeholder="correo@ejemplo.com"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-medium"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Cédula * (Acceso por defecto)
                  </label>
                  <input
                    type="text"
                    required
                    value={newMemberCedula}
                    onChange={(e) => setNewMemberCedula(e.target.value)}
                    placeholder="Ej: 1720123456"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Contraseña personalizada (Opcional)
                </label>
                <input
                  type="text"
                  value={newMemberPassword}
                  onChange={(e) => setNewMemberPassword(e.target.value)}
                  placeholder="Si se deja vacío, ingresará usando su número de cédula"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Fecha de Cumpleaños *
                  </label>
                  <input
                    type="date"
                    required
                    value={newMemberBirthday}
                    onChange={(e) => setNewMemberBirthday(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Rol en el Grupo
                  </label>
                  <select
                    value={newMemberRole}
                    onChange={(e) => setNewMemberRole(e.target.value as UserRole)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-semibold"
                  >
                    <option value="integrante">👤 Integrante</option>
                    <option value="tesorero">💰 Tesorero/a (Economía)</option>
                    <option value="admin">🛡️ Coordinador/a (Admin)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Teléfono / WhatsApp (Opcional)
                </label>
                <input
                  type="tel"
                  value={newMemberPhone}
                  onChange={(e) => setNewMemberPhone(e.target.value)}
                  placeholder="Ej: +593 99 876 5432"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              {/* Subir foto opcional con compresión automática */}
              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Foto de Perfil (Opcional)
                </label>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full overflow-hidden ring-2 ring-amber-400 bg-slate-100 dark:bg-slate-800 shrink-0 flex items-center justify-center">
                    {newMemberAvatar ? (
                      <img src={newMemberAvatar} alt="Preview" className="w-full h-full object-cover" />
                    ) : (
                      <Users className="w-5 h-5 text-slate-400" />
                    )}
                  </div>
                  <label className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold text-xs transition">
                    <Upload className="w-3.5 h-3.5" />
                    <span>{isCompressingNewAvatar ? 'Comprimiendo...' : 'Subir Foto'}</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleNewAvatarFile}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              <div className="pt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowNewMemberModal(false);
                    setNewMemberError('');
                  }}
                  className="flex-1 py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-semibold text-xs hover:bg-slate-50 dark:hover:bg-slate-800 transition"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-3 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow transition active:scale-95 flex items-center justify-center gap-1.5"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Guardar Integrante</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 5: Editar Datos / Clave de Acceso de Integrante */}
      {editingMember && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-5 sm:p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2 text-blue-900 dark:text-blue-300 font-bold text-base">
                <Key className="w-5 h-5 text-amber-500" />
                <span>Editar Acceso de Integrante</span>
              </div>
              <button
                onClick={() => setEditingMember(null)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEditMember} className="space-y-3.5 text-xs">
              {editMemberError && (
                <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900/50 text-rose-700 dark:text-rose-300 font-semibold flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{editMemberError}</span>
                </div>
              )}

              {/* Foto del integrante con actualización global */}
              <div className="flex items-center gap-3.5 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700">
                <img
                  src={editMemberAvatar || editingMember.avatarUrl}
                  alt={editMemberName || editingMember.name}
                  className="w-14 h-14 rounded-full object-cover ring-2 ring-amber-400 bg-white shrink-0"
                  referrerPolicy="no-referrer"
                />
                <div className="flex-1 min-w-0 space-y-1">
                  <p className="font-bold text-slate-800 dark:text-slate-100">Foto del Integrante</p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Al guardar se actualizará en toda la aplicación.
                  </p>
                  <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-blue-800 dark:text-blue-300 font-bold text-[11px] cursor-pointer hover:bg-blue-50 dark:hover:bg-slate-700 transition">
                    <Upload className="w-3.5 h-3.5" />
                    <span>{isCompressingEditAvatar ? 'Procesando...' : 'Cambiar Foto'}</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleEditMemberAvatarFile}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Nombre Completo *
                </label>
                <input
                  type="text"
                  required
                  value={editMemberName}
                  onChange={(e) => setEditMemberName(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-semibold"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Correo Electrónico *
                </label>
                <input
                  type="email"
                  required
                  value={editMemberEmail}
                  onChange={(e) => setEditMemberEmail(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Cédula *
                  </label>
                  <input
                    type="text"
                    required
                    value={editMemberCedula}
                    onChange={(e) => setEditMemberCedula(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Contraseña de acceso *
                  </label>
                  <input
                    type="text"
                    required
                    value={editMemberPassword}
                    onChange={(e) => setEditMemberPassword(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono font-bold"
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setEditingMember(null)}
                  className="flex-1 py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-semibold text-xs hover:bg-slate-50 dark:hover:bg-slate-800 transition"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-3 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow transition active:scale-95 flex items-center justify-center gap-1.5"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Guardar Acceso</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 4: Subida Masiva de Participantes con Correo y Cédula */}
      {showBulkModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-xl rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-5 sm:p-6 space-y-4 max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2 text-blue-900 dark:text-blue-300 font-bold text-base">
                <FileSpreadsheet className="w-5 h-5 text-emerald-600" />
                <span>Subida Masiva de Participantes (CSV / Lista)</span>
              </div>
              <button
                onClick={() => {
                  setShowBulkModal(false);
                  setBulkFeedback(null);
                }}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3.5 rounded-2xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900/60 text-xs space-y-1.5 text-blue-950 dark:text-blue-200">
              <p className="font-bold">📋 Formato aceptado:</p>
              <p>Pega tu lista separada por comas, punto y coma o tabulaciones de Excel:</p>
              <code className="block p-2 rounded-xl bg-white/80 dark:bg-slate-900/80 font-mono text-[11px] text-blue-800 dark:text-blue-300 border border-blue-200/60 dark:border-blue-800">
                Nombre, Correo, Cédula, Teléfono, FechaNacimiento(AAAA-MM-DD)
              </code>
              <p className="text-[11px] text-slate-600 dark:text-slate-400">
                Cada participante será aprobado automáticamente y podrá acceder a la app usando su correo y su cédula.
              </p>
            </div>

            <form onSubmit={handleProcessBulk} className="space-y-3.5 text-xs">
              <div className="flex items-center justify-between">
                <label className="font-semibold text-slate-700 dark:text-slate-300">
                  Pegar datos de participantes:
                </label>
                <button
                  type="button"
                  onClick={() => {
                    setBulkText(
                      `María Belén Gómez, maria.gomez@gmail.com, 1729876541, +593981234567, 2005-04-12\n` +
                      `Sebastián Alarcón, sebas.alarcon@gmail.com, 1728765432, +593992345678, 2004-11-23\n` +
                      `Valeria Castro, valeria.castro@gmail.com, 1727654323, +593973456789, 2006-08-30`
                    );
                  }}
                  className="text-xs text-blue-600 hover:text-blue-800 dark:text-blue-400 font-semibold underline"
                >
                  Cargar ejemplo de prueba
                </button>
              </div>

              <textarea
                value={bulkText}
                onChange={(e) => setBulkText(e.target.value)}
                placeholder={`David Morales, david@gmail.com, 1720987654, 0998765432, 2005-06-15\nCamila Torres, camila@gmail.com, 1721876543, 0991234567, 2006-02-20`}
                rows={7}
                className="w-full p-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono text-xs leading-relaxed"
                required
              />

              {bulkFeedback && (
                <div
                  className={`p-3 rounded-2xl text-xs space-y-1 ${
                    bulkFeedback.success
                      ? 'bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300'
                      : 'bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-300'
                  }`}
                >
                  <p className="font-bold">
                    {bulkFeedback.success
                      ? `✓ ¡${bulkFeedback.count} participantes registrados y aprobados!`
                      : '⚠️ Errores encontrados:'}
                  </p>
                  {bulkFeedback.errors.length > 0 && (
                    <ul className="list-disc list-inside space-y-0.5 text-[11px]">
                      {bulkFeedback.errors.map((err, idx) => (
                        <li key={idx}>{err}</li>
                      ))}
                    </ul>
                  )}
                </div>
              )}

              <div className="pt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowBulkModal(false);
                    setBulkFeedback(null);
                  }}
                  className="flex-1 py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-semibold text-xs hover:bg-slate-50 dark:hover:bg-slate-800 transition"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow transition active:scale-95 flex items-center justify-center gap-1.5"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Procesar e Importar Lista</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal de Personalización de Portada (Paleta de Colores y Foto de los Jóvenes) */}
      <BannerCustomizeModal
        isOpen={showBannerCustomizeModal}
        onClose={() => setShowBannerCustomizeModal(false)}
        currentPaletteId={settings.bannerPalette}
        currentImageUrl={settings.bannerImageUrl}
        currentImageOpacity={settings.bannerImageOpacity}
        groupName={settings.groupName}
        onSave={({ paletteId, imageUrl, imageOpacity }) => {
          updateSettings({
            bannerPalette: paletteId,
            bannerImageUrl: imageUrl,
            bannerImageOpacity: imageOpacity,
          });
          setFeedbackMessage({ type: 'success', text: '¡Portada del grupo actualizada exitosamente!' });
          setTimeout(() => setFeedbackMessage(null), 3500);
        }}
      />

      {/* Modal para Crear Otro Grupo Independiente */}
      {showNewGroupModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-5 sm:p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2 text-blue-900 dark:text-blue-300 font-bold text-base">
                <Users className="w-5 h-5 text-blue-600" />
                <span>Nuevo Espacio por Grupo</span>
              </div>
              <button
                type="button"
                onClick={() => setShowNewGroupModal(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {newGroupError && (
              <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-xs text-rose-700 dark:text-rose-300">
                {newGroupError}
              </div>
            )}

            <form onSubmit={handleCreateAnotherGroup} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Nombre del Grupo JMV *
                </label>
                <input
                  type="text"
                  required
                  value={newGroupNameDraft}
                  onChange={(e) => setNewGroupNameDraft(e.target.value)}
                  placeholder="Ej: JMV Parroquia La Merced"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-bold"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Parroquia / Comunidad
                  </label>
                  <input
                    type="text"
                    value={newGroupParishDraft}
                    onChange={(e) => setNewGroupParishDraft(e.target.value)}
                    placeholder="Ej: Parroquia La Merced"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Código Privado *
                  </label>
                  <input
                    type="text"
                    required
                    value={newGroupCodeDraft}
                    onChange={(e) =>
                      setNewGroupCodeDraft(e.target.value.replace(/[\s\u200B-\u200D\uFEFF]/g, '').toUpperCase())
                    }
                    placeholder="Ej: MERCED26"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono font-bold uppercase"
                  />
                </div>
              </div>

              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2.5">
                <p className="font-bold text-slate-700 dark:text-slate-300">
                  Coordinador/a del nuevo grupo:
                </p>
                <input
                  type="text"
                  required
                  value={newGroupCoordName}
                  onChange={(e) => setNewGroupCoordName(e.target.value)}
                  placeholder="Nombre y apellido *"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <input
                    type="email"
                    required
                    value={newGroupCoordEmail}
                    onChange={(e) => setNewGroupCoordEmail(e.target.value)}
                    placeholder="Correo electrónico *"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                  <input
                    type="text"
                    required
                    value={newGroupCoordCedula}
                    onChange={(e) => setNewGroupCoordCedula(e.target.value.replace(/\D/g, ''))}
                    placeholder="Cédula *"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono font-bold"
                  />
                </div>
                <input
                  type="text"
                  value={newGroupCoordPass}
                  onChange={(e) => setNewGroupCoordPass(e.target.value)}
                  placeholder="Contraseña opcional (por defecto su cédula)"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
                />
              </div>

              <div className="pt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowNewGroupModal(false)}
                  className="flex-1 py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-semibold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isCreatingNewGroup}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 text-white font-bold shadow transition"
                >
                  {isCreatingNewGroup ? 'Creando...' : 'Crear Grupo Independiente'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
