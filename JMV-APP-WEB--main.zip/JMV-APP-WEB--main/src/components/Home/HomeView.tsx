import React, { useState, useEffect } from 'react';
import {
  Calendar,
  Clock,
  Award,
  DollarSign,
  Cake,
  Bell,
  Heart,
  ChevronRight,
  BookOpen,
  Sparkles,
  Users,
  Compass,
  ArrowRight,
  RefreshCw,
  Gift,
  Palette,
  Shuffle,
  CalendarDays,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { MOTIVATIONAL_QUOTES, getDailyQuote } from '../../services/storage';
import { getBannerPalette } from '../../data/bannerPalettes';
import { BannerCustomizeModal } from './BannerCustomizeModal';
import heroYouthImg from '../../assets/images/jmv_hero_youth_1794117311900.jpg';
import marianMedalImg from '../../assets/images/jmv_marian_medal_1794117311829.jpg';

export const HomeView: React.FC<{
  onNavigateTab: (tab: string) => void;
  onOpenRegister?: () => void;
}> = ({ onNavigateTab, onOpenRegister }) => {
  const {
    currentUser,
    challenges,
    feePayments,
    settings,
    updateSettings,
    users,
    activities,
    reflection,
    secretRound,
    mySecretTarget,
    chatMessages,
    isAdmin,
  } = useApp();

  // Cuenta regresiva para la próxima reunión
  const [timeLeft, setTimeLeft] = useState<{ days: number; hours: number; minutes: number; seconds: number }>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  // Frase del día automática según la fecha actual
  const dailyQuoteData = getDailyQuote();
  const [quoteIndex, setQuoteIndex] = useState(dailyQuoteData.index);
  const [showCustomizeModal, setShowCustomizeModal] = useState(false);

  useEffect(() => {
    // Calcular tiempo restante para la próxima reunión
    const updateCountdown = () => {
      const target = new Date(settings.nextMeetingDate).getTime();
      const now = new Date().getTime();
      const difference = target - now;

      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((difference % (1000 * 60)) / 1000),
        });
      } else {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
      }
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, [settings.nextMeetingDate]);

  // Reto activo
  const activeChallenge = challenges.find((c) => c.isActive) || challenges[0];

  // Cumpleaños próximos (este mes o en los próximos 14 días)
  const today = new Date();
  const upcomingBirthdays = users.filter((u) => {
    if (!u.birthday) return false;
    const bday = new Date(u.birthday);
    const bMonth = bday.getMonth();
    const bDay = bday.getDate();
    const currentMonth = today.getMonth();
    const currentDay = today.getDate();

    // Mismo mes y día futuro o actual, o principios del próximo mes
    if (bMonth === currentMonth && bDay >= currentDay && bDay <= currentDay + 14) return true;
    if (bMonth === (currentMonth + 1) % 12 && bDay <= 7) return true;
    return false;
  });

  // Estadísticas personales de cuota
  const myPayments = feePayments.filter((p) => p.userId === currentUser.id && p.status === 'pagado');
  const totalPaidByMe = myPayments.reduce((acc, p) => acc + p.amount, 0);

  // Mensaje fijado del asesor o coordinador
  const pinnedNotice = chatMessages.find((m) => m.isPinned);

  // Paleta activa del cuadro principal
  const activePalette = getBannerPalette(settings.bannerPalette);

  // Control de frases: automática por fecha o aleatoria a petición
  const isTodayQuote = quoteIndex === dailyQuoteData.index;
  const currentQuote = MOTIVATIONAL_QUOTES[quoteIndex] || dailyQuoteData.quote;

  const handleRandomQuote = () => {
    let nextIdx = Math.floor(Math.random() * MOTIVATIONAL_QUOTES.length);
    if (nextIdx === quoteIndex) {
      nextIdx = (quoteIndex + 1) % MOTIVATIONAL_QUOTES.length;
    }
    setQuoteIndex(nextIdx);
  };

  const handleResetToTodayQuote = () => {
    setQuoteIndex(dailyQuoteData.index);
  };

  const pendingMembersCount = isAdmin
    ? users.filter((u) => u.status === 'pendiente_aprobacion').length
    : 0;

  return (
    <div className="space-y-6 pb-20 animate-in fade-in">
      {isAdmin && pendingMembersCount > 0 && (
        <button
          type="button"
          onClick={() => onNavigateTab('admin')}
          className="w-full p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border-2 border-emerald-300 dark:border-emerald-800 text-left flex items-center justify-between gap-3 shadow-sm hover:bg-emerald-100/70 dark:hover:bg-emerald-950/60 transition"
        >
          <div className="flex items-center gap-3 min-w-0">
            <span className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 font-extrabold text-sm shadow">
              {pendingMembersCount}
            </span>
            <div className="min-w-0">
              <p className="text-xs sm:text-sm font-extrabold text-emerald-950 dark:text-emerald-200 truncate">
                {pendingMembersCount === 1
                  ? '1 nuevo integrante espera tu autorización para ingresar'
                  : `${pendingMembersCount} nuevos integrantes esperan tu autorización para ingresar`}
              </p>
              <p className="text-[11px] text-emerald-700 dark:text-emerald-300 truncate">
                Pulsa aquí para revisar la solicitud y presionar «Aceptar nuevo integrante»
              </p>
            </div>
          </div>
          <span className="px-3 py-1.5 rounded-xl bg-emerald-600 text-white font-bold text-xs shrink-0 flex items-center gap-1">
            <span>Revisar</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </span>
        </button>
      )}

      {/* Banner de bienvenida y espíritu mariano con paleta configurable y foto propia */}
      <div
        className={`relative overflow-hidden rounded-3xl bg-gradient-to-br ${activePalette.gradientClass} text-white p-6 shadow-xl border ${activePalette.borderClass} transition-all duration-300`}
      >
        <div className="relative z-10 max-w-2xl">
          <div className="flex flex-wrap items-start justify-between gap-3 mb-3">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-white/95 p-1.5 ring-2 ring-amber-300/80 shadow-lg shrink-0 flex items-center justify-center overflow-hidden">
                <img
                  src={settings.logoUrl || marianMedalImg}
                  alt={settings.groupName}
                  className="w-full h-full object-contain rounded-xl"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="min-w-0">
                <span
                  className={`font-extrabold text-[11px] tracking-wider uppercase px-2.5 py-0.5 rounded-full inline-flex items-center gap-1 ${activePalette.badgeBg}`}
                >
                  <Sparkles className="w-3 h-3" /> {settings.groupName}
                </span>
                <p className="mt-1 text-xs sm:text-sm font-bold text-amber-200 truncate drop-shadow-sm">
                  {settings.parishName || 'Comunidad Parroquial'}
                </p>
              </div>
            </div>

            {/* Botón para cambiar paleta de colores y foto del cuadro principal */}
            <button
              onClick={() => setShowCustomizeModal(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-semibold backdrop-blur-md border border-white/25 shadow-sm transition active:scale-95 cursor-pointer shrink-0"
              title="Personalizar colores del cuadro y subir foto propia del grupo"
            >
              <Palette className="w-3.5 h-3.5 text-amber-300" />
              <span>Personalizar Portada</span>
            </button>
          </div>

          <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight">
            ¡La paz esté contigo, {currentUser.name.split(' ')[0]}!
          </h1>
          <p className="mt-1 text-xs sm:text-sm text-blue-100/90 leading-relaxed">
            "A Jesús por María". Que el fuego de la caridad vicenciana guíe hoy tus acciones y servicio en {settings.groupName}.
          </p>

          <div className="mt-3 flex items-center gap-2 text-xs text-blue-200/90 bg-white/10 backdrop-blur-sm px-3 py-1.5 rounded-xl w-fit">
            <span>👤 Conectado como: <strong className="text-white">{currentUser.name}</strong></span>
            <button
              onClick={() => onNavigateTab('perfil')}
              className="text-amber-300 hover:text-amber-200 underline font-semibold ml-1 cursor-pointer"
            >
              (Ver mi ficha)
            </button>
          </div>

          <div className="mt-4 flex flex-wrap items-center gap-2.5 sm:gap-3">
            <button
              onClick={() => onNavigateTab('retos')}
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl font-bold text-xs shadow-md transition active:scale-95 ${activePalette.primaryButtonClass}`}
            >
              <Award className="w-4 h-4" />
              <span>Ver Reto de la Semana</span>
            </button>
            <button
              onClick={() => onNavigateTab('chat')}
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl font-semibold text-xs backdrop-blur-sm transition border ${activePalette.secondaryButtonClass}`}
            >
              <span>Abrir Chat Grupal</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
            {onOpenRegister && (
              <button
                onClick={onOpenRegister}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs backdrop-blur-sm transition border border-white/20"
              >
                <span>+ Registrar nuevo integrante</span>
              </button>
            )}
          </div>
        </div>

        {/* Imagen de fondo sutil con scrim medido (foto propia del grupo o muestra oficial) */}
        <div
          className="absolute right-0 top-0 bottom-0 w-1/2 hidden sm:block pointer-events-none transition-opacity duration-300"
          style={{ opacity: (settings.bannerImageOpacity ?? 30) / 100 }}
        >
            <img
              src={settings.bannerImageUrl || heroYouthImg}
              alt={settings.groupName}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
        </div>
      </div>

      {/* Tarjeta de Registro y Bienvenida para nuevos estudiantes / integrantes */}
      <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-blue-900/10 via-indigo-900/10 to-amber-500/10 dark:from-blue-950/40 dark:via-indigo-950/40 dark:to-amber-950/20 border border-blue-200/80 dark:border-blue-800/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-sm">
        <div className="flex items-start gap-3">
          <div className="w-11 h-11 rounded-2xl bg-white ring-1 ring-blue-200 dark:ring-blue-800 p-1 flex items-center justify-center shrink-0 shadow-md mt-0.5 overflow-hidden">
            <img
              src={settings.logoUrl || marianMedalImg}
              alt={settings.groupName}
              className="w-full h-full object-contain rounded-xl"
            />
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="font-bold text-sm text-blue-950 dark:text-blue-100">
                ¿Eres un nuevo estudiante o integrante de {settings.groupName}?
              </h3>
              <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-700 dark:text-amber-300">
                ¡Únete!
              </span>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5 leading-relaxed">
              Crea tu ficha personal en {settings.parishName || settings.groupName} con el código privado otorgado por tu coordinador para registrar tus cuotas, ganar puntos y chatear.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 w-full sm:w-auto shrink-0">
          <button
            onClick={() => onOpenRegister?.()}
            className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-blue-900 hover:bg-blue-800 active:scale-95 text-white font-bold text-xs shadow-md transition flex items-center justify-center gap-1.5"
          >
            <span>+ Registrarme ahora</span>
          </button>
          <button
            onClick={() => onNavigateTab('perfil')}
            className="px-3 py-2.5 rounded-xl border border-blue-200 dark:border-blue-800 bg-white dark:bg-slate-800 hover:bg-slate-50 text-blue-900 dark:text-blue-300 font-bold text-xs transition"
            title="Ver mi perfil individual"
          >
            Mi Ficha
          </button>
        </div>
      </div>

      {/* Frase / Inspiración Vicenciana del Día automática y motivacional */}
      <div className="p-4 sm:p-5 rounded-3xl bg-amber-500/10 dark:bg-amber-500/5 border border-amber-500/25 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-sm">
        <div className="flex items-start gap-3 flex-1 min-w-0">
          <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-700 dark:text-amber-400 flex items-center justify-center shrink-0 mt-0.5 shadow-sm">
            <BookOpen className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[10px] font-black uppercase tracking-wider text-amber-800 dark:text-amber-400">
                Inspiración Vicenciana del Día
              </span>
              <span
                className={`text-[9px] font-extrabold px-2 py-0.5 rounded-full ${
                  isTodayQuote
                    ? 'bg-amber-500/25 text-amber-900 dark:text-amber-200 border border-amber-500/30'
                    : 'bg-blue-500/20 text-blue-900 dark:text-blue-300 border border-blue-500/30'
                }`}
              >
                {isTodayQuote ? '📅 Frase de hoy' : '🎲 Frase aleatoria'}
              </span>
              {isTodayQuote && (
                <span className="text-[10px] text-amber-800/80 dark:text-amber-300/80 font-semibold capitalize hidden sm:inline">
                  · {dailyQuoteData.dayString}
                </span>
              )}
            </div>
            <p className="text-xs sm:text-sm font-semibold italic text-slate-800 dark:text-slate-100 mt-1 leading-relaxed">
              "{currentQuote.text}"
            </p>
            <p className="text-[11px] font-medium text-amber-900/80 dark:text-amber-400/90 mt-0.5">
              — {currentQuote.author}
            </p>
          </div>
        </div>

        {/* Botones de acción: Cambiar frase aleatoria o regresar a la del día */}
        <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
          {!isTodayQuote && (
            <button
              onClick={handleResetToTodayQuote}
              className="flex items-center gap-1 text-[11px] font-bold text-blue-700 dark:text-blue-400 hover:underline px-2.5 py-1.5 rounded-xl hover:bg-blue-50 dark:hover:bg-blue-950/40 transition"
              title="Volver a la frase asignada automáticamente para el día de hoy"
            >
              <CalendarDays className="w-3.5 h-3.5" />
              <span>Frase de hoy</span>
            </button>
          )}
          <button
            onClick={handleRandomQuote}
            title="Ver otra frase aleatoria para motivarse"
            className="flex items-center gap-1 text-[11px] font-bold text-amber-900 dark:text-amber-200 px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 active:scale-95 transition shadow-sm border border-amber-500/30"
          >
            <Shuffle className="w-3.5 h-3.5" />
            <span>Otra frase</span>
          </button>
        </div>
      </div>

      {/* Grid de 2 columnas principales */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Próxima reunión con cuenta regresiva en vivo */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-blue-900 dark:text-blue-400 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-blue-600" />
                Próxima Reunión
              </span>
              <span className="text-[11px] font-semibold text-slate-500">
                {new Date(settings.nextMeetingDate).toLocaleDateString('es-ES', {
                  weekday: 'short',
                  day: 'numeric',
                  month: 'short',
                })}
              </span>
            </div>

            <p className="mt-2 text-sm font-bold text-slate-900 dark:text-white">
              {settings.meetingLocation}
            </p>
            <p className="text-xs text-slate-500 mt-0.5">
              Hora: {new Date(settings.nextMeetingDate).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })} hrs
            </p>

            {/* Marcador de cuenta regresiva */}
            <div className="mt-4 grid grid-cols-4 gap-2 text-center">
              <div className="p-2.5 rounded-2xl bg-blue-50 dark:bg-slate-800/80 border border-blue-100 dark:border-slate-700">
                <span className="block text-lg sm:text-xl font-extrabold text-blue-900 dark:text-blue-400 tabular-nums">
                  {timeLeft.days}
                </span>
                <span className="text-[10px] font-semibold text-slate-500">Días</span>
              </div>
              <div className="p-2.5 rounded-2xl bg-blue-50 dark:bg-slate-800/80 border border-blue-100 dark:border-slate-700">
                <span className="block text-lg sm:text-xl font-extrabold text-blue-900 dark:text-blue-400 tabular-nums">
                  {String(timeLeft.hours).padStart(2, '0')}
                </span>
                <span className="text-[10px] font-semibold text-slate-500">Horas</span>
              </div>
              <div className="p-2.5 rounded-2xl bg-blue-50 dark:bg-slate-800/80 border border-blue-100 dark:border-slate-700">
                <span className="block text-lg sm:text-xl font-extrabold text-blue-900 dark:text-blue-400 tabular-nums">
                  {String(timeLeft.minutes).padStart(2, '0')}
                </span>
                <span className="text-[10px] font-semibold text-slate-500">Min</span>
              </div>
              <div className="p-2.5 rounded-2xl bg-blue-50 dark:bg-slate-800/80 border border-blue-100 dark:border-slate-700">
                <span className="block text-lg sm:text-xl font-extrabold text-amber-600 dark:text-amber-400 tabular-nums">
                  {String(timeLeft.seconds).padStart(2, '0')}
                </span>
                <span className="text-[10px] font-semibold text-slate-500">Seg</span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <span className="text-xs text-slate-500">¿Asistirás a la reunión?</span>
            <button
              onClick={() => onNavigateTab('actividades')}
              className="text-xs font-bold text-blue-800 dark:text-blue-400 hover:underline flex items-center gap-1"
            >
              Confirmar asistencia <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Reto Semanal Activo */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400 flex items-center gap-1.5">
                <Award className="w-4 h-4 text-amber-500" />
                Reto Semanal Activo
              </span>
              <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300">
                +{activeChallenge.points} pts
              </span>
            </div>

            <h3 className="mt-2 text-sm font-bold text-slate-900 dark:text-white line-clamp-1">
              {activeChallenge.title}
            </h3>
            <p className="mt-1 text-xs text-slate-600 dark:text-slate-400 line-clamp-3 leading-relaxed">
              {activeChallenge.description}
            </p>

            <div className="mt-3 p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-center gap-2">
              <Gift className="w-4 h-4 text-amber-500 shrink-0" />
              <div className="text-[11px] text-slate-700 dark:text-slate-300">
                <span className="font-semibold">Recompensa:</span> {activeChallenge.reward}
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <span className="text-xs text-slate-500">Tus puntos: <strong className="text-slate-800 dark:text-slate-200">{currentUser.points}</strong></span>
            <button
              onClick={() => onNavigateTab('retos')}
              className="px-3 py-1.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs transition"
            >
              Participar ahora
            </button>
          </div>
        </div>
      </div>

      {/* Fila de Cuota $1 y Aviso importante */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Widget Cuota Semanal $1 */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm md:col-span-1">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
              <DollarSign className="w-4 h-4 text-emerald-600" />
              Cuota Chompas ($1)
            </span>
            <span className="text-[10px] font-semibold text-slate-400">Meta: ${settings.hoodieGoalAmount}</span>
          </div>

          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white tabular-nums">
              ${totalPaidByMe}.00
            </span>
            <span className="text-xs text-slate-500">has aportado tú</span>
          </div>

          {/* Barra de progreso de la cuota del usuario */}
          <div className="mt-3">
            <div className="flex justify-between text-[11px] text-slate-500 mb-1">
              <span>{myPayments.length} semanas pagadas</span>
              <span>Meta individual: ${settings.hoodieCostPerPerson}</span>
            </div>
            <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-500"
                style={{ width: `${Math.min(100, (totalPaidByMe / settings.hoodieCostPerPerson) * 100)}%` }}
              />
            </div>
          </div>

          <button
            onClick={() => onNavigateTab('cuotas')}
            className="mt-4 w-full py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold transition flex items-center justify-center gap-1"
          >
            <span>Ver tabla general del grupo</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Aviso Pinned / Anuncio Oficial */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm md:col-span-2 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="p-1 rounded-lg bg-amber-500/10 text-amber-600">
                <Bell className="w-4 h-4" />
              </span>
              <span className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                Aviso Oficial del Asesor / Coordinación
              </span>
            </div>

            {pinnedNotice ? (
              <div className="p-3.5 rounded-2xl bg-blue-50/50 dark:bg-blue-950/20 border border-blue-100 dark:border-blue-900/30">
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="text-xs font-bold text-blue-900 dark:text-blue-300">
                    {pinnedNotice.userName}
                  </span>
                  <span className="text-[10px] text-slate-400">
                    · {new Date(pinnedNotice.createdAt).toLocaleDateString('es-ES', { day: 'numeric', month: 'short' })}
                  </span>
                </div>
                <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                  {pinnedNotice.text}
                </p>
              </div>
            ) : (
              <p className="text-xs text-slate-500 italic">No hay avisos fijados en este momento.</p>
            )}
          </div>

          {/* Cumpleaños cercanos con acceso a tarjetas automáticas */}
          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="p-1 rounded-lg bg-pink-100 dark:bg-pink-950 text-pink-600">
                <Cake className="w-4 h-4" />
              </span>
              <div className="text-xs">
                {upcomingBirthdays.length > 0 ? (
                  <span className="text-slate-700 dark:text-slate-300">
                    🎉 Próximos cumpleaños: <strong>{upcomingBirthdays.map((u) => u.name.split(' ')[0]).join(', ')}</strong>
                  </span>
                ) : (
                  <span className="text-slate-500">Consulta el calendario de cumpleaños del grupo</span>
                )}
              </div>
            </div>
            <button
              onClick={() => onNavigateTab('cumpleanios')}
              className="inline-flex items-center gap-1 text-xs font-bold text-pink-600 dark:text-pink-400 hover:text-pink-700 hover:underline shrink-0"
            >
              <span>Generar Tarjetas</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Dinámica de Amigo Secreto (Alerta especial si está activa) */}
      {secretRound && secretRound.status === 'active' && (
        <div className="p-5 rounded-3xl bg-gradient-to-r from-purple-900/90 via-indigo-900 to-blue-900 text-white shadow-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/10 flex items-center justify-center shrink-0 text-amber-300">
              <Gift className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-300">
                Dinámica Activa: Amigo Secreto Semanal
              </span>
              <h4 className="text-sm font-bold text-white mt-0.5">
                {mySecretTarget ? (
                  <>Tu amigo secreto asignado es: <span className="text-amber-300 font-extrabold">{mySecretTarget.name}</span></>
                ) : (
                  'El sorteo ha sido iniciado para toda la comunidad'
                )}
              </h4>
              <p className="text-xs text-blue-100/80 mt-0.5">
                Déjale un mensaje anónimo de oración y aprecio hoy.
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigateTab('amigo-secreto')}
            className="px-4 py-2 rounded-xl bg-white text-indigo-950 font-bold text-xs hover:bg-indigo-50 active:scale-95 transition shrink-0"
          >
            Escribir Mensaje Anónimo
          </button>
        </div>
      )}

      {/* Reflexión del Asesor Espiritual */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-2 mb-3">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-900 dark:text-blue-400 flex items-center gap-1.5">
            <Heart className="w-4 h-4 text-blue-600" />
            Palabra del Asesor
          </span>
          <span className="text-slate-400">·</span>
          <span className="text-xs text-slate-500">{reflection.advisorName}</span>
        </div>

        <h3 className="text-base font-bold text-slate-900 dark:text-white">
          {reflection.title}
        </h3>
        <p className="mt-2 text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
          {reflection.content}
        </p>

        <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
          <span>{reflection.advisorTitle}</span>
          <span>{new Date(reflection.date).toLocaleDateString('es-ES', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
        </div>
      </div>

      {/* Modal de Personalización de Portada (Paleta de Colores y Foto de los Jóvenes) */}
      <BannerCustomizeModal
        isOpen={showCustomizeModal}
        onClose={() => setShowCustomizeModal(false)}
        currentPaletteId={settings.bannerPalette}
        currentImageUrl={settings.bannerImageUrl}
        currentImageOpacity={settings.bannerImageOpacity}
        groupName={settings.groupName}
        onSave={({ paletteId, imageUrl, imageOpacity }) => {
          updateSettings({
            bannerPalette: paletteId,
            bannerImageUrl: imageUrl,
            bannerImageOpacity: imageOpacity,
          });
        }}
      />
    </div>
  );
};
