import React, { useState } from 'react';
import {
  Award,
  Plus,
  CheckCircle2,
  Clock,
  Sparkles,
  Camera,
  MessageSquare,
  Gift,
  ThumbsUp,
  XCircle,
  Trophy,
  Medal,
  Calendar,
  X,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { compressImage } from '../../services/imageCompression';

export const ChallengesView: React.FC = () => {
  const {
    currentUser,
    users,
    challenges,
    submissions,
    createChallenge,
    submitChallenge,
    reviewSubmission,
    isAdmin,
  } = useApp();

  // Estados de modales
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showSubmitModal, setShowSubmitModal] = useState<string | null>(null);

  // Formulario de creación
  const [newTitle, setNewTitle] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newPoints, setNewPoints] = useState(50);
  const [newReward, setNewReward] = useState('Elegir dinámica del sábado');
  const [newEndDate, setNewEndDate] = useState(
    new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0]
  );

  // Formulario de entrega
  const [submitComment, setSubmitComment] = useState('');
  const [submitImage, setSubmitImage] = useState<string>('');
  const [isCompressing, setIsCompressing] = useState(false);

  // Ranking ordenado por puntos
  const sortedRanking = [...users].sort((a, b) => b.points - a.points);

  const activeChallenge = challenges.find((c) => c.isActive) || challenges[0];
  const mySubmission = submissions.find(
    (s) => s.challengeId === activeChallenge?.id && s.userId === currentUser.id
  );

  const handleImagePick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setIsCompressing(true);
      const res = await compressImage(file, { maxWidth: 800, maxHeight: 800, quality: 0.75 });
      setSubmitImage(res.dataUrl);
    } catch (err) {
      console.error(err);
    } finally {
      setIsCompressing(false);
    }
  };

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newDescription.trim()) return;

    createChallenge({
      title: newTitle.trim(),
      description: newDescription.trim(),
      points: Number(newPoints),
      reward: newReward.trim(),
      startDate: new Date().toISOString().split('T')[0],
      endDate: newEndDate,
    });

    setNewTitle('');
    setNewDescription('');
    setShowCreateModal(false);
  };

  const handleSubmissionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeChallenge) return;

    submitChallenge(activeChallenge.id, submitComment.trim() || undefined, submitImage || undefined);
    setSubmitComment('');
    setSubmitImage('');
    setShowSubmitModal(null);
  };

  return (
    <div className="space-y-6 pb-20 animate-in fade-in">
      {/* Encabezado del módulo */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400">
              <Award className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
              Retos Semanales y Recompensas
            </h1>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Pequeñas acciones cotidianas con espíritu vicenciano para crecer en comunidad.
          </p>
        </div>

        {isAdmin && (
          <button
            onClick={() => setShowCreateModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow-md transition active:scale-95 shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Crear Nuevo Reto</span>
          </button>
        )}
      </div>

      {/* Reto Activo de la Semana */}
      {activeChallenge && (
        <div className="p-6 rounded-3xl bg-gradient-to-br from-blue-900 via-indigo-900 to-blue-950 text-white shadow-xl shadow-blue-950/20">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
            <span className="px-3 py-1 rounded-full bg-amber-400 text-slate-950 font-extrabold text-[10px] uppercase tracking-wider">
              ⭐ Reto Activo de la Semana
            </span>
            <span className="text-xs text-blue-200 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" />
              Hasta: {new Date(activeChallenge.endDate).toLocaleDateString('es-ES', { day: 'numeric', month: 'short' })}
            </span>
          </div>

          <h2 className="text-lg sm:text-xl font-extrabold tracking-tight">
            {activeChallenge.title}
          </h2>
          <p className="mt-2 text-xs sm:text-sm text-blue-100 leading-relaxed max-w-2xl">
            {activeChallenge.description}
          </p>

          <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-xl">
            <div className="p-3 rounded-2xl bg-white/10 backdrop-blur-md border border-white/10 flex items-center gap-3">
              <Sparkles className="w-5 h-5 text-amber-400 shrink-0" />
              <div>
                <span className="block text-[10px] text-blue-200 uppercase font-semibold">Puntos en juego</span>
                <span className="text-base font-extrabold text-white">+{activeChallenge.points} Puntos</span>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-white/10 backdrop-blur-md border border-white/10 flex items-center gap-3">
              <Gift className="w-5 h-5 text-amber-400 shrink-0" />
              <div>
                <span className="block text-[10px] text-blue-200 uppercase font-semibold">Recompensa</span>
                <span className="text-xs font-bold text-white line-clamp-1">{activeChallenge.reward}</span>
              </div>
            </div>
          </div>

          {/* Estado de participación del usuario actual */}
          <div className="mt-6 pt-4 border-t border-white/15 flex flex-wrap items-center justify-between gap-4">
            <div>
              {mySubmission ? (
                <div className="flex items-center gap-2">
                  {mySubmission.status === 'approved' ? (
                    <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 font-bold text-xs border border-emerald-400/30">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      ¡Reto Aprobado! (+{activeChallenge.points} pts)
                    </span>
                  ) : mySubmission.status === 'pending' ? (
                    <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 font-bold text-xs border border-amber-400/30">
                      <Clock className="w-4 h-4 text-amber-400" />
                      Entrega en revisión por el coordinador
                    </span>
                  ) : (
                    <span className="text-xs text-red-300 font-bold">Entrega rechazada. Puedes intentar nuevamente.</span>
                  )}
                </div>
              ) : (
                <span className="text-xs text-blue-200">¿Ya realizaste este reto? Comparte tu experiencia.</span>
              )}
            </div>

            {!mySubmission && (
              <button
                onClick={() => setShowSubmitModal(activeChallenge.id)}
                className="px-5 py-2.5 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs shadow-lg active:scale-95 transition"
              >
                Marcar como Cumplido
              </button>
            )}
          </div>
        </div>
      )}

      {/* Entregas y Aprobaciones del Coordinador / Admin */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-blue-600" />
              Evidencias y Entregas de la Comunidad
            </h3>
            <span className="text-xs text-slate-500">{submissions.length} entregas</span>
          </div>

          <div className="space-y-3">
            {submissions.map((sub) => {
              const liveAuthor = users.find((u) => u.id === sub.userId);
              const authorAvatar = liveAuthor?.avatarUrl || sub.userAvatar;
              const authorName = liveAuthor?.name || sub.userName;
              return (
              <div
                key={sub.id}
                className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <img
                      src={authorAvatar}
                      alt={authorName}
                      className="w-9 h-9 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-700"
                    />
                    <div>
                      <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                        {authorName}
                      </h4>
                      <p className="text-[10px] text-slate-400">
                        {new Date(sub.submittedAt).toLocaleDateString('es-ES', {
                          day: 'numeric',
                          month: 'short',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </p>
                    </div>
                  </div>

                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      sub.status === 'approved'
                        ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300'
                        : sub.status === 'pending'
                        ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300'
                        : 'bg-red-100 dark:bg-red-950/60 text-red-800 dark:text-red-300'
                    }`}
                  >
                    {sub.status === 'approved' ? '✓ Aprobado' : sub.status === 'pending' ? '⏳ Pendiente' : 'Rechazado'}
                  </span>
                </div>

                {sub.comment && (
                  <p className="mt-2.5 text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                    "{sub.comment}"
                  </p>
                )}

                {sub.imageUrl && (
                  <div className="mt-3 rounded-2xl overflow-hidden max-h-60 bg-slate-100 dark:bg-slate-800 border border-slate-100 dark:border-slate-800">
                    <img
                      src={sub.imageUrl}
                      alt="Evidencia"
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}

                {/* Acciones para el Administrador / Coordinador */}
                {isAdmin && sub.status === 'pending' && (
                  <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2">
                    <button
                      onClick={() => reviewSubmission(sub.id, 'rejected')}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-xl border border-red-200 text-red-600 hover:bg-red-50 text-xs font-semibold"
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      Rechazar
                    </button>
                    <button
                      onClick={() => reviewSubmission(sub.id, 'approved')}
                      className="flex items-center gap-1 px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow transition active:scale-95"
                    >
                      <ThumbsUp className="w-3.5 h-3.5" />
                      Aprobar y Asignar Puntos
                    </button>
                  </div>
                )}
              </div>
              );
            })}
          </div>
        </div>

        {/* Podio / Ranking Amistoso e Insignias */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Trophy className="w-4 h-4 text-amber-500" />
              Ranking Amistoso JMV
            </h3>
            <span className="text-xs text-slate-500">Puntos de servicio</span>
          </div>

          <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
            {sortedRanking.map((user, idx) => (
              <div
                key={user.id}
                className={`flex items-center justify-between p-2.5 rounded-2xl transition ${
                  user.id === currentUser.id
                    ? 'bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900/50'
                    : 'hover:bg-slate-50 dark:hover:bg-slate-800/50'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <span
                    className={`w-6 h-6 rounded-full flex items-center justify-center font-black text-xs ${
                      idx === 0
                        ? 'bg-amber-400 text-slate-950 shadow'
                        : idx === 1
                        ? 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                        : idx === 2
                        ? 'bg-amber-700 text-white'
                        : 'text-slate-400 text-xs'
                    }`}
                  >
                    {idx + 1}
                  </span>
                  <img
                    src={user.avatarUrl}
                    alt={user.name}
                    className="w-8 h-8 rounded-full object-cover"
                  />
                  <div>
                    <h5 className="text-xs font-bold text-slate-900 dark:text-white line-clamp-1">
                      {user.name} {user.id === currentUser.id && '· Tú'}
                    </h5>
                    <div className="flex items-center gap-1 text-[10px] text-slate-400">
                      {user.badges.slice(0, 2).map((b) => (
                        <span key={b} className="capitalize">
                          {b === 'constancia' ? '⭐ Constancia' : b === 'servicio' ? '🤝 Servicio' : '💛 Alegría'}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <span className="block text-sm font-extrabold text-blue-900 dark:text-blue-400 tabular-nums">
                    {user.points}
                  </span>
                  <span className="text-[9px] text-slate-400 uppercase font-semibold">pts</span>
                </div>
              </div>
            ))}
          </div>

          {/* Insignias de mérito vicenciano */}
          <div className="p-4 rounded-3xl bg-amber-500/10 dark:bg-amber-500/5 border border-amber-500/20 text-xs">
            <h4 className="font-bold text-amber-800 dark:text-amber-400 flex items-center gap-1.5 mb-2">
              <Medal className="w-4 h-4" /> Insignias para Desbloquear
            </h4>
            <ul className="space-y-1.5 text-slate-700 dark:text-slate-300 text-[11px]">
              <li>⭐ <strong>Constancia:</strong> Asistir a 4 reuniones consecutivas (200 pts)</li>
              <li>🤝 <strong>Servicio Vicenciano:</strong> Cumplir 3 retos solidarios (350 pts)</li>
              <li>🕊️ <strong>Oración Fiel:</strong> Participar activamente en el muro de oración</li>
              <li>💛 <strong>Alegría Mariana:</strong> Insignia de bienvenida a todos los integrantes</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Modal: Crear Nuevo Reto (Admin) */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 animate-in fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                Crear Nuevo Reto Semanal
              </h3>
              <button onClick={() => setShowCreateModal(false)} className="text-slate-400">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Título del reto *
                </label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="Ej: Misión de la Sonrisa"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Descripción de la acción concreta *
                </label>
                <textarea
                  required
                  rows={3}
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  placeholder="Describe qué deben hacer los jóvenes..."
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Puntos
                  </label>
                  <input
                    type="number"
                    min="10"
                    max="100"
                    value={newPoints}
                    onChange={(e) => setNewPoints(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Fecha límite
                  </label>
                  <input
                    type="date"
                    value={newEndDate}
                    onChange={(e) => setNewEndDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Recompensa visible *
                </label>
                <input
                  type="text"
                  required
                  value={newReward}
                  onChange={(e) => setNewReward(e.target.value)}
                  placeholder="Ej: Elegir el juego del sábado + Insignia"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow mt-2"
              >
                Publicar Reto para el Grupo
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Enviar Entrega de Reto */}
      {showSubmitModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 animate-in fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                Marcar Reto como Cumplido
              </h3>
              <button onClick={() => setShowSubmitModal(null)} className="text-slate-400">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmissionSubmit} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Comentario o testimonio (opcional)
                </label>
                <textarea
                  rows={3}
                  value={submitComment}
                  onChange={(e) => setSubmitComment(e.target.value)}
                  placeholder="Cuéntanos cómo fue tu experiencia..."
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Foto de evidencia (opcional, comprimida para internet lento)
                </label>
                {submitImage ? (
                  <div className="relative rounded-2xl overflow-hidden h-36 bg-slate-100">
                    <img src={submitImage} alt="Evidencia" className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => setSubmitImage('')}
                      className="absolute top-2 right-2 p-1 rounded-full bg-black/60 text-white"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <label className="cursor-pointer border-2 border-dashed border-slate-200 dark:border-slate-700 hover:border-blue-500 rounded-2xl p-4 flex flex-col items-center justify-center gap-1.5 transition text-slate-500">
                    <Camera className="w-6 h-6 text-slate-400" />
                    <span className="font-semibold text-xs">
                      {isCompressing ? 'Comprimiendo imagen...' : 'Seleccionar foto'}
                    </span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImagePick}
                      className="hidden"
                    />
                  </label>
                )}
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow mt-2"
              >
                Enviar al Coordinador
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
