import React, { useState, useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { TopBar } from './components/Navigation/TopBar';
import { BottomNav } from './components/Navigation/BottomNav';
import { HomeView } from './components/Home/HomeView';
import { ChallengesView } from './components/Challenges/ChallengesView';
import { FeesView } from './components/Fees/FeesView';
import { ChatView } from './components/Chat/ChatView';
import { CalendarView } from './components/Calendar/CalendarView';
import { SecretFriendView } from './components/SecretFriend/SecretFriendView';
import { PrayerWallView } from './components/Prayers/PrayerWallView';
import { BirthdaysView } from './components/Birthdays/BirthdaysView';
import { GalleryView } from './components/Gallery/GalleryView';
import { ServiceWallView } from './components/Service/ServiceWallView';
import { AttendanceView } from './components/Attendance/AttendanceView';
import { PollsView } from './components/Polls/PollsView';
import { AdminDashboard } from './components/Admin/AdminDashboard';
import { MoreMenuView } from './components/Menu/MoreMenuView';
import { AuthModal } from './components/Auth/AuthModal';
import { SupabaseNetlifyGuide } from './components/Guide/SupabaseNetlifyGuide';
import { OfflineIndicator } from './components/Common/OfflineIndicator';
import { MobileSidebar } from './components/Navigation/MobileSidebar';
import { MemberProfileView } from './components/Profile/MemberProfileView';

function AppContent() {
  const [currentTab, setCurrentTab] = useState<string>('inicio');
  const {
    currentUser,
    isAuthenticated,
    showSupabaseGuide,
    setShowSupabaseGuide,
    showAuthModal,
    setShowAuthModal,
    authModalMode,
    setAuthModalMode,
  } = useApp();

  useEffect(() => {
    if (!isAuthenticated) {
      setCurrentTab('inicio');
    }
  }, [isAuthenticated]);

  useEffect(() => {
    if (currentTab === 'admin' && currentUser?.role !== 'admin') {
      setCurrentTab('inicio');
    }
  }, [currentUser?.id, currentUser?.role, currentTab]);

  const handleOpenRegister = () => {
    setAuthModalMode('register');
    setShowAuthModal(true);
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen max-w-full overflow-x-hidden bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col">
        <OfflineIndicator />
        <AuthModal
          isOpen={true}
          onClose={() => {}}
          initialMode={authModalMode}
          isFullScreenGate={true}
        />
      </div>
    );
  }

  const renderActiveView = () => {
    switch (currentTab) {
      case 'inicio':
        return (
          <HomeView
            onNavigateTab={(tab) => setCurrentTab(tab)}
            onOpenRegister={handleOpenRegister}
          />
        );
      case 'retos':
        return <ChallengesView />;
      case 'cuotas':
        return <FeesView />;
      case 'chat':
        return <ChatView />;
      case 'actividades':
        return <CalendarView />;
      case 'amigo-secreto':
        return <SecretFriendView />;
      case 'oracion':
        return <PrayerWallView />;
      case 'cumpleanios':
        return <BirthdaysView onNavigateToChat={() => setCurrentTab('chat')} />;
      case 'galeria':
        return <GalleryView />;
      case 'servicio':
        return <ServiceWallView />;
      case 'asistencia':
        return <AttendanceView />;
      case 'encuestas':
        return <PollsView />;
      case 'perfil':
        return (
          <MemberProfileView
            onNavigateTab={(tab) => setCurrentTab(tab)}
            onOpenRegister={handleOpenRegister}
          />
        );
      case 'admin':
        return <AdminDashboard onNavigateTab={(tab) => setCurrentTab(tab)} />;
      case 'menu':
        return <MoreMenuView onSelectModule={(mod) => setCurrentTab(mod)} />;
      default:
        return (
          <HomeView
            onNavigateTab={(tab) => setCurrentTab(tab)}
            onOpenRegister={handleOpenRegister}
          />
        );
    }
  };

  return (
    <div className="min-h-screen max-w-full overflow-x-hidden bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col transition-colors selection:bg-blue-600 selection:text-white">
      {/* Banner no intrusivo de estado offline */}
      <OfflineIndicator />

      {/* Barra superior fija de la app */}
      <TopBar
        currentTab={currentTab}
        onNavigateTab={(tab) => setCurrentTab(tab)}
        onOpenRegister={handleOpenRegister}
      />

      {/* Barra lateral deslizable en móvil con todas las opciones */}
      <MobileSidebar
        currentTab={currentTab}
        onNavigateTab={(tab) => setCurrentTab(tab)}
        onOpenRegister={handleOpenRegister}
      />

      {/* Contenido principal responsive */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 py-5 sm:py-6">
        {renderActiveView()}
      </main>

      {/* Barra de navegación inferior móvil (thumb-zone) */}
      <BottomNav
        currentTab={currentTab}
        onTabChange={(tab) => setCurrentTab(tab)}
      />

      {/* Modal Unificado de Autenticación (Cambio de Cuenta o Registro) */}
      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        initialMode={authModalMode}
      />

      <SupabaseNetlifyGuide
        isOpen={showSupabaseGuide}
        onClose={() => setShowSupabaseGuide(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
