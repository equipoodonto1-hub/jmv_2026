import React, { useState } from 'react';
import {
  Image as ImageIcon,
  Heart,
  MessageCircle,
  Plus,
  Camera,
  FolderPlus,
  Calendar,
  X,
  Upload,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { compressImage } from '../../services/imageCompression';

export const GalleryView: React.FC = () => {
  const {
    albums,
    photos,
    createAlbum,
    uploadPhoto,
    likePhoto,
    addPhotoComment,
    currentUser,
    isAdmin,
  } = useApp();

  const [selectedAlbumId, setSelectedAlbumId] = useState<string | 'all'>('all');
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showNewAlbumModal, setShowNewAlbumModal] = useState(false);

  // Estados de subida
  const [targetAlbumId, setTargetAlbumId] = useState(albums[0]?.id || '');
  const [uploadedImageUrl, setUploadedImageUrl] = useState('');
  const [photoCaption, setPhotoCaption] = useState('');
  const [isCompressing, setIsCompressing] = useState(false);

  // Estados nuevo álbum
  const [albumTitle, setAlbumTitle] = useState('');
  const [albumDescription, setAlbumDescription] = useState('');
  const [albumCoverUrl, setAlbumCoverUrl] = useState('');

  // Comentario activo
  const [commentInput, setCommentInput] = useState<Record<string, string>>({});

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsCompressing(true);
      const res = await compressImage(file, { maxWidth: 1200, maxHeight: 1200, quality: 0.8 });
      setUploadedImageUrl(res.dataUrl);
    } catch (err) {
      console.error(err);
    } finally {
      setIsCompressing(false);
    }
  };

  const handleUploadSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadedImageUrl || !targetAlbumId) return;

    uploadPhoto(targetAlbumId, uploadedImageUrl, photoCaption.trim() || undefined);
    setUploadedImageUrl('');
    setPhotoCaption('');
    setShowUploadModal(false);
  };

  const handleCreateAlbumSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!albumTitle.trim()) return;

    createAlbum(
      albumTitle.trim(),
      albumDescription.trim(),
      albumCoverUrl || 'https://images.unsplash.com/photo-1511632765486-a01980e01a18?auto=format&fit=crop&w=600&q=80'
    );
    setAlbumTitle('');
    setAlbumDescription('');
    setAlbumCoverUrl('');
    setShowNewAlbumModal(false);
  };

  const filteredPhotos =
    selectedAlbumId === 'all'
      ? photos
      : photos.filter((p) => p.albumId === selectedAlbumId);

  const selectedAlbum = albums.find((a) => a.id === selectedAlbumId);

  return (
    <div className="space-y-6 pb-20 animate-in fade-in">
      {/* Encabezado */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400">
              <ImageIcon className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
              Galería de Fotos JMV
            </h1>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Memorias fraternas organizadas por actividades. Con compresión automática para internet lento.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {isAdmin && (
            <button
              onClick={() => setShowNewAlbumModal(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 text-xs font-semibold transition"
            >
              <FolderPlus className="w-4 h-4" />
              <span>Nuevo Álbum</span>
            </button>
          )}
          <button
            onClick={() => setShowUploadModal(true)}
            className="flex items-center gap-1.5 px-4 py-2 rounded-2xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow-md transition active:scale-95"
          >
            <Camera className="w-4 h-4" />
            <span>Subir Foto</span>
          </button>
        </div>
      </div>

      {/* Selector de Álbumes */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        <button
          onClick={() => setSelectedAlbumId('all')}
          className={`px-4 py-2 rounded-2xl text-xs font-bold transition whitespace-nowrap ${
            selectedAlbumId === 'all'
              ? 'bg-blue-900 text-white shadow-md'
              : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50'
          }`}
        >
          Todas las Fotos ({photos.length})
        </button>

        {albums.map((album) => (
          <button
            key={album.id}
            onClick={() => setSelectedAlbumId(album.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-xs font-bold transition whitespace-nowrap ${
              selectedAlbumId === album.id
                ? 'bg-blue-900 text-white shadow-md'
                : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50'
            }`}
          >
            <span>{album.title}</span>
            <span className="text-[10px] opacity-70">({album.photoCount})</span>
          </button>
        ))}
      </div>

      {/* Grid de Fotos */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredPhotos.map((photo) => {
          const hasLiked = photo.likes.includes(currentUser.id);

          return (
            <div
              key={photo.id}
              className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden flex flex-col justify-between"
            >
              <div>
                <div className="relative aspect-4/3 bg-slate-100 dark:bg-slate-800 overflow-hidden">
                  <img
                    src={photo.url}
                    alt={photo.caption || 'Foto JMV'}
                    className="w-full h-full object-cover transition duration-300 hover:scale-105"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-3 left-3 px-2 py-0.5 rounded-full bg-black/60 backdrop-blur-md text-white text-[10px] font-semibold">
                    {photo.uploadedByName}
                  </div>
                </div>

                <div className="p-4 space-y-2">
                  {photo.caption && (
                    <p className="text-xs text-slate-800 dark:text-slate-200 leading-relaxed font-medium">
                      "{photo.caption}"
                    </p>
                  )}

                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span>
                      {new Date(photo.uploadedAt).toLocaleDateString('es-ES', {
                        day: 'numeric',
                        month: 'short',
                      })}
                    </span>
                    <button
                      onClick={() => likePhoto(photo.id)}
                      className={`flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-semibold transition active:scale-95 ${
                        hasLiked
                          ? 'bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 font-bold'
                          : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'
                      }`}
                    >
                      <Heart className={`w-3.5 h-3.5 ${hasLiked ? 'fill-red-600 text-red-600' : ''}`} />
                      <span>{photo.likes.length}</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Comentarios de la foto */}
              <div className="p-4 pt-0 border-t border-slate-100 dark:border-slate-800 mt-2 space-y-2">
                {photo.comments.length > 0 && (
                  <div className="space-y-1.5 max-h-24 overflow-y-auto text-[11px]">
                    {photo.comments.map((c) => (
                      <div key={c.id} className="text-slate-600 dark:text-slate-300">
                        <strong className="text-slate-900 dark:text-white mr-1">{c.userName}:</strong>
                        <span>{c.text}</span>
                      </div>
                    ))}
                  </div>
                )}

                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="text"
                    value={commentInput[photo.id] || ''}
                    onChange={(e) =>
                      setCommentInput({ ...commentInput, [photo.id]: e.target.value })
                    }
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        addPhotoComment(photo.id, commentInput[photo.id] || '');
                        setCommentInput({ ...commentInput, [photo.id]: '' });
                      }
                    }}
                    placeholder="Deja un comentario fraterno..."
                    className="flex-1 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-[11px] outline-none"
                  />
                  <button
                    onClick={() => {
                      addPhotoComment(photo.id, commentInput[photo.id] || '');
                      setCommentInput({ ...commentInput, [photo.id]: '' });
                    }}
                    className="px-2.5 py-1.5 rounded-xl bg-blue-900 text-white font-bold text-[11px]"
                  >
                    Enviar
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal: Subir Foto */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 animate-in fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                Subir Foto a la Galería
              </h3>
              <button onClick={() => setShowUploadModal(false)} className="text-slate-400">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleUploadSubmit} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Selecciona el Álbum *
                </label>
                <select
                  value={targetAlbumId}
                  onChange={(e) => setTargetAlbumId(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                >
                  {albums.map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.title}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Foto (comprimida automáticamente en tu celular) *
                </label>
                {uploadedImageUrl ? (
                  <div className="relative rounded-2xl overflow-hidden h-40 bg-slate-100">
                    <img src={uploadedImageUrl} alt="Preview" className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => setUploadedImageUrl('')}
                      className="absolute top-2 right-2 p-1 rounded-full bg-black/60 text-white"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <label className="cursor-pointer border-2 border-dashed border-slate-200 dark:border-slate-700 hover:border-blue-500 rounded-2xl p-6 flex flex-col items-center justify-center gap-1.5 transition text-slate-500">
                    <Upload className="w-6 h-6 text-slate-400" />
                    <span className="font-semibold">
                      {isCompressing ? 'Comprimiendo imagen...' : 'Selecciona foto desde galería o cámara'}
                    </span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                  </label>
                )}
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Pie de foto o recuerdo
                </label>
                <input
                  type="text"
                  value={photoCaption}
                  onChange={(e) => setPhotoCaption(e.target.value)}
                  placeholder="Ej: Compartiendo en el almuerzo solidario"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <button
                type="submit"
                disabled={!uploadedImageUrl || isCompressing}
                className="w-full py-2.5 rounded-xl bg-blue-900 hover:bg-blue-800 disabled:opacity-50 text-white font-bold text-xs shadow mt-2"
              >
                Publicar en la Galería
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Nuevo Álbum */}
      {showNewAlbumModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 animate-in fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                Crear Nuevo Álbum de Actividad
              </h3>
              <button onClick={() => setShowNewAlbumModal(false)} className="text-slate-400">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateAlbumSubmit} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Título del Álbum *
                </label>
                <input
                  type="text"
                  required
                  value={albumTitle}
                  onChange={(e) => setAlbumTitle(e.target.value)}
                  placeholder="Ej: Pascua Juvenil 2026"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Descripción
                </label>
                <textarea
                  rows={2}
                  value={albumDescription}
                  onChange={(e) => setAlbumDescription(e.target.value)}
                  placeholder="De qué trató la actividad..."
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow mt-2"
              >
                Crear Álbum
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
