import React from 'react';
import {
  Calendar,
  Image as ImageIcon,
  Heart,
  Gift,
  Cake,
  UserCheck,
  Vote,
  ShieldCheck,
  Database,
  BookOpen,
  ChevronRight,
  Sparkles,
  DollarSign,
  Palette,
  Settings,
  Users,
  User,
  UserPlus,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import marianMedalImg from '../../assets/images/jmv_marian_medal_1794117311829.jpg';

interface MenuItem {
  id: string;
  title: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  badge?: string;
  action?: () => void;
}

interface MenuSection {
  category: string;
  items: MenuItem[];
}

export const MoreMenuView: React.FC<{
  onSelectModule: (moduleId: string) => void;
}> = ({ onSelectModule }) => {
  const { users, isAdmin, isTreasurer, settings, setShowSupabaseGuide } = useApp();
  const pendingCount = users.filter((u) => u.status === 'pendiente_aprobacion').length;

  const menuSections: MenuSection[] = [
    {
      category: 'Vida Comunitaria y Espiritualidad',
      items: [
        {
          id: 'actividades',
          title: 'Calendario de Actividades',
          description: 'Reuniones, retiros espirituales y confirmación de asistencia.',
          icon: Calendar,
          color: 'text-blue-600 bg-blue-50 dark:bg-blue-950/50',
        },
        {
          id: 'oracion',
          title: 'Muro de Oración',
          description: 'Peticiones, agradecimientos e intenciones comunitarias.',
          icon: Heart,
          color: 'text-pink-600 bg-pink-50 dark:bg-pink-950/50',
        },
        {
          id: 'servicio',
          title: 'Muro de Experiencias de Servicio',
          description: 'Testimonios de caridad en asilos, comedores y misiones.',
          icon: Sparkles,
          color: 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/50',
        },
        {
          id: 'amigo-secreto',
          title: 'Amigo Secreto Semanal',
          description: '7 días de mensajes anónimos diarios y revelación festiva.',
          icon: Gift,
          color: 'text-purple-600 bg-purple-50 dark:bg-purple-950/50',
        },
      ],
    },
    {
      category: 'Participación y Memorias',
      items: [
        {
          id: 'galeria',
          title: 'Galería de Fotos',
          description: 'Álbumes por actividad con compresión automática.',
          icon: ImageIcon,
          color: 'text-teal-600 bg-teal-50 dark:bg-teal-950/50',
        },
        {
          id: 'cumpleanios',
          title: 'Cumpleaños del Mes',
          description: 'Felicitaciones marianas y tarjeta automática para el chat.',
          icon: Cake,
          color: 'text-rose-600 bg-rose-50 dark:bg-rose-950/50',
        },
        {
          id: 'asistencia',
          title: 'Asistencia y Constancia',
          description: 'Porcentajes por reunión y reconocimiento a la fidelidad.',
          icon: UserCheck,
          color: 'text-indigo-600 bg-indigo-50 dark:bg-indigo-950/50',
        },
        {
          id: 'encuestas',
          title: 'Encuestas Rápidas',
          description: 'Votación para fechas, actividades y camisetas.',
          icon: Vote,
          color: 'text-amber-600 bg-amber-50 dark:bg-amber-950/50',
        },
        {
          id: 'perfil',
          title: 'Mi Ficha y Panel Individual',
          description: 'Gestiona tus datos personales, historial de cuotas $1, retos y puntos vicencianos.',
          icon: User,
          color: 'text-blue-700 dark:text-blue-300 bg-blue-100 dark:bg-blue-950',
          badge: '🔒 Personal',
        },
      ],
    },
    {
      category: 'Administración y Soporte',
      items: [
        {
          id: 'admin',
          title: 'Panel de Solicitudes de Nuevos Integrantes',
          description: 'Revisa y autoriza el ingreso de jóvenes recién registrados en tu comunidad.',
          icon: UserPlus,
          color: 'text-emerald-700 dark:text-emerald-300 bg-emerald-100 dark:bg-emerald-950',
          badge: `${pendingCount} pend.`,
        },
        {
          id: 'admin',
          title: 'Gestión y Eliminación de Integrantes',
          description: 'Crea los jóvenes reales de tu parroquia y elimina los perfiles de ejemplo.',
          icon: Users,
          color: 'text-indigo-700 dark:text-indigo-300 bg-indigo-100 dark:bg-indigo-950',
          badge: '👥 Miembros',
        },
        {
          id: 'admin',
          title: 'Nombre, Parroquia y Logo Oficial',
          description: 'Personaliza el nombre de tu parroquia y sube el escudo o logo oficial.',
          icon: Palette,
          color: 'text-amber-700 dark:text-amber-300 bg-amber-100 dark:bg-amber-950',
          badge: '⚙️ Identidad',
        },
        {
          id: 'cuotas',
          title: 'Tesorería y Finanzas',
          description: 'Cuota de $1, ventas, registro de gastos en actividades y balance.',
          icon: DollarSign,
          color: 'text-emerald-700 dark:text-emerald-300 bg-emerald-100 dark:bg-emerald-950',
          badge: isTreasurer ? 'Encargado Economía' : undefined,
        },
        {
          id: 'admin',
          title: 'Panel del Administrador',
          description: 'Resumen gerencial, código de invitación, recordatorios y tesorería.',
          icon: ShieldCheck,
          color: 'text-blue-900 dark:text-blue-300 bg-blue-100 dark:bg-blue-950',
          badge: isAdmin ? 'Acceso Admin' : 'Solo lectura',
        },
        {
          id: 'guia-supabase',
          title: 'Guía Netlify + Supabase',
          description: 'Paso a paso para publicar gratis y conectar la base de datos.',
          icon: Database,
          color: 'text-teal-700 dark:text-teal-300 bg-teal-100 dark:bg-teal-950',
          action: () => setShowSupabaseGuide(true),
        },
      ],
    },
  ];

  return (
    <div className="space-y-6 pb-20 animate-in fade-in">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-2xl bg-white ring-2 ring-amber-400/70 p-1 shadow-sm shrink-0 flex items-center justify-center overflow-hidden">
          <img
            src={settings.logoUrl || marianMedalImg}
            alt={settings.groupName}
            className="w-full h-full object-contain rounded-xl"
          />
        </div>
        <div className="min-w-0">
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white truncate">
            {settings.groupName}
          </h1>
          <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400 truncate">
            {settings.parishName || 'Comunidad Parroquial'} · Módulos y herramientas comunitarias
          </p>
        </div>
      </div>

      <div className="space-y-6">
        {menuSections.map((sec) => (
          <div key={sec.category} className="space-y-3">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400 px-1">
              {sec.category}
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {sec.items.map((item, idx) => {
                const Icon = item.icon;

                return (
                  <button
                    key={`${item.id}-${idx}`}
                    onClick={() => {
                      if (item.action) item.action();
                      else onSelectModule(item.id);
                    }}
                    className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm hover:border-blue-400 dark:hover:border-blue-600 transition flex items-center justify-between text-left group active:scale-[0.98]"
                  >
                    <div className="flex items-center gap-3.5 mr-2">
                      <div
                        className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 ${item.color}`}
                      >
                        <Icon className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-blue-900 dark:group-hover:text-blue-400 transition">
                            {item.title}
                          </h3>
                          {item.badge && (
                            <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300">
                              {item.badge}
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-2">
                          {item.description}
                        </p>
                      </div>
                    </div>

                    <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 dark:group-hover:text-blue-400 shrink-0 transition" />
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
