import React from 'react';
import { Home, Award, DollarSign, MessageCircle, LayoutGrid } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const BottomNav: React.FC<{
  currentTab: string;
  onTabChange: (tab: string) => void;
}> = ({ currentTab, onTabChange }) => {
  const { submissions, isAdmin, toggleMobileSidebar } = useApp();

  const pendingSubmissionsCount = isAdmin
    ? submissions.filter((s) => s.status === 'pending').length
    : 0;

  const tabs = [
    { id: 'inicio', label: 'Inicio', icon: Home },
    { id: 'retos', label: 'Retos', icon: Award, badge: pendingSubmissionsCount > 0 ? pendingSubmissionsCount : undefined },
    { id: 'cuotas', label: 'Cuotas $1', icon: DollarSign },
    { id: 'chat', label: 'Chat', icon: MessageCircle },
    { id: 'menu', label: 'Menú', icon: LayoutGrid },
  ];

  return (
    <nav
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 pb-safe transition-colors"
      aria-label="Navegación principal de la app"
    >
      <div className="grid grid-cols-5 h-16 items-center max-w-lg mx-auto px-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => {
                if (tab.id === 'menu') {
                  toggleMobileSidebar();
                } else {
                  onTabChange(tab.id);
                }
              }}
              className="relative flex flex-col items-center justify-center min-h-[48px] py-1 text-center transition-transform active:scale-95"
              aria-label={tab.label}
              aria-current={isActive ? 'page' : undefined}
            >
              <div className="relative">
                <Icon
                  className={`w-5 h-5 transition-colors ${
                    isActive
                      ? 'text-blue-900 dark:text-blue-400 stroke-[2.5]'
                      : 'text-slate-500 dark:text-slate-400 stroke-[1.8]'
                  }`}
                />
                {tab.badge !== undefined && (
                  <span className="absolute -top-1.5 -right-2.5 min-w-[16px] h-4 px-1 rounded-full bg-amber-500 text-slate-950 font-extrabold text-[9px] flex items-center justify-center shadow">
                    {tab.badge}
                  </span>
                )}
              </div>
              <span
                className={`text-[10px] mt-1 font-semibold tracking-tight transition-colors ${
                  isActive
                    ? 'text-blue-900 dark:text-blue-400 font-bold'
                    : 'text-slate-500 dark:text-slate-400'
                }`}
              >
                {tab.label}
              </span>
              {isActive && (
                <div className="absolute top-0 w-8 h-0.5 rounded-full bg-blue-900 dark:bg-blue-400" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
