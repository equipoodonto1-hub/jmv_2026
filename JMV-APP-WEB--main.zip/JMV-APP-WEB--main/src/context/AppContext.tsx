import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import {
  UserProfile,
  UserRole,
  WeeklyChallenge,
  ChallengeSubmission,
  FeeWeek,
  FeePayment,
  ChatMessage,
  ActivityEvent,
  ServiceExperience,
  PhotoAlbum,
  PhotoItem,
  SecretFriendRound,
  SecretMessage,
  PrayerRequest,
  MeetingReminder,
  AttendanceSession,
  Poll,
  AdvisorReflection,
  FeeCampaign,
  ActivityExpense,
  PasswordRecoveryRequest,
  GroupSummary,
} from '../types';
import { StorageService, GroupSettings, EXAMPLE_ADMIN, normalizeGroupKey } from '../services/storage';
import {
  isSupabaseConfigured,
  getSupabaseClient,
  setSupabaseSessionToken,
  getSupabaseSessionToken,
} from '../services/supabaseClient';

const generateUuid = (): string => {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
};

const isUuid = (val: string): boolean =>
  /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(val);

interface AppContextType {
  // Autenticación y Perfil
  currentUser: UserProfile;
  users: UserProfile[];
  isAdmin: boolean;
  canManageFinances: boolean; // Permitido para Admin y Tesorero/a encargado/a de economía
  isTreasurer: boolean;
  treasurerUser: UserProfile | undefined;
  setTreasurerUser: (userId: string) => void;
  switchUser: (userId: string) => void;
  updateProfile: (profile: Partial<UserProfile>) => void;
  updateUser: (userId: string, data: Partial<UserProfile>) => void;
  deleteUser: (userId: string) => { success: boolean; error?: string };
  cleanExampleUsers: () => { success: boolean; removedCount: number; error?: string };
  
  // Autenticación con Correo y Cédula / Clave y Gestión por Grupo
  activeGroupKey: string;
  availableGroups: GroupSummary[];
  switchGroup: (groupKey: string) => Promise<void>;
  createGroupWorkspace: (data: {
    groupName: string;
    parishName?: string;
    invitationCode: string;
    logoUrl?: string;
    coordinatorName: string;
    coordinatorEmail: string;
    coordinatorCedula: string;
    coordinatorPassword?: string;
  }) => Promise<{ success: boolean; error?: string; groupKey?: string }>;
  isAuthenticated: boolean;
  loginWithCredentials: (
    emailOrCedula: string,
    passwordOrCedula: string,
    preferredGroupKey?: string
  ) => Promise<{ success: boolean; error?: string; user?: UserProfile; pendingApproval?: boolean }>;
  restoreExampleAdmin: () => UserProfile;
  requestPasswordReminder: (emailOrCedula: string) => Promise<{
    found: boolean;
    sentViaEmail: boolean;
    provider?: string;
    requiresCedulaVerification?: boolean;
    message: string;
    userEmail?: string;
    userName?: string;
  }>;
  verifyCedulaAndRecoverPassword: (
    email: string,
    cedula: string,
    newPassword?: string
  ) => Promise<{
    success: boolean;
    error?: string;
    recoveredPassword?: string;
    userName?: string;
    userEmail?: string;
  }>;
  passwordRequests: PasswordRecoveryRequest[];
  resolvePasswordRequest: (requestId: string) => void;
  logout: () => void;
  approveMember: (userId: string) => void;
  rejectMember: (userId: string) => void;
  refreshMembers: () => Promise<void>;
  bulkImportMembers: (list: Array<{ name: string; email: string; cedula: string; phone?: string; birthday?: string; role?: UserRole }>) => { success: boolean; count: number; errors: string[] };
  showAuthModal: boolean;
  setShowAuthModal: (show: boolean) => void;
  authModalMode: 'login' | 'register';
  setAuthModalMode: (mode: 'login' | 'register') => void;

  registerMember: (data: {
    name: string;
    email: string;
    cedula: string;
    password?: string;
    birthday: string;
    phone?: string;
    invitationCode: string;
    groupName?: string;
    groupKey?: string;
    avatarUrl?: string;
    imageConsentAccepted: boolean;
    isMinor?: boolean;
    tutorName?: string;
    tutorPhone?: string;
    serviceArea?: string;
    spiritualQuote?: string;
    emergencyContact?: string;
    role?: UserRole;
    autoApprove?: boolean;
  }) => Promise<{ success: boolean; error?: string; pendingApproval?: boolean; userName?: string; groupName?: string }>;

  // Tema y Preferencias
  theme: 'light' | 'dark';
  toggleTheme: () => void;

  // Ajustes del Grupo
  settings: GroupSettings;
  updateSettings: (newSettings: Partial<GroupSettings>) => void;

  // Retos Semanales
  challenges: WeeklyChallenge[];
  submissions: ChallengeSubmission[];
  createChallenge: (challenge: Omit<WeeklyChallenge, 'id' | 'createdBy' | 'isActive'>) => void;
  submitChallenge: (challengeId: string, comment?: string, imageUrl?: string) => void;
  reviewSubmission: (submissionId: string, status: 'approved' | 'rejected') => void;

  // Cuotas de 1 Dólar y Nuevas Semanas
  feeWeeks: FeeWeek[];
  feePayments: FeePayment[];
  addFeeWeek: () => void;
  markFeePayment: (userId: string, weekNumber: number, isPaid: boolean, note?: string) => void;
  exportFeesToCSV: () => void;

  // Campañas de Ventas, Inversión y Nuevas Cuotas (ej. Empanadas, Polladas, Rifas)
  feeCampaigns: FeeCampaign[];
  createFeeCampaign: (campaign: Omit<FeeCampaign, 'id' | 'createdAt' | 'createdBy' | 'isActive'>) => FeeCampaign;
  recordCampaignPayment: (
    campaignId: string,
    userId: string,
    quantity: number,
    amount: number,
    isPaid: boolean,
    note?: string,
    paymentType?: 'inversion' | 'venta',
    mode?: 'sumar' | 'reemplazar'
  ) => void;
  deleteCampaignSalePayment: (paymentId: string) => void;
  markCampaignSalePaid: (paymentId: string, isPaid: boolean) => void;
  toggleInvestmentPayment: (campaignId: string, userId: string, isPaid: boolean, amount?: number) => void;
  updateCampaignFinancials: (campaignId: string, data: { ingredientCosts?: number }) => void;
  deleteFeeCampaign: (campaignId: string) => void;
  cleanExampleCampaigns: () => number;

  // Registro de Gastos en Actividades (Egresos comunitarios)
  activityExpenses: ActivityExpense[];
  addActivityExpense: (expense: Omit<ActivityExpense, 'id' | 'createdAt' | 'registeredBy' | 'registeredById'>) => void;
  deleteActivityExpense: (expenseId: string) => void;

  // Chat Grupal
  chatMessages: ChatMessage[];
  sendMessage: (text: string, imageUrl?: string) => void;
  togglePinMessage: (messageId: string) => void;
  addMessageReaction: (messageId: string, emoji: string) => void;
  reportMessage: (messageId: string) => void;

  // Calendario y Asistencias
  activities: ActivityEvent[];
  createActivity: (activity: Omit<ActivityEvent, 'id' | 'attendees' | 'createdBy'>) => void;
  bulkCreateActivities: (events: Omit<ActivityEvent, 'id' | 'attendees' | 'createdBy'>[]) => void;
  rsvpActivity: (activityId: string, status: 'voy' | 'no_voy' | 'tal_vez') => void;
  attendanceSessions: AttendanceSession[];
  recordAttendance: (title: string, date: string, records: { userId: string; status: 'presente' | 'justificado' | 'ausente' }[]) => void;

  // Galería y Servicio
  albums: PhotoAlbum[];
  photos: PhotoItem[];
  createAlbum: (title: string, description: string, coverUrl: string) => void;
  uploadPhoto: (albumId: string, url: string, caption?: string) => void;
  likePhoto: (photoId: string) => void;
  addPhotoComment: (photoId: string, text: string) => void;

  serviceExperiences: ServiceExperience[];
  addServiceExperience: (item: Omit<ServiceExperience, 'id' | 'userId' | 'userName' | 'userAvatar' | 'likes' | 'reactions' | 'comments'>) => void;
  reactToService: (serviceId: string, reaction: 'oracion' | 'amor' | 'inspirador') => void;
  addServiceComment: (serviceId: string, text: string) => void;

  // Amigo Secreto Semanal
  secretRound: SecretFriendRound;
  secretMessages: SecretMessage[];
  startSecretFriendRound: (title: string, participantIds?: string[], durationDays?: number) => void;
  resetSecretFriendRound: () => void;
  sendSecretMessage: (text: string, dayNumber: number) => void;
  revealSecretFriends: () => void;
  mySecretTarget: UserProfile | null;

  // Muro de Oración
  prayers: PrayerRequest[];
  addPrayer: (title: string, description: string, type: 'peticion' | 'agradecimiento', isAnonymous: boolean) => void;
  joinPrayer: (prayerId: string) => void;

  // Recordatorios & Notificaciones
  reminders: MeetingReminder[];
  addReminder: (title: string, message: string, scheduledFor: string) => void;
  triggerPushNotification: (title: string, body: string) => void;

  // Encuestas y Reflexión
  polls: Poll[];
  votePoll: (pollId: string, optionId: string) => void;
  createPoll: (question: string, options: string[]) => void;
  reflection: AdvisorReflection;
  updateReflection: (data: Partial<AdvisorReflection>) => void;

  // Supabase Status
  supabaseConnected: boolean;
  showSupabaseGuide: boolean;
  setShowSupabaseGuide: (show: boolean) => void;
  triggerConfetti: () => void;

  // Barra Lateral Móvil (Drawer)
  isMobileSidebarOpen: boolean;
  setIsMobileSidebarOpen: (open: boolean) => void;
  toggleMobileSidebar: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Grupo activo y catálogo de grupos registrados
  const [activeGroupKey, setActiveGroupKey] = useState<string>(() => StorageService.getActiveGroupKey());
  const activeGroupKeyRef = useRef<string>(activeGroupKey);
  activeGroupKeyRef.current = activeGroupKey;
  const [availableGroups, setAvailableGroups] = useState<GroupSummary[]>(() => StorageService.getGroupsRegistry());

  // Estado de usuarios (aislado por grupo)
  const [users, setUsers] = useState<UserProfile[]>(() => StorageService.getUsers());
  const usersRef = useRef<UserProfile[]>(users);
  usersRef.current = users;
  const [currentUserId, setCurrentUserId] = useState<string>(() => StorageService.getCurrentUserId());
  
  // Tema claro / oscuro
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    const saved = localStorage.getItem('jmv_theme');
    if (saved === 'dark' || saved === 'light') return saved;
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  });

  // Ajustes generales del grupo activo
  const [settings, setSettings] = useState<GroupSettings>(() => StorageService.getSettings());
  const settingsRef = useRef<GroupSettings>(settings);
  settingsRef.current = settings;

  // Módulos principales (aislados por grupo)
  const [challenges, setChallenges] = useState<WeeklyChallenge[]>(() => StorageService.getChallenges());
  const [submissions, setSubmissions] = useState<ChallengeSubmission[]>(() => StorageService.getSubmissions());
  const [feeWeeks, setFeeWeeks] = useState<FeeWeek[]>(() => StorageService.getFeeWeeks());
  const [feePayments, setFeePayments] = useState<FeePayment[]>(() => StorageService.getFeePayments());
  const [feeCampaigns, setFeeCampaigns] = useState<FeeCampaign[]>(() => StorageService.getFeeCampaigns());
  const [activityExpenses, setActivityExpenses] = useState<ActivityExpense[]>(() => StorageService.getActivityExpenses());
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(() => StorageService.getChatMessages());
  const [activities, setActivities] = useState<ActivityEvent[]>(() => StorageService.getActivities());
  const [attendanceSessions, setAttendanceSessions] = useState<AttendanceSession[]>(() => StorageService.getAttendance());
  const [albums, setAlbums] = useState<PhotoAlbum[]>(() => StorageService.getPhotoAlbums());
  const [photos, setPhotos] = useState<PhotoItem[]>(() => StorageService.getPhotoItems());
  const [serviceExperiences, setServiceExperiences] = useState<ServiceExperience[]>(() => StorageService.getServiceExperiences());
  const [secretRound, setSecretRound] = useState<SecretFriendRound>(() => StorageService.getSecretFriendRound());
  const [secretMessages, setSecretMessages] = useState<SecretMessage[]>(() => StorageService.getSecretMessages());
  const [prayers, setPrayers] = useState<PrayerRequest[]>(() => StorageService.getPrayers());
  const [reminders, setReminders] = useState<MeetingReminder[]>(() => StorageService.getReminders());
  const [polls, setPolls] = useState<Poll[]>(() => StorageService.getPolls());
  const [reflection, setReflection] = useState<AdvisorReflection>(() => StorageService.getReflection());
  const [passwordRequests, setPasswordRequests] = useState<PasswordRecoveryRequest[]>(() =>
    StorageService.getPasswordRequests()
  );

  // Modal de Guía Supabase/Netlify
  const [showSupabaseGuide, setShowSupabaseGuide] = useState(false);
  const [supabaseConnected, setSupabaseConnected] = useState(isSupabaseConfigured());

  // Estado de autenticación y modales
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    const savedId = StorageService.getCurrentUserId();
    const initialUsers = StorageService.getUsers();
    return Boolean(savedId && initialUsers.some((u) => u.id === savedId));
  });
  const [showAuthModal, setShowAuthModal] = useState<boolean>(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register'>('login');

  // Barra lateral móvil (drawer)
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const toggleMobileSidebar = () => setIsMobileSidebarOpen((prev) => !prev);

  // Sincronizar clase .dark en el documento raíz
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('jmv_theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  const isRealCustomAvatar = (url?: string): boolean =>
    Boolean(url && !url.includes('api.dicebear.com'));

  const mergeUsersPreservingAvatars = (
    localList: UserProfile[],
    incomingList: UserProfile[]
  ): UserProfile[] => {
    const merged = [...localList];
    incomingList.forEach((ru) => {
      const idx = merged.findIndex(
        (lu) =>
          lu.id === ru.id ||
          (ru.email && lu.email.trim().toLowerCase() === ru.email.trim().toLowerCase()) ||
          (ru.cedula && lu.cedula.trim() === ru.cedula.trim())
      );
      if (idx >= 0) {
        const localUser = merged[idx];
        const chosenAvatar = isRealCustomAvatar(ru.avatarUrl)
          ? ru.avatarUrl
          : isRealCustomAvatar(localUser.avatarUrl)
          ? localUser.avatarUrl
          : ru.avatarUrl || localUser.avatarUrl;
        merged[idx] = {
          ...localUser,
          ...ru,
          password: ru.password || localUser.password,
          avatarUrl: chosenAvatar,
        };
      } else {
        merged.push(ru);
      }
    });
    return merged;
  };

  const rowMatchesGroup = (rowGroupKey: unknown, targetKey: string): boolean => {
    const cleanRowKey = rowGroupKey ? normalizeGroupKey(String(rowGroupKey)) : '';
    if (cleanRowKey && cleanRowKey === targetKey) return true;
    if (StorageService.isLegacyGroup(targetKey) && (!cleanRowKey || cleanRowKey === 'default')) {
      return true;
    }
    return false;
  };

  const mapSupabaseRowToUser = (row: any, fallbackGroupKey?: string): UserProfile => {
    const resolvedKey =
      row.group_key && String(row.group_key) !== 'default'
        ? normalizeGroupKey(row.group_key)
        : fallbackGroupKey || activeGroupKeyRef.current;
    return {
      id: String(row.id),
      name: String(row.name || 'Integrante'),
      email: String(row.email || '').trim().toLowerCase(),
      cedula: String(row.cedula || '').trim(),
      password: row.password ? String(row.password).trim() : undefined,
      groupKey: resolvedKey,
      groupName: row.group_name ? String(row.group_name) : settingsRef.current.groupName,
      status: row.status === 'pendiente_aprobacion' ? 'pendiente_aprobacion' : 'aprobado',
      role: row.role === 'admin' ? 'admin' : row.role === 'tesorero' ? 'tesorero' : 'integrante',
      isTreasurer: Boolean(row.is_treasurer) || row.role === 'tesorero' || row.role === 'admin',
      avatarUrl:
        row.avatar_url ||
        `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(row.name || 'JMV')}`,
      birthday: row.birthday || '2005-01-01',
      phone: row.phone || undefined,
      joinedAt: row.joined_at || new Date().toISOString().split('T')[0],
      points: Number(row.points ?? 50),
      badges: Array.isArray(row.badges) && row.badges.length > 0 ? row.badges : ['alegria'],
      serviceArea: row.service_area || undefined,
      spiritualQuote: row.spiritual_quote || undefined,
      imageConsentAccepted: row.image_consent_accepted !== false,
      isMinor: Boolean(row.is_minor),
      tutorName: row.tutor_name || undefined,
      tutorPhone: row.tutor_phone || undefined,
    };
  };

  const syncProfileToSupabase = async (
    user: UserProfile,
    explicitGroupKey?: string,
    includePassword = false
  ) => {
    const targetKey = explicitGroupKey || user.groupKey || activeGroupKeyRef.current;
    const client = getSupabaseClient(targetKey);
    if (!client) return;
    const payload: Record<string, any> = {
      group_key: targetKey,
      group_name: user.groupName || StorageService.getSettings(targetKey).groupName,
      name: user.name,
      email: user.email.trim().toLowerCase(),
      cedula: user.cedula.trim(),
      status: user.status,
      role: user.role,
      is_treasurer: Boolean(user.isTreasurer || user.role === 'tesorero' || user.role === 'admin'),
      avatar_url: user.avatarUrl,
      birthday: user.birthday || '2005-01-01',
      phone: user.phone || null,
      joined_at: user.joinedAt || new Date().toISOString().split('T')[0],
      points: user.points ?? 50,
      badges: user.badges || ['alegria'],
      service_area: user.serviceArea || 'Misión y Visitas',
      spiritual_quote: user.spiritualQuote || null,
      image_consent_accepted: user.imageConsentAccepted !== false,
      is_minor: Boolean(user.isMinor),
      tutor_name: user.tutorName || null,
      tutor_phone: user.tutorPhone || null,
    };
    if (includePassword && user.password && user.password.trim()) {
      payload.password = user.password.trim();
    }
    try {
      if (isUuid(user.id)) {
        await client.from('jmv_profiles').upsert({ id: user.id, ...payload }, { onConflict: 'id' });
      } else if (payload.email) {
        await client
          .from('jmv_profiles')
          .update(payload)
          .eq('email', payload.email)
          .eq('group_key', targetKey);
      }
    } catch (err) {
      console.warn('Supabase sync profile skipped:', err);
    }
  };

  const refreshMembers = async (targetGroupKey?: string) => {
    const resolvedKey = targetGroupKey || activeGroupKeyRef.current;
    const freshLocal = StorageService.getUsers(resolvedKey);
    let mergedList =
      resolvedKey === activeGroupKeyRef.current
        ? mergeUsersPreservingAvatars(usersRef.current, freshLocal)
        : freshLocal;

    const client = getSupabaseClient(resolvedKey);
    if (client && getSupabaseSessionToken(resolvedKey)) {
      try {
        const { data, error } = await client.from('jmv_profiles').select('*');
        if (!error && Array.isArray(data) && data.length > 0) {
          const remoteUsers = data
            .filter((row: any) => rowMatchesGroup(row.group_key, resolvedKey))
            .map((row: any) => mapSupabaseRowToUser(row, resolvedKey))
            .filter((u) => u.email || u.cedula);
          if (remoteUsers.length > 0) {
            mergedList = mergeUsersPreservingAvatars(mergedList, remoteUsers);
          }
        }
      } catch (err) {
        console.warn('Supabase refresh skipped:', err);
      }
    }

    StorageService.saveUsers(mergedList, resolvedKey);
    if (resolvedKey === activeGroupKeyRef.current) {
      usersRef.current = mergedList;
      setUsers(mergedList);
    }
  };

  const normalizeInvitationCode = (code?: string): string =>
    String(code || '')
      .replace(/[\s\u200B-\u200D\uFEFF]/g, '')
      .trim()
      .toUpperCase();

  const syncSettingsToRemote = async (nextSettings: GroupSettings, explicitGroupKey?: string) => {
    const targetKey = normalizeGroupKey(explicitGroupKey || nextSettings.groupKey || activeGroupKeyRef.current);
    try {
      void fetch('/api/group-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          groupKey: targetKey,
          groupName: nextSettings.groupName,
          parishName: nextSettings.parishName,
          logoUrl: nextSettings.logoUrl,
          invitationCode: normalizeInvitationCode(nextSettings.invitationCode),
          bannerPalette: nextSettings.bannerPalette,
          bannerImageUrl: nextSettings.bannerImageUrl,
          bannerImageOpacity: nextSettings.bannerImageOpacity,
        }),
      }).catch(() => {});
    } catch {
      // Ignorar si no hay backend activo (ej. modo offline)
    }

    const client = getSupabaseClient(targetKey);
    if (!client) return;
    const rowId = StorageService.isLegacyGroup(targetKey) ? 'default' : targetKey;
    try {
      await client.from('jmv_group_settings').upsert(
        {
          id: rowId,
          group_key: targetKey,
          group_name: nextSettings.groupName,
          parish_name: nextSettings.parishName || '',
          logo_url: nextSettings.logoUrl || null,
          invitation_code: normalizeInvitationCode(nextSettings.invitationCode) || 'JMV2026',
          hoodie_goal_amount: nextSettings.hoodieGoalAmount,
          hoodie_cost_per_person: nextSettings.hoodieCostPerPerson,
          advisor_name: nextSettings.advisorName || null,
          next_meeting_date: nextSettings.nextMeetingDate || null,
          meeting_location: nextSettings.meetingLocation || null,
          banner_palette: nextSettings.bannerPalette || 'azul-mariano',
          banner_image_url: nextSettings.bannerImageUrl || null,
          banner_image_opacity: nextSettings.bannerImageOpacity ?? 30,
          emailjs_service_id: nextSettings.emailjsServiceId || null,
          emailjs_template_id: nextSettings.emailjsTemplateId || null,
          emailjs_public_key: nextSettings.emailjsPublicKey || null,
          updated_at: new Date().toISOString(),
        },
        { onConflict: 'id' }
      );
    } catch (err) {
      console.warn('Supabase sync settings skipped:', err);
    }
  };

  const applySettingsRowToState = (settingsRow: any, targetKey: string) => {
    const baseLocal = StorageService.getSettings(targetKey);
    const mergedSettings: GroupSettings = {
      ...baseLocal,
      groupKey: targetKey,
      ...(settingsRow.group_name ? { groupName: settingsRow.group_name } : {}),
      ...(settingsRow.parish_name ? { parishName: settingsRow.parish_name } : {}),
      ...(settingsRow.logo_url ? { logoUrl: settingsRow.logo_url } : {}),
      ...(settingsRow.invitation_code
        ? { invitationCode: normalizeInvitationCode(settingsRow.invitation_code) }
        : {}),
      ...(settingsRow.hoodie_goal_amount ? { hoodieGoalAmount: Number(settingsRow.hoodie_goal_amount) } : {}),
      ...(settingsRow.hoodie_cost_per_person
        ? { hoodieCostPerPerson: Number(settingsRow.hoodie_cost_per_person) }
        : {}),
      ...(settingsRow.advisor_name ? { advisorName: settingsRow.advisor_name } : {}),
      ...(settingsRow.next_meeting_date ? { nextMeetingDate: settingsRow.next_meeting_date } : {}),
      ...(settingsRow.meeting_location ? { meetingLocation: settingsRow.meeting_location } : {}),
      ...(settingsRow.banner_palette ? { bannerPalette: settingsRow.banner_palette } : {}),
      ...(settingsRow.banner_image_url ? { bannerImageUrl: settingsRow.banner_image_url } : {}),
      ...(typeof settingsRow.banner_image_opacity === 'number'
        ? { bannerImageOpacity: settingsRow.banner_image_opacity }
        : {}),
      ...(settingsRow.emailjs_service_id ? { emailjsServiceId: settingsRow.emailjs_service_id } : {}),
      ...(settingsRow.emailjs_template_id ? { emailjsTemplateId: settingsRow.emailjs_template_id } : {}),
      ...(settingsRow.emailjs_public_key ? { emailjsPublicKey: settingsRow.emailjs_public_key } : {}),
    };
    StorageService.saveSettings(mergedSettings, targetKey);
    if (targetKey === activeGroupKeyRef.current) {
      settingsRef.current = mergedSettings;
      setSettings(mergedSettings);
    }
    setAvailableGroups(StorageService.getGroupsRegistry());
  };

  const reloadWorkspaceForGroup = (nextGroupKey: string) => {
    const cleanKey = StorageService.setActiveGroupKey(nextGroupKey);
    activeGroupKeyRef.current = cleanKey;
    setActiveGroupKey(cleanKey);

    const nextUsers = StorageService.getUsers(cleanKey);
    usersRef.current = nextUsers;
    setUsers(nextUsers);

    const nextSettings = StorageService.getSettings(cleanKey);
    settingsRef.current = nextSettings;
    setSettings(nextSettings);

    setChallenges(StorageService.getChallenges(cleanKey));
    setSubmissions(StorageService.getSubmissions(cleanKey));
    setFeeWeeks(StorageService.getFeeWeeks(cleanKey));
    setFeePayments(StorageService.getFeePayments(cleanKey));
    setFeeCampaigns(StorageService.getFeeCampaigns(cleanKey));
    setActivityExpenses(StorageService.getActivityExpenses(cleanKey));
    setChatMessages(StorageService.getChatMessages(cleanKey));
    setActivities(StorageService.getActivities(cleanKey));
    setAttendanceSessions(StorageService.getAttendance(cleanKey));
    setAlbums(StorageService.getPhotoAlbums(cleanKey));
    setPhotos(StorageService.getPhotoItems(cleanKey));
    setServiceExperiences(StorageService.getServiceExperiences(cleanKey));
    setSecretRound(StorageService.getSecretFriendRound(cleanKey));
    setSecretMessages(StorageService.getSecretMessages(cleanKey));
    setPrayers(StorageService.getPrayers(cleanKey));
    setReminders(StorageService.getReminders(cleanKey));
    setPolls(StorageService.getPolls(cleanKey));
    setReflection(StorageService.getReflection(cleanKey));
    setPasswordRequests(StorageService.getPasswordRequests(cleanKey));

    const savedUid = StorageService.getCurrentUserId(cleanKey);
    const validUser = savedUid ? nextUsers.find((u) => u.id === savedUid) : undefined;
    const canEnter =
      Boolean(validUser) && (validUser?.status !== 'pendiente_aprobacion' || validUser?.role === 'admin');
    setCurrentUserId(canEnter && validUser ? validUser.id : '');
    setIsAuthenticated(canEnter);
    setAvailableGroups(StorageService.getGroupsRegistry());
  };

  const switchGroup = async (groupKey: string) => {
    const cleanKey = normalizeGroupKey(groupKey);
    reloadWorkspaceForGroup(cleanKey);

    // Hidratar desde servidor local y Supabase para ese grupo específico
    try {
      const res = await fetch(`/api/group-settings?groupKey=${encodeURIComponent(cleanKey)}`);
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data?.groups)) {
          data.groups.forEach((g: any) => {
            if (g?.groupKey && g?.groupName) {
              StorageService.upsertGroupRegistry({
                groupKey: g.groupKey,
                groupName: g.groupName,
                parishName: g.parishName,
                logoUrl: g.logoUrl,
                updatedAt: g.updatedAt,
              });
            }
          });
        }
        if (data?.groupName || data?.parishName || data?.logoUrl) {
          const updated: GroupSettings = {
            ...StorageService.getSettings(cleanKey),
            groupKey: cleanKey,
            ...(data.groupName ? { groupName: data.groupName } : {}),
            ...(data.parishName ? { parishName: data.parishName } : {}),
            ...(data.logoUrl ? { logoUrl: data.logoUrl } : {}),
            ...(data.bannerPalette ? { bannerPalette: data.bannerPalette } : {}),
            ...(data.bannerImageUrl ? { bannerImageUrl: data.bannerImageUrl } : {}),
            ...(typeof data.bannerImageOpacity === 'number'
              ? { bannerImageOpacity: data.bannerImageOpacity }
              : {}),
          };
          StorageService.saveSettings(updated, cleanKey);
          if (cleanKey === activeGroupKeyRef.current) {
            settingsRef.current = updated;
            setSettings(updated);
          }
        }
      }
    } catch {
      // Ignorar si offline
    }

    await refreshMembers(cleanKey);

    const client = getSupabaseClient(cleanKey);
    if (client) {
      try {
        const { data: pubGroups } = await client.rpc('jmv_list_public_groups');
        if (Array.isArray(pubGroups)) {
          const match = pubGroups.find((g: any) => normalizeGroupKey(g.group_key) === cleanKey);
          if (match) {
            applySettingsRowToState(match, cleanKey);
          }
        }
        if (getSupabaseSessionToken(cleanKey)) {
          const { data: fullSettings } = await client.rpc('jmv_get_group_settings', {
            p_group_key: cleanKey,
          });
          if (fullSettings) {
            applySettingsRowToState(fullSettings, cleanKey);
          }
        }
      } catch {
        // Ignorar
      }
    }

    setAvailableGroups(StorageService.getGroupsRegistry());
  };

  useEffect(() => {
    const handleStorageChange = (event: StorageEvent) => {
      const currentKey = activeGroupKeyRef.current;
      const expectedUsersKey = StorageService.scopedKey('jmv_users_v1', currentKey);
      const expectedSettingsKey = StorageService.scopedKey('jmv_group_settings_v1', currentKey);
      if (event.key === expectedUsersKey) {
        const freshLocal = StorageService.getUsers(currentKey);
        usersRef.current = freshLocal;
        setUsers(freshLocal);
      }
      if (event.key === expectedSettingsKey) {
        const freshSettings = StorageService.getSettings(currentKey);
        settingsRef.current = freshSettings;
        setSettings(freshSettings);
      }
      if (event.key === 'jmv_groups_registry_v1') {
        setAvailableGroups(StorageService.getGroupsRegistry());
      }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  useEffect(() => {
    let cancelled = false;
    const currentKey = activeGroupKeyRef.current;
    (async () => {
      const client = getSupabaseClient(currentKey);
      if (client) {
        setSupabaseConnected(true);
        try {
          const { data: pubGroups, error: pubError } = await client.rpc('jmv_list_public_groups');
          if (!pubError && Array.isArray(pubGroups) && !cancelled) {
            pubGroups.forEach((row: any) => {
              const rKey = normalizeGroupKey(
                row.group_key && row.group_key !== 'default'
                  ? row.group_key
                  : row.group_name || StorageService.getLegacyGroupKey()
              );
              if (row.group_name) {
                StorageService.upsertGroupRegistry({
                  groupKey: rKey,
                  groupName: row.group_name,
                  parishName: row.parish_name,
                  logoUrl: row.logo_url,
                  updatedAt: row.updated_at,
                });
              }
              if (rKey === currentKey || (StorageService.isLegacyGroup(currentKey) && row.group_key === 'default')) {
                applySettingsRowToState(row, currentKey);
              }
            });
          }

          if (getSupabaseSessionToken(currentKey) && !cancelled) {
            const [{ data: fullSettings }, { data: profilesData, error: profilesError }] = await Promise.all([
              client.rpc('jmv_get_group_settings', { p_group_key: currentKey }),
              client.from('jmv_profiles').select('*'),
            ]);

            if (fullSettings && !cancelled) {
              applySettingsRowToState(fullSettings, currentKey);
            }

            if (!profilesError && Array.isArray(profilesData) && !cancelled && profilesData.length > 0) {
              const remoteUsers = profilesData
                .filter((row: any) => rowMatchesGroup(row.group_key, currentKey))
                .map((row: any) => mapSupabaseRowToUser(row, currentKey))
                .filter((u) => u.email || u.cedula);
              if (remoteUsers.length > 0 && currentKey === activeGroupKeyRef.current) {
                setUsers((prev) => {
                  const merged = mergeUsersPreservingAvatars(prev, remoteUsers);
                  StorageService.saveUsers(merged, currentKey);
                  usersRef.current = merged;
                  return merged;
                });
              }
            }
          }
        } catch (err) {
          console.warn('Supabase initial load skipped:', err);
        }
      }

      // Sincronizar catálogo público y configuración del grupo activo con el servidor local
      try {
        const res = await fetch(`/api/group-settings?groupKey=${encodeURIComponent(currentKey)}`);
        if (res.ok && !cancelled) {
          const data = await res.json();
          if (Array.isArray(data?.groups)) {
            data.groups.forEach((g: any) => {
              if (g?.groupKey && g?.groupName) {
                StorageService.upsertGroupRegistry({
                  groupKey: g.groupKey,
                  groupName: g.groupName,
                  parishName: g.parishName,
                  logoUrl: g.logoUrl,
                  updatedAt: g.updatedAt,
                });
              }
            });
            setAvailableGroups(StorageService.getGroupsRegistry());
          }
          if ((data?.groupName || data?.parishName || data?.logoUrl) && currentKey === activeGroupKeyRef.current) {
            setSettings((prev) => {
              const updated: GroupSettings = {
                ...prev,
                groupKey: currentKey,
                ...(data.groupName ? { groupName: data.groupName } : {}),
                ...(data.parishName ? { parishName: data.parishName } : {}),
                ...(data.logoUrl ? { logoUrl: data.logoUrl } : {}),
                ...(data.bannerPalette ? { bannerPalette: data.bannerPalette } : {}),
                ...(data.bannerImageUrl ? { bannerImageUrl: data.bannerImageUrl } : {}),
                ...(typeof data.bannerImageOpacity === 'number'
                  ? { bannerImageOpacity: data.bannerImageOpacity }
                  : {}),
              };
              settingsRef.current = updated;
              StorageService.saveSettings(updated, currentKey);
              return updated;
            });
          }
          if (!data?.hasInvitationCode) {
            const currentLocalSettings = StorageService.getSettings(currentKey);
            const currentId = StorageService.getCurrentUserId(currentKey);
            const currentLocalUser = usersRef.current.find((u) => u.id === currentId);
            if (currentLocalUser?.role === 'admin' && currentLocalSettings.invitationCode) {
              void syncSettingsToRemote(currentLocalSettings, currentKey);
            }
          }
        }
      } catch {
        // Ignorar si no hay backend
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [showSupabaseGuide]);

  const matchedUser = currentUserId ? users.find((u) => u.id === currentUserId) : undefined;
  const effectiveAuthenticated =
    isAuthenticated &&
    Boolean(matchedUser) &&
    (matchedUser?.status !== 'pendiente_aprobacion' || matchedUser?.role === 'admin');
  const currentUser = matchedUser || users[0] || EXAMPLE_ADMIN;
  const isAdmin = effectiveAuthenticated && currentUser?.role === 'admin';
  const isTreasurer = effectiveAuthenticated && (currentUser?.role === 'tesorero' || currentUser?.isTreasurer === true);
  const canManageFinances = isAdmin || isTreasurer;
  const treasurerUser = users.find((u) => u.role === 'tesorero' || u.isTreasurer);

  useEffect(() => {
    if (!isAdmin) return;
    const currentKey = activeGroupKeyRef.current;
    const active = settingsRef.current;
    void fetch('/api/group-settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        groupKey: currentKey,
        groupName: active.groupName,
        parishName: active.parishName,
        logoUrl: active.logoUrl,
        invitationCode: normalizeInvitationCode(active.invitationCode),
        bannerPalette: active.bannerPalette,
        bannerImageUrl: active.bannerImageUrl,
        bannerImageOpacity: active.bannerImageOpacity,
      }),
    }).catch(() => {});

    const client = getSupabaseClient(currentKey);
    if (client && getSupabaseSessionToken(currentKey)) {
      void (async () => {
        try {
          const { data } = await client.rpc('jmv_get_group_settings', { p_group_key: currentKey });
          if (!data) {
            await syncSettingsToRemote(active, currentKey);
          }
        } catch {
          // Ignorar error de red
        }
      })();
    }
  }, [isAdmin, activeGroupKey]);

  const setTreasurerUser = (userId: string) => {
    setUsers((prev) => {
      const updated: UserProfile[] = prev.map((u) => {
        if (u.id === userId) {
          const newRole: UserRole = u.role === 'admin' ? 'admin' : 'tesorero';
          return { ...u, role: newRole, isTreasurer: true };
        }
        if (u.role === 'tesorero') {
          const defaultRole: UserRole = 'integrante';
          return { ...u, role: defaultRole, isTreasurer: false };
        }
        return u;
      });
      StorageService.saveUsers(updated);
      return updated;
    });
    triggerConfetti();
  };

  const switchUser = (userId: string) => {
    setCurrentUserId(userId);
    StorageService.setCurrentUserId(userId);
    setIsAuthenticated(true);
  };

  const propagateUserIdentity = (userId: string, nextName: string, nextAvatar: string) => {
    setSubmissions((prev) => {
      let changed = false;
      const updated = prev.map((s) => {
        if (s.userId !== userId) return s;
        if (s.userName === nextName && s.userAvatar === nextAvatar) return s;
        changed = true;
        return { ...s, userName: nextName, userAvatar: nextAvatar };
      });
      if (changed) StorageService.saveSubmissions(updated);
      return changed ? updated : prev;
    });

    setChatMessages((prev) => {
      let changed = false;
      const updated = prev.map((m) => {
        if (m.userId !== userId) return m;
        if (m.userName === nextName && m.userAvatar === nextAvatar) return m;
        changed = true;
        return { ...m, userName: nextName, userAvatar: nextAvatar };
      });
      if (changed) StorageService.saveChatMessages(updated);
      return changed ? updated : prev;
    });

    setActivities((prev) => {
      let changed = false;
      const updated = prev.map((act) => {
        let actChanged = false;
        const nextAttendees = act.attendees.map((att) => {
          if (att.userId !== userId) return att;
          if (att.userName === nextName && att.userAvatar === nextAvatar) return att;
          actChanged = true;
          return { ...att, userName: nextName, userAvatar: nextAvatar };
        });
        if (!actChanged) return act;
        changed = true;
        return { ...act, attendees: nextAttendees };
      });
      if (changed) StorageService.saveActivities(updated);
      return changed ? updated : prev;
    });

    setServiceExperiences((prev) => {
      let changed = false;
      const updated = prev.map((exp) => {
        let expChanged = false;
        const nextExp = { ...exp };
        if (exp.userId === userId && (exp.userName !== nextName || exp.userAvatar !== nextAvatar)) {
          nextExp.userName = nextName;
          nextExp.userAvatar = nextAvatar;
          expChanged = true;
        }
        const nextComments = exp.comments.map((c) => {
          if (c.userId !== userId) return c;
          if (c.userName === nextName && c.userAvatar === nextAvatar) return c;
          expChanged = true;
          return { ...c, userName: nextName, userAvatar: nextAvatar };
        });
        if (expChanged) {
          nextExp.comments = nextComments;
          changed = true;
          return nextExp;
        }
        return exp;
      });
      if (changed) StorageService.saveServiceExperiences(updated);
      return changed ? updated : prev;
    });

    setFeePayments((prev) => {
      let changed = false;
      const updated = prev.map((p) => {
        if (p.userId !== userId || p.userName === nextName) return p;
        changed = true;
        return { ...p, userName: nextName };
      });
      if (changed) StorageService.saveFeePayments(updated);
      return changed ? updated : prev;
    });
  };

  const updateProfile = (data: Partial<UserProfile>) => {
    if (!effectiveAuthenticated) return;
    const nextUsers = usersRef.current.map((u) =>
      u.id === currentUser.id ? { ...u, ...data } : u
    );
    usersRef.current = nextUsers;
    setUsers(nextUsers);
    StorageService.saveUsers(nextUsers);
    const updatedUser = nextUsers.find((u) => u.id === currentUser.id);
    if (updatedUser) {
      void syncProfileToSupabase(updatedUser);
      propagateUserIdentity(updatedUser.id, updatedUser.name, updatedUser.avatarUrl);
    }
  };

  const triggerConfetti = () => {
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#1e3a8a', '#2563eb', '#f59e0b', '#ffffff'],
      });
    } catch (e) {
      // Ignorar si el navegador bloquea canvas
    }
  };

  const findCandidateInGroup = (list: UserProfile[], cleanId: string, cleanIdDigits: string): UserProfile | undefined =>
    list.find((u) => {
      const uEmail = (u.email || '').trim().toLowerCase();
      const uCedula = (u.cedula || '').trim().toLowerCase();
      const uCedulaDigits = uCedula.replace(/\D/g, '');
      return (
        uEmail === cleanId ||
        uCedula === cleanId ||
        (cleanIdDigits.length >= 6 && uCedulaDigits === cleanIdDigits)
      );
    });

  const checkPasswordMatch = (user: UserProfile, cleanPass: string): boolean => {
    const validPassword = (user.password || user.cedula || '').trim();
    const validCedula = (user.cedula || '').trim();
    const cleanPassDigits = cleanPass.replace(/\D/g, '');
    const validCedulaDigits = validCedula.replace(/\D/g, '');
    return (
      cleanPass === validPassword ||
      cleanPass === validCedula ||
      (cleanPassDigits.length >= 6 && cleanPassDigits === validCedulaDigits && cleanPass === cleanPassDigits)
    );
  };

  const loginWithCredentials = async (
    emailOrCedula: string,
    passwordOrCedula: string,
    preferredGroupKey?: string
  ) => {
    const cleanId = emailOrCedula.trim().toLowerCase();
    const cleanIdDigits = cleanId.replace(/\D/g, '');
    const cleanPass = passwordOrCedula.trim();

    if (!cleanId || !cleanPass) {
      return {
        success: false,
        error: 'Ingresa tu correo electrónico (o cédula) y tu contraseña o número de cédula.',
      };
    }

    const explicitGroupKey =
      preferredGroupKey && preferredGroupKey !== 'auto' ? normalizeGroupKey(preferredGroupKey) : '';
    let matchedGroupKey = explicitGroupKey || activeGroupKeyRef.current;

    const collectGroupCandidates = (targetKey: string): UserProfile[] => {
      const stored = StorageService.getUsers(targetKey);
      const map = new Map<string, UserProfile>();
      const base = targetKey === activeGroupKeyRef.current ? [...stored, ...usersRef.current] : stored;
      base.forEach((u) => map.set(u.id, u));
      return Array.from(map.values());
    };

    let allCandidates = collectGroupCandidates(matchedGroupKey);
    let user = findCandidateInGroup(allCandidates, cleanId, cleanIdDigits);

    // Si no eligió grupo explícito y no está en el grupo activo, buscar en los demás grupos registrados
    if (!user && !explicitGroupKey) {
      const reg = StorageService.getGroupsRegistry();
      for (const g of reg) {
        if (g.groupKey === matchedGroupKey) continue;
        const gCandidates = collectGroupCandidates(g.groupKey);
        const found = findCandidateInGroup(gCandidates, cleanId, cleanIdDigits);
        if (found && checkPasswordMatch(found, cleanPass)) {
          user = found;
          matchedGroupKey = g.groupKey;
          allCandidates = gCandidates;
          break;
        }
      }
      // Segundo pase si la clave está mal pero el usuario sí existe en otro grupo
      if (!user) {
        for (const g of reg) {
          if (g.groupKey === matchedGroupKey) continue;
          const gCandidates = collectGroupCandidates(g.groupKey);
          const found = findCandidateInGroup(gCandidates, cleanId, cleanIdDigits);
          if (found) {
            user = found;
            matchedGroupKey = g.groupKey;
            allCandidates = gCandidates;
            break;
          }
        }
      }
    }

    // Si Supabase está configurado, autenticar primero vía RPC segura (jmv_login con bcrypt + token de sesión RLS)
    if (isSupabaseConfigured()) {
      const client = getSupabaseClient(explicitGroupKey || matchedGroupKey);
      if (client) {
        try {
          const { data: loginRes, error: rpcError } = await client.rpc('jmv_login', {
            p_identifier: cleanId,
            p_password: cleanPass,
            p_group_key: explicitGroupKey || null,
          });

          if (!rpcError && loginRes) {
            if (loginRes.ok && loginRes.session_token && loginRes.profile) {
              const targetKey = normalizeGroupKey(loginRes.profile.group_key || matchedGroupKey);
              setSupabaseSessionToken(loginRes.session_token, targetKey);

              if (loginRes.group_settings) {
                applySettingsRowToState(loginRes.group_settings, targetKey);
              }

              const remoteUser = mapSupabaseRowToUser(loginRes.profile, targetKey);
              const existingInGroup = collectGroupCandidates(targetKey);
              const mergedUsers = mergeUsersPreservingAvatars(existingInGroup, [remoteUser]);
              StorageService.saveUsers(mergedUsers, targetKey);

              if (targetKey !== activeGroupKeyRef.current) {
                await switchGroup(targetKey);
              } else {
                await refreshMembers(targetKey);
              }

              StorageService.setCurrentUserId(remoteUser.id, targetKey);
              setCurrentUserId(remoteUser.id);
              setIsAuthenticated(true);
              setShowAuthModal(false);
              triggerConfetti();
              return { success: true, user: remoteUser };
            }

            if (loginRes.reason === 'PENDING_APPROVAL') {
              return {
                success: false,
                pendingApproval: true,
                error:
                  'Tu solicitud de inscripción fue enviada y aún espera autorización del Administrador. Solo podrás ingresar cuando acepte tu solicitud.',
              };
            }

            if (loginRes.reason === 'INVALID_PASSWORD') {
              return {
                success: false,
                error: 'La contraseña o cédula ingresada es incorrecta. Por favor verifica tus datos.',
              };
            }
          }
        } catch (err) {
          console.warn('Supabase RPC login skipped:', err);
        }
      }
    }

    if (!user) {
      return {
        success: false,
        error: explicitGroupKey
          ? 'No se encontró ningún integrante con ese correo o cédula dentro del grupo seleccionado.'
          : 'No se encontró ningún integrante registrado con ese correo o cédula. Verifica si ya completaste el registro.',
      };
    }

    if (!checkPasswordMatch(user, cleanPass)) {
      return {
        success: false,
        error: 'La contraseña o cédula ingresada es incorrecta. Por favor verifica tus datos.',
      };
    }

    if (user.status === 'pendiente_aprobacion' && user.role !== 'admin') {
      return {
        success: false,
        pendingApproval: true,
        error:
          'Tu solicitud de inscripción fue enviada y aún espera autorización del Administrador. Solo podrás ingresar cuando acepte tu solicitud.',
      };
    }

    // Cambiar al espacio de trabajo exclusivo de su grupo antes de iniciar sesión
    if (matchedGroupKey !== activeGroupKeyRef.current) {
      await switchGroup(matchedGroupKey);
    }

    StorageService.setCurrentUserId(user.id, matchedGroupKey);
    setCurrentUserId(user.id);
    setIsAuthenticated(true);
    setShowAuthModal(false);
    triggerConfetti();
    return { success: true, user };
  };

  const createGroupWorkspace = async (data: {
    groupName: string;
    parishName?: string;
    invitationCode: string;
    logoUrl?: string;
    coordinatorName: string;
    coordinatorEmail: string;
    coordinatorCedula: string;
    coordinatorPassword?: string;
  }): Promise<{ success: boolean; error?: string; groupKey?: string }> => {
    const cleanGroupName = data.groupName.trim();
    if (!cleanGroupName) {
      return { success: false, error: 'Ingresa el nombre del nuevo grupo JMV.' };
    }
    const cleanCode = normalizeInvitationCode(data.invitationCode);
    if (!cleanCode || cleanCode.length < 3) {
      return { success: false, error: 'Define un código privado de invitación de al menos 3 caracteres.' };
    }
    const cleanCoordName = data.coordinatorName.trim();
    const cleanCoordEmail = data.coordinatorEmail.trim().toLowerCase();
    const cleanCoordCedula = data.coordinatorCedula.trim();
    if (!cleanCoordName || !cleanCoordEmail.includes('@') || !cleanCoordCedula) {
      return {
        success: false,
        error: 'Completa el nombre, correo válido y cédula del coordinador/a del nuevo grupo.',
      };
    }

    const newKey = normalizeGroupKey(cleanGroupName);
    const existingGroups = StorageService.getGroupsRegistry();
    if (existingGroups.some((g) => g.groupKey === newKey)) {
      return {
        success: false,
        error: `Ya existe un grupo llamado "${cleanGroupName}". Agrega la parroquia o ciudad para diferenciarlo.`,
      };
    }

    const coordinator: UserProfile = {
      id: generateUuid(),
      name: cleanCoordName,
      email: cleanCoordEmail,
      cedula: cleanCoordCedula,
      password: (data.coordinatorPassword || cleanCoordCedula).trim(),
      groupKey: newKey,
      groupName: cleanGroupName,
      status: 'aprobado',
      role: 'admin',
      isTreasurer: true,
      avatarUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(cleanCoordName)}`,
      birthday: '2000-01-01',
      joinedAt: new Date().toISOString().split('T')[0],
      points: 100,
      badges: ['constancia', 'servicio'],
      imageConsentAccepted: true,
      isMinor: false,
    };

    let finalCoordinator = coordinator;
    const client = getSupabaseClient();
    if (client) {
      try {
        const { data: rpcRes, error: rpcErr } = await client.rpc('jmv_create_group_workspace', {
          p_group_key: newKey,
          p_group_name: cleanGroupName,
          p_parish_name: data.parishName?.trim() || '',
          p_invitation_code: cleanCode,
          p_logo_url: data.logoUrl || null,
          p_coord_name: cleanCoordName,
          p_coord_email: cleanCoordEmail,
          p_coord_cedula: cleanCoordCedula,
          p_coord_password: coordinator.password,
        });
        if (!rpcErr && rpcRes) {
          if (rpcRes.ok === false) {
            return { success: false, error: rpcRes.error || 'No se pudo crear el grupo en Supabase.' };
          }
          if (rpcRes.session_token) {
            setSupabaseSessionToken(rpcRes.session_token, newKey);
          }
          if (rpcRes.profile?.id) {
            finalCoordinator = { ...coordinator, id: String(rpcRes.profile.id) };
          }
        }
      } catch (err) {
        console.warn('Supabase createGroupWorkspace fallback:', err);
      }
    }

    StorageService.initializeGroupWorkspace({
      groupKey: newKey,
      groupName: cleanGroupName,
      parishName: data.parishName?.trim(),
      logoUrl: data.logoUrl,
      invitationCode: cleanCode,
      coordinator: finalCoordinator,
    });
    StorageService.setCurrentUserId(finalCoordinator.id, newKey);

    reloadWorkspaceForGroup(newKey);
    const createdSettings = StorageService.getSettings(newKey);
    await syncSettingsToRemote(createdSettings, newKey);

    setCurrentUserId(finalCoordinator.id);
    setIsAuthenticated(true);
    setShowAuthModal(false);
    triggerConfetti();
    return { success: true, groupKey: newKey };
  };

  const restoreExampleAdmin = (): UserProfile => {
    const stored = StorageService.getUsers();
    const map = new Map<string, UserProfile>();
    [...stored, ...usersRef.current].forEach((u) => map.set(u.id, u));
    const currentList = Array.from(map.values());

    const existingIdx = currentList.findIndex(
      (u) => u.id === EXAMPLE_ADMIN.id || u.email.trim().toLowerCase() === EXAMPLE_ADMIN.email.toLowerCase()
    );

    const restoredAdmin: UserProfile =
      existingIdx >= 0
        ? {
            ...currentList[existingIdx],
            email: EXAMPLE_ADMIN.email,
            cedula: EXAMPLE_ADMIN.cedula,
            password: EXAMPLE_ADMIN.password,
            role: 'admin',
            isTreasurer: true,
            status: 'aprobado',
          }
        : EXAMPLE_ADMIN;

    const updated =
      existingIdx >= 0
        ? currentList.map((u, idx) => (idx === existingIdx ? restoredAdmin : u))
        : [restoredAdmin, ...currentList];

    usersRef.current = updated;
    setUsers(updated);
    StorageService.saveUsers(updated);
    return restoredAdmin;
  };

  const findUserAcrossSources = async (emailOrCedula: string): Promise<UserProfile | undefined> => {
    const cleanId = emailOrCedula.trim().toLowerCase();
    const cleanIdDigits = cleanId.replace(/\D/g, '');
    const storedUsers = StorageService.getUsers();
    const candidateMap = new Map<string, UserProfile>();
    [...storedUsers, ...usersRef.current].forEach((u) => candidateMap.set(u.id, u));
    const allCandidates = Array.from(candidateMap.values());

    let user = allCandidates.find((u) => {
      const uEmail = (u.email || '').trim().toLowerCase();
      const uCedula = (u.cedula || '').trim().toLowerCase();
      const uCedulaDigits = uCedula.replace(/\D/g, '');
      return (
        uEmail === cleanId ||
        uCedula === cleanId ||
        (cleanIdDigits.length >= 6 && uCedulaDigits === cleanIdDigits)
      );
    });

    if (!user && isSupabaseConfigured()) {
      const client = getSupabaseClient();
      if (client) {
        try {
          const { data } = await client
            .from('jmv_profiles')
            .select('*')
            .or(`email.ilike.${cleanId},cedula.eq.${emailOrCedula.trim()}`)
            .limit(1);
          if (Array.isArray(data) && data.length > 0) {
            const remoteUser = mapSupabaseRowToUser(data[0]);
            user = remoteUser;
            const nextUsers = [...allCandidates.filter((u) => u.id !== remoteUser.id), remoteUser];
            usersRef.current = nextUsers;
            setUsers(nextUsers);
            StorageService.saveUsers(nextUsers);
          }
        } catch (err) {
          console.warn('Supabase recovery lookup error:', err);
        }
      }
    }

    return user;
  };

  const upsertPasswordRequest = (user: UserProfile, status: 'pending' | 'resolved') => {
    setPasswordRequests((prev) => {
      const filtered = prev.filter((r) => !(r.userId === user.id && r.status === 'pending'));
      const next: PasswordRecoveryRequest[] = [
        {
          id: `req-${Date.now()}`,
          userId: user.id,
          userName: user.name,
          userEmail: user.email,
          requestedAt: new Date().toISOString(),
          status,
        },
        ...filtered,
      ].slice(0, 30);
      StorageService.savePasswordRequests(next);
      return next;
    });
  };

  const resolvePasswordRequest = (requestId: string) => {
    setPasswordRequests((prev) => {
      const next = prev.map((r) => (r.id === requestId ? { ...r, status: 'resolved' as const } : r));
      StorageService.savePasswordRequests(next);
      return next;
    });
  };

  const requestPasswordReminder = async (emailOrCedula: string) => {
    const cleanInput = emailOrCedula.trim();
    if (!cleanInput) {
      return {
        found: false,
        sentViaEmail: false,
        message: 'Ingresa el correo electrónico o cédula con el que te registraste.',
      };
    }

    let user = await findUserAcrossSources(cleanInput);
    if (!user && isSupabaseConfigured()) {
      const client = getSupabaseClient();
      if (client) {
        try {
          const { data: recRes } = await client.rpc('jmv_request_password_recovery', {
            p_identifier: cleanInput,
            p_group_key: activeGroupKeyRef.current,
          });
          if (recRes?.found) {
            return {
              found: true,
              sentViaEmail: false,
              requiresCedulaVerification: true,
              userEmail: recRes.user_email || cleanInput,
              userName: recRes.user_name || 'Integrante',
              message: `Cuenta encontrada (${recRes.user_email || cleanInput}). Registramos tu solicitud para el Coordinador y puedes restablecer tu contraseña verificando tu cédula.`,
            };
          }
        } catch {
          // Continuar con respuesta estándar
        }
      }
    }

    if (!user) {
      return {
        found: false,
        sentViaEmail: false,
        message:
          'No encontramos ninguna cuenta registrada con ese correo o cédula en este dispositivo. Si eres coordinador, puedes restaurar el Admin de ejemplo o registrarte nuevamente.',
      };
    }

    const userPassword = (user.password || user.cedula || '').trim();

    // 1. Intentar envío por EmailJS si está configurado en Ajustes del Grupo o variables Vite
    const ejsService = (settings.emailjsServiceId || import.meta.env.VITE_EMAILJS_SERVICE_ID || '').trim();
    const ejsTemplate = (settings.emailjsTemplateId || import.meta.env.VITE_EMAILJS_TEMPLATE_ID || '').trim();
    const ejsPublicKey = (settings.emailjsPublicKey || import.meta.env.VITE_EMAILJS_PUBLIC_KEY || '').trim();

    if (ejsService && ejsTemplate && ejsPublicKey) {
      try {
        const ejsRes = await fetch('https://api.emailjs.com/api/v1.0/email/send', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            service_id: ejsService,
            template_id: ejsTemplate,
            user_id: ejsPublicKey,
            template_params: {
              to_email: user.email,
              to_name: user.name,
              user_email: user.email,
              user_cedula: user.cedula,
              user_password: userPassword,
              group_name: settings.groupName,
              parish_name: settings.parishName || 'JMV',
              message: `Tu contraseña de acceso es: ${userPassword} (Cédula: ${user.cedula})`,
            },
          }),
        });
        if (ejsRes.ok) {
          upsertPasswordRequest(user, 'resolved');
          return {
            found: true,
            sentViaEmail: true,
            provider: 'emailjs',
            userEmail: user.email,
            userName: user.name,
            message: `¡Recordatorio enviado correctamente a ${user.email}! Revisa tu bandeja de entrada o spam.`,
          };
        }
      } catch (err) {
        console.warn('EmailJS send failed:', err);
      }
    }

    // 2. Intentar envío por servidor (/api/send-password-reminder con Resend o webhook)
    try {
      const apiRes = await fetch('/api/send-password-reminder', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: user.email,
          name: user.name,
          password: userPassword,
          cedula: user.cedula,
          groupName: settings.groupName,
          parishName: settings.parishName,
        }),
      });
      if (apiRes.ok) {
        const data = await apiRes.json();
        if (data?.delivered) {
          upsertPasswordRequest(user, 'resolved');
          return {
            found: true,
            sentViaEmail: true,
            provider: data.provider || 'server',
            userEmail: user.email,
            userName: user.name,
            message: `¡Recordatorio enviado correctamente a ${user.email}! Revisa tu bandeja de entrada o carpeta de spam.`,
          };
        }
      }
    } catch (err) {
      console.warn('Server email reminder unavailable:', err);
    }

    // 3. Registrar solicitud para el Coordinador y habilitar recuperación segura verificando Cédula
    upsertPasswordRequest(user, 'pending');
    return {
      found: true,
      sentViaEmail: false,
      requiresCedulaVerification: true,
      userEmail: user.email,
      userName: user.name,
      message: `Cuenta encontrada (${user.email}). El envío automático de correo aún no tiene proveedor (Resend/EmailJS) configurado, pero registramos tu solicitud para el Coordinador y puedes recuperar o cambiar tu contraseña ahora mismo verificando tu cédula.`,
    };
  };

  const verifyCedulaAndRecoverPassword = async (
    emailOrCedula: string,
    cedula: string,
    newPassword?: string
  ) => {
    const cleanCedula = cedula.trim();
    const cleanCedulaDigits = cleanCedula.replace(/\D/g, '');
    if (!cleanCedula) {
      return { success: false, error: 'Ingresa tu número de cédula para verificar tu identidad.' };
    }

    if (isSupabaseConfigured()) {
      const client = getSupabaseClient();
      if (client) {
        try {
          const { data: resetRes, error: rpcErr } = await client.rpc('jmv_reset_password_with_cedula', {
            p_identifier: emailOrCedula,
            p_cedula: cleanCedula,
            p_new_password: newPassword && newPassword.trim() ? newPassword.trim() : null,
            p_group_key: activeGroupKeyRef.current,
          });
          if (!rpcErr && resetRes) {
            if (!resetRes.ok) {
              if (resetRes.reason === 'CEDULA_MISMATCH') {
                return {
                  success: false,
                  error: 'La cédula ingresada no coincide con la registrada en esa cuenta.',
                };
              }
            } else {
              if (newPassword && newPassword.trim()) {
                return {
                  success: true,
                  recoveredPassword: newPassword.trim(),
                  userName: resetRes.user_name,
                  userEmail: resetRes.user_email,
                };
              }
            }
          }
        } catch (err) {
          console.warn('Supabase reset RPC fallback:', err);
        }
      }
    }

    const user = await findUserAcrossSources(emailOrCedula);
    if (!user) {
      return {
        success: false,
        error: isSupabaseConfigured()
          ? 'Por seguridad RLS (contraseñas cifradas), ingresa una nueva contraseña además de tu cédula para restablecer tu acceso.'
          : 'No se encontró una cuenta con ese correo.',
      };
    }

    const uCedula = (user.cedula || '').trim();
    const uCedulaDigits = uCedula.replace(/\D/g, '');
    const matches =
      uCedula.toLowerCase() === cleanCedula.toLowerCase() ||
      (cleanCedulaDigits.length >= 6 && cleanCedulaDigits === uCedulaDigits);

    if (!matches) {
      return {
        success: false,
        error: 'La cédula ingresada no coincide con la registrada en esa cuenta. Por privacidad no podemos mostrar la clave.',
      };
    }

    const updatedPass = newPassword && newPassword.trim() ? newPassword.trim() : (user.password || user.cedula).trim();
    if (newPassword && newPassword.trim()) {
      updateUser(user.id, { password: updatedPass });
    }

    upsertPasswordRequest(user, 'resolved');
    return {
      success: true,
      recoveredPassword: updatedPass,
      userName: user.name,
      userEmail: user.email,
    };
  };

  const logout = () => {
    const activeKey = activeGroupKeyRef.current;
    const client = getSupabaseClient(activeKey);
    if (client && getSupabaseSessionToken(activeKey)) {
      void client.rpc('jmv_logout');
    }
    setSupabaseSessionToken(null, activeKey);
    StorageService.clearCurrentUserId(activeKey);
    setCurrentUserId('');
    setIsAuthenticated(false);
    setIsMobileSidebarOpen(false);
    setAuthModalMode('login');
    setShowAuthModal(true);
  };

  const approveMember = (userId: string) => {
    const nextUsers: UserProfile[] = usersRef.current.map((u) =>
      u.id === userId ? { ...u, status: 'aprobado' as const } : u
    );
    usersRef.current = nextUsers;
    setUsers(nextUsers);
    StorageService.saveUsers(nextUsers);
    const target = nextUsers.find((u) => u.id === userId);
    if (target) void syncProfileToSupabase(target);
    triggerConfetti();
  };

  const rejectMember = (userId: string) => {
    const nextUsers = usersRef.current.filter((u) => u.id !== userId);
    usersRef.current = nextUsers;
    setUsers(nextUsers);
    StorageService.saveUsers(nextUsers);
    const client = getSupabaseClient(activeGroupKeyRef.current);
    if (client && isUuid(userId)) {
      void client.from('jmv_profiles').delete().eq('id', userId);
    }
  };

  const bulkImportMembers = (list: Array<{ name: string; email: string; cedula: string; phone?: string; birthday?: string; role?: UserRole }>) => {
    const errors: string[] = [];
    let addedCount = 0;
    const newUsers: UserProfile[] = [];
    const currentList = usersRef.current;

    list.forEach((item, index) => {
      const name = item.name?.trim();
      const email = item.email?.trim().toLowerCase();
      const cedula = item.cedula?.trim();

      if (!name || !email || !cedula) {
        errors.push(`Fila ${index + 1}: Nombre, correo y cédula son obligatorios.`);
        return;
      }

      const emailExists =
        currentList.some((u) => u.email.trim().toLowerCase() === email) ||
        newUsers.some((u) => u.email.trim().toLowerCase() === email);
      if (emailExists) {
        errors.push(`Fila ${index + 1}: El correo ${email} ya está registrado.`);
        return;
      }

      const cedulaExists =
        currentList.some((u) => u.cedula.trim() === cedula) ||
        newUsers.some((u) => u.cedula.trim() === cedula);
      if (cedulaExists) {
        errors.push(`Fila ${index + 1}: La cédula ${cedula} ya está registrada.`);
        return;
      }

      const newId = generateUuid();
      newUsers.push({
        id: newId,
        name,
        email,
        cedula,
        password: cedula,
        status: 'aprobado',
        role: item.role || 'integrante',
        isTreasurer: item.role === 'tesorero',
        avatarUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(name)}`,
        birthday: item.birthday || '2005-01-01',
        phone: item.phone?.trim(),
        joinedAt: new Date().toISOString().split('T')[0],
        points: 50,
        badges: ['alegria'],
        imageConsentAccepted: true,
        isMinor: false,
      });
      addedCount++;
    });

    if (newUsers.length > 0) {
      const updated = [...currentList, ...newUsers];
      usersRef.current = updated;
      setUsers(updated);
      StorageService.saveUsers(updated);
      newUsers.forEach((nu) => void syncProfileToSupabase(nu, undefined, true));
      triggerConfetti();
    }

    return { success: addedCount > 0, count: addedCount, errors };
  };

  const registerMember = async (data: {
    name: string;
    email: string;
    cedula: string;
    password?: string;
    birthday: string;
    phone?: string;
    invitationCode: string;
    groupName?: string;
    groupKey?: string;
    avatarUrl?: string;
    imageConsentAccepted: boolean;
    isMinor?: boolean;
    tutorName?: string;
    tutorPhone?: string;
    serviceArea?: string;
    spiritualQuote?: string;
    emergencyContact?: string;
    role?: UserRole;
    autoApprove?: boolean;
  }) => {
    const isAuto = Boolean(data.autoApprove);
    const registry = StorageService.getGroupsRegistry();

    let targetGroupKey = activeGroupKeyRef.current;
    if (data.groupKey && data.groupKey.trim()) {
      targetGroupKey = normalizeGroupKey(data.groupKey);
    } else if (data.groupName && data.groupName.trim()) {
      const normalizedFromName = normalizeGroupKey(data.groupName);
      const foundByName = registry.find(
        (g) => g.groupKey === normalizedFromName || normalizeGroupKey(g.groupName) === normalizedFromName
      );
      targetGroupKey = foundByName ? foundByName.groupKey : normalizedFromName;
    }

    const freshTargetSettings = StorageService.getSettings(targetGroupKey);
    const resolvedGroupName = data.groupName?.trim() || freshTargetSettings.groupName;
    const enteredCode = normalizeInvitationCode(data.invitationCode);

    if (!isAuto) {
      const localCode = normalizeInvitationCode(
        targetGroupKey === activeGroupKeyRef.current
          ? freshTargetSettings.invitationCode || settingsRef.current.invitationCode
          : freshTargetSettings.invitationCode
      );

      let authoritativeMatched: boolean | null = null;
      const client = getSupabaseClient();
      if (client) {
        try {
          const { data: verifyRpc } = await client.rpc('jmv_verify_invitation_code', {
            p_group_key: targetGroupKey,
            p_code: enteredCode,
          });
          if (verifyRpc?.configured) {
            authoritativeMatched = Boolean(verifyRpc.valid);
          }
        } catch {
          // Continuar con respaldo del servidor / local
        }
      }

      if (authoritativeMatched === null) {
        try {
          const verifyRes = await fetch('/api/verify-invitation-code', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              code: enteredCode,
              groupKey: targetGroupKey,
              groupName: resolvedGroupName,
            }),
          });
          if (verifyRes.ok) {
            const verifyJson = await verifyRes.json();
            if (verifyJson?.configured) {
              authoritativeMatched = Boolean(verifyJson.valid);
            }
          }
        } catch {
          // Continuar con respaldo local
        }
      }

      const isCodeValid =
        authoritativeMatched !== null ? authoritativeMatched : Boolean(enteredCode && enteredCode === localCode);

      if (!isCodeValid) {
        return {
          success: false,
          error: `Código de invitación incorrecto para el grupo "${resolvedGroupName}". Solicita el código vigente al coordinador de ese grupo.`,
        };
      }
    }
    if (!data.name.trim()) {
      return { success: false, error: 'Por favor ingresa tu nombre completo.' };
    }
    const cleanEmail = data.email.trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes('@')) {
      return { success: false, error: 'Por favor ingresa un correo electrónico válido.' };
    }
    const cleanCedula = data.cedula.trim();
    if (!cleanCedula) {
      return { success: false, error: 'Por favor ingresa tu número de cédula.' };
    }

    const freshTargetUsers = StorageService.getUsers(targetGroupKey);
    const currentList =
      targetGroupKey === activeGroupKeyRef.current
        ? mergeUsersPreservingAvatars(usersRef.current, freshTargetUsers)
        : freshTargetUsers;
    if (currentList.some((u) => u.email.trim().toLowerCase() === cleanEmail)) {
      return { success: false, error: `Ya existe un integrante registrado con este correo en "${resolvedGroupName}".` };
    }
    if (currentList.some((u) => u.cedula.trim() === cleanCedula)) {
      return { success: false, error: `Ya existe un integrante registrado con esta cédula en "${resolvedGroupName}".` };
    }

    if (!data.imageConsentAccepted) {
      return { success: false, error: 'Debes aceptar la autorización de uso interno de imagen para participar en las actividades.' };
    }

    const cleanPassword = data.password && data.password.trim() ? data.password.trim() : cleanCedula;
    let newId = generateUuid();

    if (!isAuto && isSupabaseConfigured()) {
      const client = getSupabaseClient();
      if (client) {
        try {
          const { data: regRes, error: regErr } = await client.rpc('jmv_register_member', {
            p_group_key: targetGroupKey,
            p_group_name: resolvedGroupName,
            p_name: data.name.trim(),
            p_email: cleanEmail,
            p_cedula: cleanCedula,
            p_password: cleanPassword,
            p_birthday: data.birthday || '2005-01-01',
            p_phone: data.phone?.trim() || null,
            p_invitation_code: enteredCode,
            p_avatar_url:
              data.avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(data.name)}`,
            p_image_consent_accepted: data.imageConsentAccepted,
            p_is_minor: Boolean(data.isMinor),
            p_tutor_name: data.tutorName || null,
            p_tutor_phone: data.tutorPhone || null,
            p_service_area: data.serviceArea || 'Misión y Visitas',
            p_spiritual_quote: data.spiritualQuote || null,
            p_emergency_contact: data.emergencyContact || null,
          });
          if (!regErr && regRes) {
            if (regRes.ok === false) {
              return { success: false, error: regRes.error || 'No se pudo completar el registro en Supabase.' };
            }
            if (regRes.id) {
              newId = String(regRes.id);
            }
          }
        } catch (err) {
          console.warn('Supabase RPC register fallback:', err);
        }
      }
    }

    const newUser: UserProfile = {
      id: newId,
      name: data.name.trim(),
      email: cleanEmail,
      cedula: cleanCedula,
      password: cleanPassword,
      groupKey: targetGroupKey,
      groupName: resolvedGroupName,
      status: isAuto ? 'aprobado' : 'pendiente_aprobacion',
      role: data.role || 'integrante',
      isTreasurer: data.role === 'tesorero',
      avatarUrl: data.avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(data.name)}`,
      birthday: data.birthday || '2005-01-01',
      phone: data.phone?.trim(),
      joinedAt: new Date().toISOString().split('T')[0],
      points: 50, // Bono de bienvenida
      badges: ['alegria'],
      imageConsentAccepted: data.imageConsentAccepted,
      isMinor: data.isMinor,
      tutorName: data.tutorName,
      tutorPhone: data.tutorPhone,
      serviceArea: data.serviceArea,
      spiritualQuote: data.spiritualQuote,
      emergencyContact: data.emergencyContact,
    };

    const updatedUsers = [...currentList, newUser];
    StorageService.saveUsers(updatedUsers, targetGroupKey);
    if (targetGroupKey === activeGroupKeyRef.current) {
      usersRef.current = updatedUsers;
      setUsers(updatedUsers);
    }
    if (isAuto) {
      void syncProfileToSupabase(newUser, targetGroupKey, true);
    }
    triggerConfetti();
    return {
      success: true,
      pendingApproval: !isAuto,
      userName: newUser.name,
      groupName: resolvedGroupName,
    };
  };

  const deleteUser = (userId: string): { success: boolean; error?: string } => {
    const currentList = usersRef.current;
    if (currentList.length <= 1) {
      return { success: false, error: 'Debe quedar al menos un integrante (coordinador/a) en el grupo.' };
    }

    const userToDelete = currentList.find((u) => u.id === userId);
    if (!userToDelete) {
      return { success: false, error: 'Integrante no encontrado.' };
    }

    const adminCount = currentList.filter((u) => u.role === 'admin').length;
    if (userToDelete.role === 'admin' && adminCount <= 1) {
      return {
        success: false,
        error: 'No puedes eliminar al único Administrador/Coordinador. Asigna primero otro Coordinador/a.',
      };
    }

    const remainingUsers = currentList.filter((u) => u.id !== userId);

    // Si el usuario actual es el que se va a eliminar, cambiamos inmediatamente al primer coordinador restante
    if (currentUserId === userId) {
      const fallbackUser = remainingUsers.find((u) => u.role === 'admin') || remainingUsers[0];
      setCurrentUserId(fallbackUser.id);
      StorageService.setCurrentUserId(fallbackUser.id);
    }

    usersRef.current = remainingUsers;
    setUsers(remainingUsers);
    StorageService.saveUsers(remainingUsers);

    const client = getSupabaseClient(activeGroupKeyRef.current);
    if (client && isUuid(userId)) {
      void client.from('jmv_profiles').delete().eq('id', userId);
    }

    // Limpiar cuotas pendientes de ese usuario para mantener limpia la contabilidad
    const cleanedFeePayments = feePayments.filter((p) => !(p.userId === userId && p.status === 'pendiente'));
    setFeePayments(cleanedFeePayments);
    StorageService.saveFeePayments(cleanedFeePayments);

    return { success: true };
  };

  const cleanExampleUsers = (): { success: boolean; removedCount: number; error?: string } => {
    // IDs de los integrantes de muestra predefinidos
    const sampleIds = ['user-2', 'user-3', 'user-4', 'user-5', 'user-6'];
    const currentList = usersRef.current;

    // Filtramos para remover solo los de muestra
    const remaining = currentList.filter((u) => !sampleIds.includes(u.id));

    // Si remaining estuviera vacío, dejamos al usuario activo
    const finalUsers = remaining.length > 0 ? remaining : [currentList[0]];
    const removedCount = currentList.length - finalUsers.length;

    if (removedCount === 0) {
      return { success: false, removedCount: 0, error: 'Ya no hay integrantes de ejemplo por eliminar. ¡Todos tus miembros son reales!' };
    }

    if (!finalUsers.some((u) => u.id === currentUserId)) {
      const fallback = finalUsers.find((u) => u.role === 'admin') || finalUsers[0];
      setCurrentUserId(fallback.id);
      StorageService.setCurrentUserId(fallback.id);
    }

    usersRef.current = finalUsers;
    setUsers(finalUsers);
    StorageService.saveUsers(finalUsers);

    // Limpiar cuotas pendientes de los usuarios de ejemplo removidos
    const cleanedPayments = feePayments.filter((p) => !sampleIds.includes(p.userId));
    setFeePayments(cleanedPayments);
    StorageService.saveFeePayments(cleanedPayments);

    triggerConfetti();
    return { success: true, removedCount };
  };

  const updateUser = (userId: string, data: Partial<UserProfile>) => {
    const nextUsers = usersRef.current.map((u) => {
      if (u.id !== userId) return u;
      return {
        ...u,
        ...data,
        email: (data.email !== undefined ? data.email : u.email).trim().toLowerCase(),
        cedula: (data.cedula !== undefined ? data.cedula : u.cedula).trim(),
        password: (data.password !== undefined ? data.password : u.password || u.cedula).trim(),
      };
    });
    usersRef.current = nextUsers;
    setUsers(nextUsers);
    StorageService.saveUsers(nextUsers);
    const updatedTarget = nextUsers.find((u) => u.id === userId);
    if (updatedTarget) {
      void syncProfileToSupabase(updatedTarget, undefined, Boolean(data.password));
      propagateUserIdentity(updatedTarget.id, updatedTarget.name, updatedTarget.avatarUrl);
    }
  };

  const updateSettings = (newSettings: Partial<GroupSettings>) => {
    const currentKey = activeGroupKeyRef.current;
    const normalizedPatch: Partial<GroupSettings> = {
      ...newSettings,
      ...(newSettings.invitationCode !== undefined
        ? { invitationCode: normalizeInvitationCode(newSettings.invitationCode) }
        : {}),
    };
    const updated: GroupSettings = {
      ...settingsRef.current,
      ...normalizedPatch,
      groupKey: currentKey,
    };
    settingsRef.current = updated;
    setSettings(updated);
    StorageService.saveSettings(updated, currentKey);
    setAvailableGroups(StorageService.getGroupsRegistry());
    void syncSettingsToRemote(updated, currentKey);
  };

  useEffect(() => {
    if (typeof document === 'undefined') return;
    const titleParts = [settings.groupName?.trim() || 'JMV'];
    if (settings.parishName?.trim()) {
      titleParts.push(settings.parishName.trim());
    }
    document.title = titleParts.join(' · ');

    if (settings.logoUrl) {
      let favicon = document.querySelector<HTMLLinkElement>('link[rel="icon"]');
      if (!favicon) {
        favicon = document.createElement('link');
        favicon.rel = 'icon';
        document.head.appendChild(favicon);
      }
      favicon.href = settings.logoUrl;
    }
  }, [settings.groupName, settings.parishName, settings.logoUrl]);

  // --- RETOS SEMANALES ---
  const createChallenge = (data: Omit<WeeklyChallenge, 'id' | 'createdBy' | 'isActive'>) => {
    const newChallenge: WeeklyChallenge = {
      ...data,
      id: `ch-${Date.now()}`,
      createdBy: currentUser.name,
      isActive: true,
    };
    // Desactivar otros retos anteriores
    const updated = [newChallenge, ...challenges.map((c) => ({ ...c, isActive: false }))];
    setChallenges(updated);
    StorageService.saveChallenges(updated);
  };

  const submitChallenge = (challengeId: string, comment?: string, imageUrl?: string) => {
    const existing = submissions.find((s) => s.challengeId === challengeId && s.userId === currentUser.id);
    if (existing) return;

    const newSub: ChallengeSubmission = {
      id: `sub-${Date.now()}`,
      challengeId,
      userId: currentUser.id,
      userName: currentUser.name,
      userAvatar: currentUser.avatarUrl,
      submittedAt: new Date().toISOString(),
      comment,
      imageUrl,
      status: 'pending',
    };

    const updated = [newSub, ...submissions];
    setSubmissions(updated);
    StorageService.saveSubmissions(updated);
  };

  const reviewSubmission = (submissionId: string, status: 'approved' | 'rejected') => {
    const sub = submissions.find((s) => s.id === submissionId);
    if (!sub) return;

    const updatedSubmissions = submissions.map((s) =>
      s.id === submissionId
        ? {
            ...s,
            status,
            approvedBy: currentUser.name,
            approvedAt: new Date().toISOString(),
          }
        : s
    );
    setSubmissions(updatedSubmissions);
    StorageService.saveSubmissions(updatedSubmissions);

    // Si fue aprobado, sumar puntos al usuario y verificar insignias
    if (status === 'approved') {
      const challenge = challenges.find((c) => c.id === sub.challengeId);
      const pointsToAdd = challenge ? challenge.points : 50;

      const updatedUsers = users.map((u) => {
        if (u.id === sub.userId) {
          const newPoints = u.points + pointsToAdd;
          const newBadges = [...u.badges];
          if (newPoints >= 200 && !newBadges.includes('constancia')) newBadges.push('constancia');
          if (newPoints >= 350 && !newBadges.includes('servicio')) newBadges.push('servicio');
          return { ...u, points: newPoints, badges: newBadges };
        }
        return u;
      });
      setUsers(updatedUsers);
      StorageService.saveUsers(updatedUsers);
      triggerConfetti();
    }
  };

  // --- CUOTAS DE 1 DÓLAR ---
  const markFeePayment = (userId: string, weekNumber: number, isPaid: boolean, note?: string) => {
    const existingIndex = feePayments.findIndex((p) => p.userId === userId && p.weekNumber === weekNumber);
    let updated: FeePayment[];

    const user = users.find((u) => u.id === userId);

    if (existingIndex >= 0) {
      updated = [...feePayments];
      updated[existingIndex] = {
        ...updated[existingIndex],
        status: isPaid ? 'pagado' : 'pendiente',
        paidAt: isPaid ? new Date().toISOString() : undefined,
        registeredBy: isPaid ? currentUser.name : undefined,
        note: note !== undefined ? note : updated[existingIndex].note,
      };
    } else {
      updated = [
        ...feePayments,
        {
          id: `pay-${userId}-${weekNumber}-${Date.now()}`,
          userId,
          userName: user?.name || 'Integrante',
          weekId: `week-${weekNumber}`,
          weekNumber,
          amount: 1.0,
          status: isPaid ? 'pagado' : 'pendiente',
          paidAt: isPaid ? new Date().toISOString() : undefined,
          registeredBy: isPaid ? currentUser.name : undefined,
          note,
        },
      ];
    }
    setFeePayments(updated);
    StorageService.saveFeePayments(updated);
  };

  const addFeeWeek = () => {
    const nextWeekNumber = feeWeeks.length > 0 ? Math.max(...feeWeeks.map((w) => w.weekNumber)) + 1 : 1;
    const nextDate = new Date();
    nextDate.setDate(nextDate.getDate() + 7);
    const newWeek: FeeWeek = {
      id: `week-${nextWeekNumber}`,
      weekNumber: nextWeekNumber,
      title: `Semana ${nextWeekNumber}`,
      date: nextDate.toISOString().split('T')[0],
      amount: 1.0,
    };
    const updatedWeeks = [...feeWeeks, newWeek];
    setFeeWeeks(updatedWeeks);
    StorageService.saveFeeWeeks(updatedWeeks);

    // Inicializar pagos pendientes para todos los miembros actuales
    const newPayments: FeePayment[] = users.map((u) => ({
      id: `pay-${u.id}-${nextWeekNumber}-${Date.now()}`,
      userId: u.id,
      userName: u.name,
      weekId: newWeek.id,
      weekNumber: nextWeekNumber,
      amount: 1.0,
      status: 'pendiente',
    }));
    const updatedPayments = [...feePayments, ...newPayments];
    setFeePayments(updatedPayments);
    StorageService.saveFeePayments(updatedPayments);
    triggerConfetti();
  };

  const createFeeCampaign = (campaign: Omit<FeeCampaign, 'id' | 'createdAt' | 'createdBy' | 'isActive'>): FeeCampaign => {
    const newCampaign: FeeCampaign = {
      ...campaign,
      id: `camp-${Date.now()}`,
      createdAt: new Date().toISOString(),
      createdBy: `${currentUser.name} (${currentUser.role === 'admin' ? 'Coordinador' : 'Tesorero'})`,
      isActive: true,
    };
    const updated = [newCampaign, ...feeCampaigns];
    setFeeCampaigns(updated);
    StorageService.saveFeeCampaigns(updated);
    triggerConfetti();
    return newCampaign;
  };

  const recordCampaignPayment = (
    campaignId: string,
    userId: string,
    quantity: number,
    amount: number,
    isPaid: boolean,
    note?: string,
    paymentType: 'inversion' | 'venta' = 'venta',
    mode: 'sumar' | 'reemplazar' = 'sumar'
  ) => {
    const user = usersRef.current.find((u) => u.id === userId);
    let updated: FeePayment[];

    if (paymentType === 'venta' && mode === 'sumar') {
      // Cada entrega de ventas se registra como un abono adicional para que se vayan sumando (ej. 5 + 3 = 8)
      const newEntry: FeePayment = {
        id: `pay-camp-${campaignId}-${userId}-venta-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        campaignId,
        userId,
        userName: user?.name || 'Integrante',
        paymentType: 'venta',
        quantity,
        amount,
        status: isPaid ? 'pagado' : 'pendiente',
        paidAt: isPaid ? new Date().toISOString() : undefined,
        registeredBy: isPaid ? `${currentUser.name} (Economía)` : undefined,
        note: note || undefined,
      };
      updated = [...feePayments, newEntry];
    } else {
      const existingIndex = feePayments.findIndex(
        (p) => p.campaignId === campaignId && p.userId === userId && p.paymentType === paymentType
      );

      if (existingIndex >= 0) {
        updated = [...feePayments];
        updated[existingIndex] = {
          ...updated[existingIndex],
          quantity,
          amount,
          paymentType,
          status: isPaid ? 'pagado' : 'pendiente',
          paidAt: isPaid ? new Date().toISOString() : undefined,
          registeredBy: isPaid ? `${currentUser.name} (Economía)` : undefined,
          note: note !== undefined ? note : updated[existingIndex].note,
        };
      } else {
        updated = [
          ...feePayments,
          {
            id: `pay-camp-${campaignId}-${userId}-${paymentType}-${Date.now()}`,
            campaignId,
            userId,
            userName: user?.name || 'Integrante',
            paymentType,
            quantity,
            amount,
            status: isPaid ? 'pagado' : 'pendiente',
            paidAt: isPaid ? new Date().toISOString() : undefined,
            registeredBy: isPaid ? `${currentUser.name} (Economía)` : undefined,
            note,
          },
        ];
      }
    }
    setFeePayments(updated);
    StorageService.saveFeePayments(updated);
  };

  const deleteCampaignSalePayment = (paymentId: string) => {
    const updated = feePayments.filter((p) => p.id !== paymentId);
    setFeePayments(updated);
    StorageService.saveFeePayments(updated);
  };

  const markCampaignSalePaid = (paymentId: string, isPaid: boolean) => {
    const updated = feePayments.map((p) => {
      if (p.id !== paymentId) return p;
      return {
        ...p,
        status: (isPaid ? 'pagado' : 'pendiente') as 'pagado' | 'pendiente',
        paidAt: isPaid ? new Date().toISOString() : undefined,
        registeredBy: isPaid ? `${currentUser.name} (Economía)` : undefined,
      };
    });
    setFeePayments(updated);
    StorageService.saveFeePayments(updated);
  };

  const toggleInvestmentPayment = (campaignId: string, userId: string, isPaid: boolean, amount?: number) => {
    const campaign = feeCampaigns.find((c) => c.id === campaignId);
    const invAmount = amount !== undefined ? amount : campaign?.investmentPerPerson || 2.0;
    const user = users.find((u) => u.id === userId);

    const existingIndex = feePayments.findIndex(
      (p) => p.campaignId === campaignId && p.userId === userId && p.paymentType === 'inversion'
    );
    let updated: FeePayment[];

    if (existingIndex >= 0) {
      updated = [...feePayments];
      updated[existingIndex] = {
        ...updated[existingIndex],
        status: isPaid ? 'pagado' : 'pendiente',
        paidAt: isPaid ? new Date().toISOString() : undefined,
        registeredBy: isPaid ? `${currentUser.name} (Economía)` : undefined,
      };
    } else {
      updated = [
        ...feePayments,
        {
          id: `pay-inv-${campaignId}-${userId}-${Date.now()}`,
          campaignId,
          userId,
          userName: user?.name || 'Integrante',
          paymentType: 'inversion',
          amount: invAmount,
          status: isPaid ? 'pagado' : 'pendiente',
          paidAt: isPaid ? new Date().toISOString() : undefined,
          registeredBy: isPaid ? `${currentUser.name} (Economía)` : undefined,
          note: `Inversión inicial para ${campaign?.title || 'actividad'}`,
        },
      ];
    }
    setFeePayments(updated);
    StorageService.saveFeePayments(updated);
  };

  const updateCampaignFinancials = (campaignId: string, data: { ingredientCosts?: number }) => {
    const updated = feeCampaigns.map((c) => (c.id === campaignId ? { ...c, ...data } : c));
    setFeeCampaigns(updated);
    StorageService.saveFeeCampaigns(updated);
  };

  const deleteFeeCampaign = (campaignId: string) => {
    const updated = feeCampaigns.filter((c) => c.id !== campaignId);
    setFeeCampaigns(updated);
    StorageService.saveFeeCampaigns(updated);

    const cleanedPayments = feePayments.filter((p) => p.campaignId !== campaignId);
    setFeePayments(cleanedPayments);
    StorageService.saveFeePayments(cleanedPayments);
  };

  const cleanExampleCampaigns = (): number => {
    const exampleIds = ['camp-empanadas', 'camp-1', 'camp-2', 'camp-3'];
    const remaining = feeCampaigns.filter((c) => !exampleIds.includes(c.id));
    const removedCount = feeCampaigns.length - remaining.length;
    setFeeCampaigns(remaining);
    StorageService.saveFeeCampaigns(remaining);

    const cleanedPayments = feePayments.filter((p) => !p.campaignId || !exampleIds.includes(p.campaignId));
    setFeePayments(cleanedPayments);
    StorageService.saveFeePayments(cleanedPayments);
    return removedCount;
  };

  const addActivityExpense = (expense: Omit<ActivityExpense, 'id' | 'createdAt' | 'registeredBy' | 'registeredById'>) => {
    const newExpense: ActivityExpense = {
      ...expense,
      id: `exp-${Date.now()}`,
      createdAt: new Date().toISOString(),
      registeredBy: currentUser.name,
      registeredById: currentUser.id,
    };
    const updated = [newExpense, ...activityExpenses];
    setActivityExpenses(updated);
    StorageService.saveActivityExpenses(updated);
    triggerConfetti();
  };

  const deleteActivityExpense = (expenseId: string) => {
    const updated = activityExpenses.filter((e) => e.id !== expenseId);
    setActivityExpenses(updated);
    StorageService.saveActivityExpenses(updated);
  };

  const exportFeesToCSV = () => {
    const headers = ['Concepto / Campaña', 'Integrante', 'Detalle', 'Monto (USD)', 'Estado', 'Fecha de Pago', 'Registrado Por'];
    const rows = feePayments.map((p) => {
      const campaign = feeCampaigns.find((c) => c.id === p.campaignId);
      const concept = campaign ? campaign.title : 'Cuota Semanal $1 (Chompas)';
      const detail = p.campaignId
        ? `${p.quantity || 1} ${campaign?.unitLabel || 'unidades'}`
        : `Semana ${p.weekNumber || 1}`;

      return [
        `"${concept}"`,
        `"${p.userName}"`,
        `"${detail}"`,
        p.amount.toFixed(2),
        `"${p.status === 'pagado' ? 'PAGADO' : 'PENDIENTE'}"`,
        `"${p.paidAt ? p.paidAt.split('T')[0] : '-'}"`,
        `"${p.registeredBy || '-'}"`,
      ];
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `JMV_Finanzas_Comunitarias_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // --- CHAT GRUPAL ---
  const sendMessage = (text: string, imageUrl?: string) => {
    if (!text.trim() && !imageUrl) return;

    const newMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      userAvatar: currentUser.avatarUrl,
      userRole: currentUser.role,
      text: text.trim(),
      imageUrl,
      createdAt: new Date().toISOString(),
      reactions: {},
    };

    const updated = [...chatMessages, newMsg];
    setChatMessages(updated);
    StorageService.saveChatMessages(updated);
  };

  const togglePinMessage = (messageId: string) => {
    const updated = chatMessages.map((m) =>
      m.id === messageId ? { ...m, isPinned: !m.isPinned, pinnedBy: !m.isPinned ? currentUser.name : undefined } : m
    );
    setChatMessages(updated);
    StorageService.saveChatMessages(updated);
  };

  const addMessageReaction = (messageId: string, emoji: string) => {
    const updated = chatMessages.map((m) => {
      if (m.id !== messageId) return m;
      const reactions = { ...(m.reactions || {}) };
      const currentList = reactions[emoji] || [];
      if (currentList.includes(currentUser.id)) {
        reactions[emoji] = currentList.filter((id) => id !== currentUser.id);
        if (reactions[emoji].length === 0) delete reactions[emoji];
      } else {
        reactions[emoji] = [...currentList, currentUser.id];
      }
      return { ...m, reactions };
    });
    setChatMessages(updated);
    StorageService.saveChatMessages(updated);
  };

  const reportMessage = (messageId: string) => {
    const updated = chatMessages.map((m) =>
      m.id === messageId ? { ...m, isReported: true, reportCount: (m.reportCount || 0) + 1 } : m
    );
    setChatMessages(updated);
    StorageService.saveChatMessages(updated);
  };

  // --- CALENDARIO Y ASISTENCIAS ---
  const createActivity = (data: Omit<ActivityEvent, 'id' | 'attendees' | 'createdBy'>) => {
    const newAct: ActivityEvent = {
      ...data,
      id: `act-${Date.now()}`,
      createdBy: currentUser.name,
      attendees: [
        {
          userId: currentUser.id,
          userName: currentUser.name,
          userAvatar: currentUser.avatarUrl,
          status: 'voy',
        },
      ],
    };
    const updated = [newAct, ...activities];
    setActivities(updated);
    StorageService.saveActivities(updated);
  };

  const bulkCreateActivities = (events: Omit<ActivityEvent, 'id' | 'attendees' | 'createdBy'>[]) => {
    const newActs: ActivityEvent[] = events.map((ev, idx) => ({
      ...ev,
      id: `act-${Date.now()}-${idx}`,
      createdBy: currentUser.name,
      attendees: [
        {
          userId: currentUser.id,
          userName: currentUser.name,
          userAvatar: currentUser.avatarUrl,
          status: 'voy',
        },
      ],
    }));
    const updated = [...newActs, ...activities];
    setActivities(updated);
    StorageService.saveActivities(updated);
    triggerConfetti();
  };

  const rsvpActivity = (activityId: string, status: 'voy' | 'no_voy' | 'tal_vez') => {
    const updated = activities.map((act) => {
      if (act.id !== activityId) return act;
      const existing = act.attendees.filter((a) => a.userId !== currentUser.id);
      return {
        ...act,
        attendees: [
          ...existing,
          {
            userId: currentUser.id,
            userName: currentUser.name,
            userAvatar: currentUser.avatarUrl,
            status,
          },
        ],
      };
    });
    setActivities(updated);
    StorageService.saveActivities(updated);
  };

  const recordAttendance = (
    title: string,
    date: string,
    records: { userId: string; status: 'presente' | 'justificado' | 'ausente' }[]
  ) => {
    const newSession: AttendanceSession = {
      id: `att-${Date.now()}`,
      title,
      date,
      records: records.map((r) => {
        const u = users.find((user) => user.id === r.userId);
        return {
          userId: r.userId,
          userName: u?.name || 'Integrante',
          status: r.status,
        };
      }),
    };
    const updated = [newSession, ...attendanceSessions];
    setAttendanceSessions(updated);
    StorageService.saveAttendance(updated);
  };

  // --- GALERÍA ---
  const createAlbum = (title: string, description: string, coverUrl: string) => {
    const newAlb: PhotoAlbum = {
      id: `alb-${Date.now()}`,
      title,
      description,
      coverUrl,
      date: new Date().toISOString().slice(0, 7),
      photoCount: 1,
    };
    const updated = [newAlb, ...albums];
    setAlbums(updated);
    StorageService.savePhotoAlbums(updated);
  };

  const uploadPhoto = (albumId: string, url: string, caption?: string) => {
    const newPhoto: PhotoItem = {
      id: `ph-${Date.now()}`,
      albumId,
      url,
      caption,
      uploadedBy: currentUser.id,
      uploadedByName: currentUser.name,
      uploadedAt: new Date().toISOString(),
      likes: [],
      comments: [],
    };
    const updated = [newPhoto, ...photos];
    setPhotos(updated);
    StorageService.savePhotoItems(updated);

    // Incrementar conteo en álbum
    const updatedAlbums = albums.map((a) => (a.id === albumId ? { ...a, photoCount: a.photoCount + 1 } : a));
    setAlbums(updatedAlbums);
    StorageService.savePhotoAlbums(updatedAlbums);
  };

  const likePhoto = (photoId: string) => {
    const updated = photos.map((p) => {
      if (p.id !== photoId) return p;
      const likes = p.likes.includes(currentUser.id)
        ? p.likes.filter((id) => id !== currentUser.id)
        : [...p.likes, currentUser.id];
      return { ...p, likes };
    });
    setPhotos(updated);
    StorageService.savePhotoItems(updated);
  };

  const addPhotoComment = (photoId: string, text: string) => {
    if (!text.trim()) return;
    const updated = photos.map((p) => {
      if (p.id !== photoId) return p;
      return {
        ...p,
        comments: [
          ...p.comments,
          {
            id: `pc-${Date.now()}`,
            userId: currentUser.id,
            userName: currentUser.name,
            text: text.trim(),
            createdAt: new Date().toISOString(),
          },
        ],
      };
    });
    setPhotos(updated);
    StorageService.savePhotoItems(updated);
  };

  // --- SERVICIO VICENCIANO ---
  const addServiceExperience = (
    item: Omit<ServiceExperience, 'id' | 'userId' | 'userName' | 'userAvatar' | 'likes' | 'reactions' | 'comments'>
  ) => {
    const newExp: ServiceExperience = {
      ...item,
      id: `srv-${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      userAvatar: currentUser.avatarUrl,
      likes: [],
      reactions: { oracion: 0, amor: 0, inspirador: 0 },
      comments: [],
    };
    const updated = [newExp, ...serviceExperiences];
    setServiceExperiences(updated);
    StorageService.saveServiceExperiences(updated);
  };

  const reactToService = (serviceId: string, reaction: 'oracion' | 'amor' | 'inspirador') => {
    const updated = serviceExperiences.map((s) => {
      if (s.id !== serviceId) return s;
      return {
        ...s,
        reactions: {
          ...s.reactions,
          [reaction]: s.reactions[reaction] + 1,
        },
      };
    });
    setServiceExperiences(updated);
    StorageService.saveServiceExperiences(updated);
  };

  const addServiceComment = (serviceId: string, text: string) => {
    if (!text.trim()) return;
    const updated = serviceExperiences.map((s) => {
      if (s.id !== serviceId) return s;
      return {
        ...s,
        comments: [
          ...s.comments,
          {
            id: `sc-${Date.now()}`,
            userId: currentUser.id,
            userName: currentUser.name,
            userAvatar: currentUser.avatarUrl,
            text: text.trim(),
            createdAt: new Date().toISOString(),
          },
        ],
      };
    });
    setServiceExperiences(updated);
    StorageService.saveServiceExperiences(updated);
  };

  // --- AMIGO SECRETO SEMANAL ---
  // Algoritmo circular sin autodestino, con selección opcional de integrantes
  const startSecretFriendRound = (
    title: string,
    participantIds?: string[],
    durationDays: number = 7
  ) => {
    let eligibleUsers = [...users];
    if (participantIds && participantIds.length >= 2) {
      eligibleUsers = users.filter((u) => participantIds.includes(u.id));
    }
    if (eligibleUsers.length < 2) return;

    // Barajar aleatoriamente
    const shuffled = [...eligibleUsers].sort(() => Math.random() - 0.5);
    const assignments: { giverId: string; receiverId: string }[] = [];

    // Asignación en ciclo: 0 -> 1, 1 -> 2, ..., n-1 -> 0
    for (let i = 0; i < shuffled.length; i++) {
      const giver = shuffled[i];
      const receiver = shuffled[(i + 1) % shuffled.length];
      assignments.push({
        giverId: giver.id,
        receiverId: receiver.id,
      });
    }

    const startDate = new Date();
    const revealDate = new Date(Date.now() + durationDays * 86400000);

    const newRound: SecretFriendRound = {
      id: `round-${Date.now()}`,
      title,
      startDate: startDate.toISOString().split('T')[0],
      revealDate: revealDate.toISOString().split('T')[0],
      status: 'active',
      assignments,
    };

    setSecretRound(newRound);
    StorageService.saveSecretFriendRound(newRound);
    // Limpiar mensajes anteriores de amigo secreto
    setSecretMessages([]);
    StorageService.saveSecretMessages([]);
    triggerConfetti();
  };

  const resetSecretFriendRound = () => {
    const emptyRound: SecretFriendRound = {
      id: `round-${Date.now()}`,
      title: 'Nueva Ronda de Amigo Secreto',
      startDate: new Date().toISOString().split('T')[0],
      revealDate: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
      status: 'active',
      assignments: [],
    };
    setSecretRound(emptyRound);
    StorageService.saveSecretFriendRound(emptyRound);
    setSecretMessages([]);
    StorageService.saveSecretMessages([]);
  };

  // A quién le regala el usuario actual
  const myAssignment = secretRound?.assignments?.find((a) => a.giverId === currentUser.id);
  const mySecretTarget = myAssignment ? users.find((u) => u.id === myAssignment.receiverId) || null : null;

  const sendSecretMessage = (text: string, dayNumber: number) => {
    if (!mySecretTarget || !text.trim()) return;

    const newMsg: SecretMessage = {
      id: `sm-${Date.now()}`,
      roundId: secretRound.id,
      giverId: currentUser.id,
      receiverId: mySecretTarget.id,
      dayNumber,
      text: text.trim(),
      sentAt: new Date().toISOString(),
    };

    const updated = [...secretMessages, newMsg];
    setSecretMessages(updated);
    StorageService.saveSecretMessages(updated);
  };

  const revealSecretFriends = () => {
    if (!secretRound) return;
    const updated = { ...secretRound, status: 'revealed' as const };
    setSecretRound(updated);
    StorageService.saveSecretFriendRound(updated);
    triggerConfetti();
  };

  // --- MURO DE ORACIÓN ---
  const addPrayer = (
    title: string,
    description: string,
    type: 'peticion' | 'agradecimiento',
    isAnonymous: boolean
  ) => {
    const newPrayer: PrayerRequest = {
      id: `pr-${Date.now()}`,
      userId: currentUser.id,
      userName: isAnonymous ? 'Hermano/a en Cristo (Anónimo)' : currentUser.name,
      isAnonymous,
      type,
      title: title.trim(),
      description: description.trim(),
      createdAt: new Date().toISOString(),
      prayerCount: 1,
      prayedBy: [currentUser.id],
    };
    const updated = [newPrayer, ...prayers];
    setPrayers(updated);
    StorageService.savePrayers(updated);
  };

  const joinPrayer = (prayerId: string) => {
    const updated = prayers.map((p) => {
      if (p.id !== prayerId) return p;
      const alreadyPrayed = p.prayedBy.includes(currentUser.id);
      const prayedBy = alreadyPrayed
        ? p.prayedBy.filter((id) => id !== currentUser.id)
        : [...p.prayedBy, currentUser.id];
      return {
        ...p,
        prayerCount: Math.max(0, p.prayerCount + (alreadyPrayed ? -1 : 1)),
        prayedBy,
      };
    });
    setPrayers(updated);
    StorageService.savePrayers(updated);
  };

  // --- RECORDATORIOS Y NOTIFICACIONES PUSH ---
  const addReminder = (title: string, message: string, scheduledFor: string) => {
    const newRem: MeetingReminder = {
      id: `rem-${Date.now()}`,
      title: title.trim(),
      message: message.trim(),
      scheduledFor,
      isSent: false,
      isActive: true,
    };
    const updated = [newRem, ...reminders];
    setReminders(updated);
    StorageService.saveReminders(updated);
  };

  const triggerPushNotification = (title: string, body: string) => {
    if ('Notification' in window) {
      if (Notification.permission === 'granted') {
        new Notification(title, {
          body,
          icon: '/pwa-192x192.png',
          badge: '/icon.svg',
        });
      } else if (Notification.permission !== 'denied') {
        Notification.requestPermission().then((permission) => {
          if (permission === 'granted') {
            new Notification(title, {
              body,
              icon: '/pwa-192x192.png',
            });
          }
        });
      }
    }
  };

  // --- ENCUESTAS Y REFLEXIÓN ---
  const votePoll = (pollId: string, optionId: string) => {
    const updated = polls.map((p) => {
      if (p.id !== pollId) return p;
      return {
        ...p,
        options: p.options.map((opt) => {
          const votesWithoutMe = opt.votes.filter((id) => id !== currentUser.id);
          if (opt.id === optionId) {
            return { ...opt, votes: [...votesWithoutMe, currentUser.id] };
          }
          return { ...opt, votes: votesWithoutMe };
        }),
      };
    });
    setPolls(updated);
    StorageService.savePolls(updated);
  };

  const createPoll = (question: string, optionsText: string[]) => {
    const newPoll: Poll = {
      id: `poll-${Date.now()}`,
      question: question.trim(),
      options: optionsText.map((t, i) => ({ id: `opt-${i}`, text: t.trim(), votes: [] })),
      createdBy: currentUser.name,
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 7 * 86400000).toISOString(),
    };
    const updated = [newPoll, ...polls];
    setPolls(updated);
    StorageService.savePolls(updated);
  };

  const updateReflection = (data: Partial<AdvisorReflection>) => {
    const updated = { ...reflection, ...data };
    setReflection(updated);
    StorageService.saveReflection(updated);
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        users,
        isAdmin,
        canManageFinances,
        isTreasurer,
        treasurerUser,
        setTreasurerUser,
        switchUser,
        updateProfile,
        registerMember,
        theme,
        toggleTheme,
        settings,
        updateSettings,
        challenges,
        submissions,
        createChallenge,
        submitChallenge,
        reviewSubmission,
        feeWeeks,
        feePayments,
        addFeeWeek,
        markFeePayment,
        exportFeesToCSV,
        feeCampaigns,
        createFeeCampaign,
        recordCampaignPayment,
        deleteCampaignSalePayment,
        markCampaignSalePaid,
        toggleInvestmentPayment,
        updateCampaignFinancials,
        deleteFeeCampaign,
        cleanExampleCampaigns,
        activityExpenses,
        addActivityExpense,
        deleteActivityExpense,
        chatMessages,
        sendMessage,
        togglePinMessage,
        addMessageReaction,
        reportMessage,
        activities,
        createActivity,
        bulkCreateActivities,
        rsvpActivity,
        attendanceSessions,
        recordAttendance,
        albums,
        photos,
        createAlbum,
        uploadPhoto,
        likePhoto,
        addPhotoComment,
        serviceExperiences,
        addServiceExperience,
        reactToService,
        addServiceComment,
        secretRound,
        secretMessages,
        startSecretFriendRound,
        resetSecretFriendRound,
        sendSecretMessage,
        revealSecretFriends,
        mySecretTarget,
        prayers,
        addPrayer,
        joinPrayer,
        reminders,
        addReminder,
        triggerPushNotification,
        polls,
        votePoll,
        createPoll,
        reflection,
        updateReflection,
        supabaseConnected,
        showSupabaseGuide,
        setShowSupabaseGuide,
        triggerConfetti,
        isMobileSidebarOpen,
        setIsMobileSidebarOpen,
        toggleMobileSidebar,
        deleteUser,
        cleanExampleUsers,
        updateUser,
        isAuthenticated: effectiveAuthenticated,
        activeGroupKey,
        availableGroups,
        switchGroup,
        createGroupWorkspace,
        loginWithCredentials,
        restoreExampleAdmin,
        requestPasswordReminder,
        verifyCedulaAndRecoverPassword,
        passwordRequests,
        resolvePasswordRequest,
        logout,
        approveMember,
        rejectMember,
        refreshMembers,
        bulkImportMembers,
        showAuthModal,
        setShowAuthModal,
        authModalMode,
        setAuthModalMode,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp debe ser usado dentro de un AppProvider');
  }
  return context;
};
