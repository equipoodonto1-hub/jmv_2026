import { createClient, SupabaseClient } from '@supabase/supabase-js';

const SESSION_KEY_PREFIX = 'jmv_supabase_session_v1';

export const getSupabaseConfig = (): { url: string; key: string } => {
  const envUrl = (import.meta.env.VITE_SUPABASE_URL || '').trim();
  const envKey = (import.meta.env.VITE_SUPABASE_ANON_KEY || '').trim();

  const localUrl = typeof window !== 'undefined' ? (localStorage.getItem('jmv_supabase_url') || '').trim() : '';
  const localKey = typeof window !== 'undefined' ? (localStorage.getItem('jmv_supabase_anon_key') || '').trim() : '';

  return {
    url: envUrl || localUrl,
    key: envKey || localKey,
  };
};

export const setCustomSupabaseConfig = (url: string, key: string) => {
  if (typeof window !== 'undefined') {
    if (url.trim()) localStorage.setItem('jmv_supabase_url', url.trim());
    if (key.trim()) localStorage.setItem('jmv_supabase_anon_key', key.trim());
  }
};

export const isSupabaseConfigured = (): boolean => {
  const { url, key } = getSupabaseConfig();
  return (
    typeof url === 'string' &&
    url.startsWith('https://') &&
    typeof key === 'string' &&
    key.length > 20
  );
};

export const setSupabaseSessionToken = (token: string | null, groupKey?: string) => {
  if (typeof window === 'undefined') return;
  try {
    const activeGroup = (groupKey || localStorage.getItem('jmv_active_group_key_v1') || 'default').trim();
    const scopedStorageKey = `${SESSION_KEY_PREFIX}::${activeGroup}`;
    if (token && token.trim()) {
      const clean = token.trim();
      localStorage.setItem(scopedStorageKey, clean);
      localStorage.setItem(SESSION_KEY_PREFIX, clean);
    } else {
      localStorage.removeItem(scopedStorageKey);
      localStorage.removeItem(SESSION_KEY_PREFIX);
    }
  } catch (e) {
    console.warn('No se pudo guardar token de sesión Supabase:', e);
  }
};

export const getSupabaseSessionToken = (groupKey?: string): string | null => {
  if (typeof window === 'undefined') return null;
  try {
    const activeGroup = (groupKey || localStorage.getItem('jmv_active_group_key_v1') || 'default').trim();
    const scoped = (localStorage.getItem(`${SESSION_KEY_PREFIX}::${activeGroup}`) || '').trim();
    if (scoped) return scoped;
    const globalToken = (localStorage.getItem(SESSION_KEY_PREFIX) || '').trim();
    return globalToken || null;
  } catch {
    return null;
  }
};

// Cliente oficial de Supabase con cabecera de sesión CORS-safe para RLS
export const getSupabaseClient = (groupKey?: string): SupabaseClient | null => {
  const { url, key } = getSupabaseConfig();
  if (!isSupabaseConfigured()) return null;

  const sessionToken = getSupabaseSessionToken(groupKey);
  const clientInfoHeader = sessionToken
    ? `supabase-js-web/2.0; jmv-session=${sessionToken}`
    : 'supabase-js-web/2.0';

  return createClient(url, key, {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
    },
    global: {
      headers: {
        'X-Client-Info': clientInfoHeader,
      },
    },
  });
};

export const supabase: SupabaseClient | null = getSupabaseClient();

/**
 * Prueba la conexión y verificación de seguridad RLS con el proyecto de Supabase configurado.
 */
export async function testSupabaseConnection(
  customUrl?: string,
  customKey?: string
): Promise<{ success: boolean; message: string }> {
  const url = (customUrl || getSupabaseConfig().url).trim();
  const key = (customKey || getSupabaseConfig().key).trim();

  if (!url || !key || !url.startsWith('https://') || key.length < 20) {
    return {
      success: false,
      message: 'Faltan configurar las credenciales válidas (URL que empiece con https:// y clave anon).',
    };
  }

  try {
    const testClient = createClient(url, key, { auth: { persistSession: false } });
    const { data: health, error: healthErr } = await testClient.rpc('jmv_health_check');

    if (!healthErr && health?.ok) {
      return {
        success: true,
        message: health?.rls_enabled
          ? '¡Conexión exitosa con Supabase! Seguridad RLS estricta, cifrado de claves y aislamiento por grupo verificados.'
          : '¡Conexión exitosa con tu base de datos Supabase!',
      };
    }

    // Respaldo informativo si aún no ejecutaron el script SQL actualizado con RLS
    const { error: tableErr } = await testClient.from('jmv_profiles').select('count', { count: 'exact', head: true });
    if (healthErr && !tableErr) {
      return {
        success: true,
        message:
          'Conexión establecida, pero falta ejecutar el Script SQL actualizado (pestaña 2) para activar las políticas RLS estrictas y RPCs de seguridad.',
      };
    }

    return {
      success: false,
      message: `Error al conectar con Supabase: ${healthErr?.message || tableErr?.message || 'Verifica el Script SQL en el SQL Editor.'}`,
    };
  } catch (err: any) {
    return {
      success: false,
      message: `Error de red: ${err?.message || 'No se pudo contactar a Supabase.'}`,
    };
  }
}
