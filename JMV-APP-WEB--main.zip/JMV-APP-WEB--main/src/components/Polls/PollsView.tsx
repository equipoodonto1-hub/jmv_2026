import React, { useState } from 'react';
import { Vote, Plus, CheckCircle2, Clock, Sparkles, X } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const PollsView: React.FC = () => {
  const { polls, votePoll, createPoll, currentUser, isAdmin } = useApp();

  const [showCreateModal, setShowCreateModal] = useState(false);
  const [question, setQuestion] = useState('');
  const [options, setOptions] = useState<string[]>(['', '', '']);

  const handleVote = (pollId: string, optionId: string) => {
    votePoll(pollId, optionId);
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const validOptions = options.map((o) => o.trim()).filter((o) => o.length > 0);
    if (!question.trim() || validOptions.length < 2) return;

    createPoll(question.trim(), validOptions);
    setQuestion('');
    setOptions(['', '', '']);
    setShowCreateModal(false);
  };

  const addOptionField = () => {
    if (options.length < 5) setOptions([...options, '']);
  };

  return (
    <div className="space-y-6 pb-20 animate-in fade-in">
      {/* Encabezado */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400">
              <Vote className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
              Encuestas Rápidas del Grupo
            </h1>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Decisiones comunitarias: colores de camisetas, fechas de retiros y dinámicas.
          </p>
        </div>

        {isAdmin && (
          <button
            onClick={() => setShowCreateModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow-md transition active:scale-95 shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Nueva Encuesta</span>
          </button>
        )}
      </div>

      {/* Lista de encuestas */}
      <div className="space-y-4">
        {polls.map((poll) => {
          const totalVotes = poll.options.reduce((acc, opt) => acc + opt.votes.length, 0);

          return (
            <div
              key={poll.id}
              className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4"
            >
              <div className="flex items-start justify-between gap-3">
                <h3 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white">
                  {poll.question}
                </h3>
                <span className="text-[10px] font-semibold text-slate-400 shrink-0">
                  {totalVotes} votos en total
                </span>
              </div>

              {/* Opciones con barra de porcentaje */}
              <div className="space-y-2.5">
                {poll.options.map((option) => {
                  const hasVotedThis = option.votes.includes(currentUser.id);
                  const percentage =
                    totalVotes > 0 ? Math.round((option.votes.length / totalVotes) * 100) : 0;

                  return (
                    <button
                      key={option.id}
                      onClick={() => handleVote(poll.id, option.id)}
                      className={`relative w-full p-3.5 rounded-2xl border text-left transition overflow-hidden ${
                        hasVotedThis
                          ? 'border-blue-600 bg-blue-50/50 dark:bg-blue-950/40'
                          : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/40 hover:bg-slate-50'
                      }`}
                    >
                      {/* Fondo de porcentaje */}
                      <div
                        className={`absolute left-0 top-0 bottom-0 opacity-15 transition-all duration-500 ${
                          hasVotedThis ? 'bg-blue-600' : 'bg-slate-500'
                        }`}
                        style={{ width: `${percentage}%` }}
                      />

                      <div className="relative z-10 flex items-center justify-between text-xs font-semibold">
                        <div className="flex items-center gap-2">
                          <span
                            className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${
                              hasVotedThis
                                ? 'border-blue-600 bg-blue-600 text-white'
                                : 'border-slate-300 dark:border-slate-600'
                            }`}
                          >
                            {hasVotedThis && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                          </span>
                          <span className="text-slate-800 dark:text-slate-100">{option.text}</span>
                        </div>

                        <div className="flex items-center gap-2 text-slate-500">
                          <span className="font-extrabold tabular-nums">{percentage}%</span>
                          <span className="text-[10px] opacity-70">({option.votes.length})</span>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>

              <div className="pt-2 flex items-center justify-between text-[11px] text-slate-400">
                <span>Creada por {poll.createdBy}</span>
                <span>Toca una opción para emitir o cambiar tu voto</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal: Crear Encuesta */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 animate-in fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                Crear Encuesta Rápida
              </h3>
              <button onClick={() => setShowCreateModal(false)} className="text-slate-400">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreate} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Pregunta de la encuesta *
                </label>
                <input
                  type="text"
                  required
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                  placeholder="Ej: ¿Qué color de camiseta preferimos?"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Opciones de respuesta *
                </label>
                <div className="space-y-2">
                  {options.map((opt, i) => (
                    <input
                      key={i}
                      type="text"
                      required={i < 2}
                      value={opt}
                      onChange={(e) => {
                        const newOpts = [...options];
                        newOpts[i] = e.target.value;
                        setOptions(newOpts);
                      }}
                      placeholder={`Opción ${i + 1}`}
                      className="w-full px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs"
                    />
                  ))}
                </div>
                {options.length < 5 && (
                  <button
                    type="button"
                    onClick={addOptionField}
                    className="mt-2 text-[11px] font-bold text-blue-800 dark:text-blue-400 hover:underline"
                  >
                    + Agregar otra opción
                  </button>
                )}
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow mt-2"
              >
                Publicar Encuesta
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
