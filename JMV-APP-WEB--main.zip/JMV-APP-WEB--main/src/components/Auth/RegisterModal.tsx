import React, { useState } from 'react';
import { X, Heart, User, Calendar, Phone, Key, Upload, Camera, Users } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { compressAvatarImage } from '../../services/imageCompression';

export const RegisterModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({
  isOpen,
  onClose,
}) => {
  const { registerMember, settings, activeGroupKey, availableGroups } = useApp();

  const [selectedGroupKey, setSelectedGroupKey] = useState(activeGroupKey);
  const [customGroupName, setCustomGroupName] = useState('');
  const [name, setName] = useState('');
  const [birthday, setBirthday] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [cedula, setCedula] = useState('');
  const [invitationCode, setInvitationCode] = useState('');
  const [avatarPreview, setAvatarPreview] = useState<string>('');
  const [imageConsent, setImageConsent] = useState(false);
  const [isMinor, setIsMinor] = useState(false);
  const [tutorName, setTutorName] = useState('');
  const [tutorPhone, setTutorPhone] = useState('');
  const [serviceArea, setServiceArea] = useState('Misión y Visitas');
  const [spiritualQuote, setSpiritualQuote] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [isCompressing, setIsCompressing] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);

  if (!isOpen) return null;

  const handleAvatarFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setErrorMsg('');
    try {
      setIsCompressing(true);
      const dataUrl = await compressAvatarImage(file);
      setAvatarPreview(dataUrl);
    } catch (err) {
      console.error(err);
      setErrorMsg('No se pudo procesar la foto elegida. Prueba con una imagen JPG o PNG.');
    } finally {
      setIsCompressing(false);
      e.target.value = '';
    }
  };

  const handleBirthdayChange = (val: string) => {
    setBirthday(val);
    if (val) {
      const birth = new Date(val);
      const ageDifMs = Date.now() - birth.getTime();
      const ageDate = new Date(ageDifMs);
      const calculatedAge = Math.abs(ageDate.getUTCFullYear() - 1970);
      if (calculatedAge < 18) {
        setIsMinor(true);
      } else {
        setIsMinor(false);
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const isCustom = selectedGroupKey === '__custom__';
    if (isCustom && !customGroupName.trim()) {
      setErrorMsg('Ingresa el nombre exacto del grupo JMV.');
      return;
    }

    if (isMinor && (!tutorName.trim() || !tutorPhone.trim())) {
      setErrorMsg('Al ser menor de edad, se requiere el nombre y teléfono del padre o tutor.');
      return;
    }

    const generatedEmail = email.trim() || `${name.toLowerCase().replace(/[\s\.]+/g, '')}@gmail.com`;
    const generatedCedula = cedula.trim() || `172${Date.now().toString().slice(-7)}`;
    const chosenGroup = availableGroups.find((g) => g.groupKey === selectedGroupKey);

    setIsRegistering(true);
    try {
      const res = await registerMember({
        name,
        email: generatedEmail,
        cedula: generatedCedula,
        password: generatedCedula,
        birthday,
        phone: phone.trim() || undefined,
        invitationCode: invitationCode.replace(/[\s\u200B-\u200D\uFEFF]/g, '').toUpperCase(),
        groupKey: isCustom ? undefined : selectedGroupKey,
        groupName: isCustom ? customGroupName.trim() : chosenGroup?.groupName || settings.groupName,
        avatarUrl: avatarPreview || undefined,
        imageConsentAccepted: imageConsent,
        isMinor,
        tutorName: isMinor ? tutorName.trim() : undefined,
        tutorPhone: isMinor ? tutorPhone.trim() : undefined,
        serviceArea,
        spiritualQuote: spiritualQuote.trim() || undefined,
      });

      if (!res.success) {
        setErrorMsg(res.error || 'No se pudo completar el registro.');
      } else if (res.pendingApproval) {
        setErrorMsg('');
        setName('');
        setEmail('');
        setCedula('');
        setInvitationCode('');
        onClose();
      } else {
        onClose();
      }
    } finally {
      setIsRegistering(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 my-8 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-blue-900 text-amber-400 font-extrabold flex items-center justify-center text-xs">
              JMV
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">Únete a JMV</h2>
              <p className="text-xs text-slate-500">Registro por grupo con código privado</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {errorMsg && (
          <div className="mt-3 p-3 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900/50 text-xs text-red-700 dark:text-red-300">
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-4 space-y-4 text-xs">
          {/* Grupo JMV */}
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5 text-blue-600" />
              Grupo JMV *
            </label>
            <select
              value={selectedGroupKey}
              onChange={(e) => setSelectedGroupKey(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-bold focus:ring-2 focus:ring-blue-600 outline-none"
            >
              {availableGroups.map((g) => (
                <option key={g.groupKey} value={g.groupKey}>
                  {g.groupName} {g.parishName ? `· ${g.parishName}` : ''}
                </option>
              ))}
              <option value="__custom__">Escribir el nombre exacto de otro grupo...</option>
            </select>
            {selectedGroupKey === '__custom__' && (
              <input
                type="text"
                required
                value={customGroupName}
                onChange={(e) => setCustomGroupName(e.target.value)}
                placeholder="Nombre exacto del grupo"
                className="mt-2 w-full px-3.5 py-2 rounded-xl border border-blue-300 dark:border-blue-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-semibold focus:ring-2 focus:ring-blue-600 outline-none"
              />
            )}
          </div>

          {/* Código de invitación */}
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
              <Key className="w-3.5 h-3.5 text-amber-500" />
              Código de invitación del grupo *
            </label>
            <input
              type="text"
              required
              value={invitationCode}
              onChange={(e) => setInvitationCode(e.target.value.replace(/[\s\u200B-\u200D\uFEFF]/g, '').toUpperCase())}
              placeholder="Ingresa el código privado del grupo"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white uppercase tracking-wider font-mono font-bold focus:ring-2 focus:ring-blue-600 outline-none"
            />
            <p className="text-[10px] text-slate-400 mt-1">
              Pide el código al coordinador o asesor de tu parroquia.
            </p>
          </div>

          {/* Nombre completo */}
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-blue-600" />
              Nombre y apellido *
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ej: Valeria Gómez"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-600 outline-none"
            />
          </div>

          {/* Foto de perfil con compresión */}
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
              <Camera className="w-3.5 h-3.5 text-blue-600" />
              Foto de perfil (opcional)
            </label>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full overflow-hidden bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shrink-0 flex items-center justify-center">
                {avatarPreview ? (
                  <img src={avatarPreview} alt="Preview" className="w-full h-full object-cover" />
                ) : (
                  <User className="w-6 h-6 text-slate-400" />
                )}
              </div>
              <label className="cursor-pointer flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-medium transition text-xs">
                <Upload className="w-3.5 h-3.5" />
                <span>{isCompressing ? 'Comprimiendo...' : 'Subir foto'}</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleAvatarFile}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          {/* Cumpleaños y Teléfono */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-blue-600" />
                Cumpleaños *
              </label>
              <input
                type="date"
                required
                value={birthday}
                onChange={(e) => handleBirthdayChange(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-600 outline-none text-xs"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-blue-600" />
                Teléfono WhatsApp
              </label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+593 99..."
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-600 outline-none text-xs"
              />
            </div>
          </div>

          {/* Área de Servicio y Apostolado Preferido */}
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
              <Heart className="w-3.5 h-3.5 text-rose-500" />
              ¿En qué te gustaría colaborar o servir en JMV?
            </label>
            <select
              value={serviceArea}
              onChange={(e) => setServiceArea(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs font-semibold"
            >
              <option value="Misión y Visitas">🕊️ Misión y Visitas a Comunidades</option>
              <option value="Coro y Animación">🎵 Coro y Animación Musical</option>
              <option value="Liturgia y Oración">✝️ Liturgia y Oración Comunitaria</option>
              <option value="Caridad y Comedor">🍲 Caridad y Comedor Vicenciano</option>
              <option value="Deportes y Convivencia">⚽ Deportes y Dinámicas Juveniles</option>
            </select>
          </div>

          {/* Frase o motivación vicenciana */}
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Tu frase o lema personal que te inspira (opcional)
            </label>
            <input
              type="text"
              value={spiritualQuote}
              onChange={(e) => setSpiritualQuote(e.target.value)}
              placeholder="Ej: A Jesús por María • Servir con alegría"
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs"
            />
          </div>

          {/* Menor de edad */}
          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-2.5">
            <label className="flex items-center gap-2 cursor-pointer font-semibold text-slate-800 dark:text-slate-200">
              <input
                type="checkbox"
                checked={isMinor}
                onChange={(e) => setIsMinor(e.target.checked)}
                className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500"
              />
              <span>Soy menor de edad (menor de 18 años)</span>
            </label>

            {isMinor && (
              <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-700">
                <div>
                  <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-0.5">
                    Nombre del padre, madre o apoderado *
                  </label>
                  <input
                    type="text"
                    value={tutorName}
                    onChange={(e) => setTutorName(e.target.value)}
                    placeholder="Ej: Rosa Gómez"
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-0.5">
                    Teléfono de contacto del apoderado *
                  </label>
                  <input
                    type="tel"
                    value={tutorPhone}
                    onChange={(e) => setTutorPhone(e.target.value)}
                    placeholder="Teléfono para emergencias"
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Autorización de uso de imagen */}
          <div className="p-3 rounded-2xl bg-blue-50/70 dark:bg-blue-950/30 border border-blue-100 dark:border-blue-900/40">
            <label className="flex items-start gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                required
                checked={imageConsent}
                onChange={(e) => setImageConsent(e.target.checked)}
                className="w-4 h-4 mt-0.5 rounded text-blue-600 focus:ring-blue-500"
              />
              <div className="text-[11px] text-slate-700 dark:text-slate-300 leading-tight">
                <strong>Autorización de uso de imagen interno pastoral:</strong> Autorizo la publicación de fotos en la galería privada de JMV y álbumes de actividades grupales con fines exclusivamente formativos y comunitarios.
              </div>
            </label>
          </div>

          <button
            type="submit"
            disabled={isRegistering}
            className="w-full py-3 px-4 rounded-2xl bg-blue-900 hover:bg-blue-800 disabled:opacity-60 text-white font-bold text-sm shadow-lg shadow-blue-900/20 active:scale-[0.98] transition flex items-center justify-center gap-2"
          >
            <Heart className="w-4 h-4 text-amber-400 fill-amber-400" />
            <span>{isRegistering ? 'Verificando código...' : 'Completar Registro en JMV'}</span>
          </button>
        </form>
      </div>
    </div>
  );
};
