import React from 'react';
import {
  X,
  Home,
  Award,
  DollarSign,
  MessageSquare,
  Calendar,
  Heart,
  Sparkles,
  Gift,
  Image as ImageIcon,
  Cake,
  UserCheck,
  Vote,
  Users,
  Palette,
  ShieldCheck,
  Database,
  Moon,
  Sun,
  UserPlus,
  ChevronRight,
  Sparkle,
  User,
  Key,
  LogOut,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import marianMedalImg from '../../assets/images/jmv_marian_medal_1794117311829.jpg';
import { PWAInstallButton } from '../Common/PWAInstallButton';

export const MobileSidebar: React.FC<{
  currentTab: string;
  onNavigateTab: (tab: string) => void;
  onOpenRegister: () => void;
}> = ({ currentTab, onNavigateTab, onOpenRegister }) => {
  const {
    isMobileSidebarOpen,
    setIsMobileSidebarOpen,
    currentUser,
    users,
    isAdmin,
    isTreasurer,
    theme,
    toggleTheme,
    settings,
    setShowSupabaseGuide,
    logout,
    setShowAuthModal,
    setAuthModalMode,
  } = useApp();

  if (!isMobileSidebarOpen) return null;

  const handleSelectTab = (tabId: string) => {
    onNavigateTab(tabId);
    setIsMobileSidebarOpen(false);
  };

  const navCategories = [
    {
      title: 'Principal',
      items: [
        { id: 'inicio', label: 'Inicio', icon: Home, color: 'text-blue-600 dark:text-blue-400' },
        { id: 'perfil', label: 'Mi Ficha / Panel Individual', icon: User, color: 'text-blue-700 dark:text-blue-400', badge: 'Personal' },
        { id: 'retos', label: 'Retos Semanales', icon: Award, color: 'text-amber-500' },
        { id: 'cuotas', label: 'Cuotas y Tesorería', icon: DollarSign, color: 'text-emerald-600 dark:text-emerald-400', badge: 'Ventas y $1' },
        { id: 'chat', label: 'Chat Grupal', icon: MessageSquare, color: 'text-blue-500' },
      ],
    },
    {
      title: 'Vida Comunitaria y Fe',
      items: [
        { id: 'actividades', label: 'Calendario de Actividades', icon: Calendar, color: 'text-indigo-500' },
        { id: 'oracion', label: 'Muro de Oración', icon: Heart, color: 'text-rose-500' },
        { id: 'servicio', label: 'Muro de Servicio', icon: Sparkles, color: 'text-amber-500' },
        { id: 'amigo-secreto', label: 'Amigo Secreto', icon: Gift, color: 'text-purple-500' },
      ],
    },
    {
      title: 'Memorias y Participación',
      items: [
        { id: 'galeria', label: 'Galería de Fotos', icon: ImageIcon, color: 'text-teal-500' },
        { id: 'cumpleanios', label: 'Cumpleaños del Mes', icon: Cake, color: 'text-rose-400' },
        { id: 'asistencia', label: 'Asistencia y Fidelidad', icon: UserCheck, color: 'text-blue-600' },
        { id: 'encuestas', label: 'Encuestas Rápidas', icon: Vote, color: 'text-amber-600' },
      ],
    },
    {
      title: 'Gestión y Coordinación',
      items: [
        {
          id: 'admin',
          label: 'Panel de Solicitudes',
          icon: UserPlus,
          color: 'text-emerald-600 dark:text-emerald-400',
          badge: `${users.filter((u) => u.status === 'pendiente_aprobacion').length} pend.`,
        },
        {
          id: 'admin',
          label: 'Gestión de Integrantes',
          icon: Users,
          color: 'text-indigo-600 dark:text-indigo-400',
          badge: `${users.length} miembros`,
        },
        {
          id: 'admin',
          label: 'Identidad: Parroquia y Logo',
          icon: Palette,
          color: 'text-amber-600 dark:text-amber-400',
        },
        {
          id: 'admin',
          label: 'Panel del Administrador',
          icon: ShieldCheck,
          color: 'text-blue-900 dark:text-blue-300',
        },
      ],
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Fondo translúcido con desenfoque */}
      <div
        className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm transition-opacity"
        onClick={() => setIsMobileSidebarOpen(false)}
        aria-hidden="true"
      />

      {/* Contenedor del Drawer lateral deslizable */}
      <div className="relative w-[85%] max-w-xs h-full bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col z-10 animate-in slide-in-from-left duration-250">
        {/* Cabecera del Sidebar */}
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 bg-gradient-to-r from-blue-900 via-blue-800 to-indigo-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-11 h-11 rounded-2xl overflow-hidden ring-2 ring-amber-400 bg-white p-1 shrink-0 shadow-md flex items-center justify-center">
              <img
                src={settings.logoUrl || marianMedalImg}
                alt={settings.groupName}
                className="w-full h-full object-contain rounded-xl"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="flex flex-col min-w-0">
              <span className="font-extrabold text-sm tracking-tight text-white leading-tight truncate">
                {settings.groupName}
              </span>
              <span className="text-[11px] text-amber-300 font-semibold leading-snug truncate">
                {settings.parishName || 'Comunidad Mariana'}
              </span>
            </div>
          </div>

          <button
            onClick={() => setIsMobileSidebarOpen(false)}
            className="w-8 h-8 rounded-full flex items-center justify-center text-white/80 hover:text-white hover:bg-white/10 transition-colors"
            aria-label="Cerrar barra lateral"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tarjeta del Integrante Activo (clic para ir a su ficha) */}
        <div
          onClick={() => handleSelectTab('perfil')}
          className="p-3.5 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800 transition group"
          title="Ver mi ficha y panel individual"
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <img
              src={currentUser.avatarUrl}
              alt={currentUser.name}
              className="w-9 h-9 rounded-full object-cover ring-2 ring-amber-400 shrink-0 group-hover:scale-105 transition-transform"
              referrerPolicy="no-referrer"
            />
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <p className="font-bold text-xs text-slate-900 dark:text-white truncate group-hover:text-blue-700 dark:group-hover:text-blue-400">
                  {currentUser.name}
                </p>
                <span className={`text-[8px] font-extrabold px-1.5 py-0.2 rounded-full ${
                  currentUser.status === 'aprobado'
                    ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300'
                    : 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300'
                }`}>
                  {currentUser.status === 'aprobado' ? '✓' : '⏳'}
                </span>
              </div>
              <p className="text-[10px] text-slate-400 truncate">
                CI: {currentUser.cedula}
              </p>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300">
                  {isAdmin
                    ? '🛡️ Admin'
                    : isTreasurer
                    ? '💰 Tesorero'
                    : '👤 Integrante'}
                </span>
                <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400 flex items-center gap-0.5">
                  <Sparkle className="w-2.5 h-2.5 fill-current" />
                  {currentUser.points} pts
                </span>
              </div>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 transition" />
        </div>

        {/* Lista de Navegación por Categorías con Scroll */}
        <div className="flex-1 overflow-y-auto px-3 py-3 space-y-4 text-xs">
          {navCategories.map((cat, idx) => (
            <div key={idx} className="space-y-1">
              <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                {cat.title}
              </div>
              <div className="space-y-0.5">
                {cat.items.map((item, itemIdx) => {
                  const Icon = item.icon;
                  const isActive = currentTab === item.id;
                  return (
                    <button
                      key={itemIdx}
                      onClick={() => handleSelectTab(item.id)}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-left transition font-medium ${
                        isActive
                          ? 'bg-blue-900 text-white font-bold shadow-sm'
                          : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-amber-300' : item.color}`} />
                        <span className="truncate">{item.label}</span>
                      </div>
                      {item.badge && (
                        <span
                          className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold shrink-0 ${
                            isActive
                              ? 'bg-blue-800 text-amber-200'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                          }`}
                        >
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}

          {/* Botón directo a la Guía Netlify/Supabase */}
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
            <button
              onClick={() => {
                setIsMobileSidebarOpen(false);
                setShowSupabaseGuide(true);
              }}
              className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-emerald-800 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/50 hover:bg-emerald-100 font-bold border border-emerald-200/60 dark:border-emerald-800/40 text-xs transition"
            >
              <div className="flex items-center gap-2.5">
                <Database className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Base de Datos y Netlify</span>
              </div>
              <ChevronRight className="w-3.5 h-3.5 text-emerald-500" />
            </button>
          </div>
        </div>

        {/* Pie del Sidebar: Registrar Integrante, Cambiar Cuenta, Tema Claro/Oscuro y Lema */}
        <div className="p-3 border-t border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/80 space-y-2">
          <div className="grid grid-cols-2 gap-1.5">
            <button
              onClick={() => {
                setIsMobileSidebarOpen(false);
                setAuthModalMode('login');
                setShowAuthModal(true);
              }}
              className="flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold text-[11px] transition"
            >
              <Key className="w-3.5 h-3.5 text-amber-500" />
              <span>Cambiar Cuenta</span>
            </button>
            <button
              onClick={() => {
                setIsMobileSidebarOpen(false);
                logout();
              }}
              className="flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl bg-red-50 hover:bg-red-100 dark:bg-red-950/40 text-red-600 dark:text-red-400 font-bold text-[11px] transition"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Cerrar Sesión</span>
            </button>
          </div>

          <button
            onClick={() => {
              setIsMobileSidebarOpen(false);
              setAuthModalMode('register');
              setShowAuthModal(true);
            }}
            className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs shadow transition active:scale-95"
          >
            <UserPlus className="w-3.5 h-3.5 text-amber-300" />
            <span>+ Registrar nuevo participante</span>
          </button>

          <div className="flex items-center justify-between gap-2 pt-1">
            <button
              onClick={toggleTheme}
              className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold hover:bg-white dark:hover:bg-slate-800 transition"
            >
              {theme === 'dark' ? (
                <>
                  <Sun className="w-3.5 h-3.5 text-amber-400" /> Modo Claro
                </>
              ) : (
                <>
                  <Moon className="w-3.5 h-3.5 text-blue-900" /> Modo Oscuro
                </>
              )}
            </button>
            <PWAInstallButton />
          </div>

          <p className="text-[10px] text-center text-slate-400 dark:text-slate-500 font-medium pt-1 truncate">
            {settings.groupName} • {settings.parishName || 'A Jesús por María'}
          </p>
        </div>
      </div>
    </div>
  );
};
